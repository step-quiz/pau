#!/usr/bin/env node
/* ═══════════════════════════════════════════════════════════════════
   proves/comprova.js — Proves automàtiques dels procediments
   ───────────────────────────────────────────────────────────────────
   Sense dependències. Des de l'arrel del repositori:
       node procediments/proves/comprova.js
   (o «node procediments/proves/comprova.js binomial»: només les seccions
   que tenen aquest text al nom).
   Comprova:
     1. mates.js i formules.js: fraccions, lectura, polinomis, escriptura;
     2. l'adreça de la recta tangent: lectura, errors i anada i tornada;
     3. els guions: claus vàlides i úniques; el cursor, les fusions i els
        canvis de nom només fan servir símbols que existeixen;
     4. la veritat: cada línia de cada pas és una igualtat certa. Es
        comprova amb aritmètica exacta (fraccions), per a una graella
        de dades.
   Acaba amb el codi 1 si alguna prova falla.
   ═══════════════════════════════════════════════════════════════════ */
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const DIR = path.join(__dirname, '..');
for (const fitxer of ['mates.js', 'formules.js', 'dades.js', 'recta-tangent.js', 'extrems.js', 'creixement.js', 'optimitzacio.js', 'matrius.js', 'polinomi-condicions.js', 'bolzano.js', 'asimptotes.js', 'arbres.js', 'probabilitat-total.js', 'bayes.js', 'binomial.js', 'determinant.js', 'rang.js', 'sistema-sci.js', 'discussio.js', 'inversa.js', 'equacio-matricial.js', 'esglaonar.js', 'geometria.js', 'pla.js', 'recta-plans.js', 'recta-pla.js', 'dues-rectes.js', 'distancies.js', 'projeccions.js', 'area-volum.js', 'perpendicular-comuna.js', 'primitiva.js', 'barrow.js', 'grafiques.js', 'integrals.js', 'area-eix.js', 'area-corbes.js', 'area-parametre.js', 'grafica-funcio.js', 'domini.js']) {
  vm.runInThisContext(fs.readFileSync(path.join(DIR, fitxer), 'utf8'), {filename: fitxer});
}
const {Mates: M, Formules: F, Dades: Dd, RectaTangent: RT, Extrems, Creixement, Optimitzacio, PolinomiCondicions, Bolzano, Asimptotes, ProbabilitatTotal, Bayes, Binomial, Matrius, Determinant, Rang, SistemaSCI, Discussio, Inversa, EquacioMatricial, Esglaonar, Geometria, Pla, RectaPlans, RectaPla, DuesRectes, Distancies, Projeccions, AreaVolum, PerpendicularComuna, Primitiva, Barrow, AreaEix, AreaCorbes, AreaParametre, Domini} = globalThis;
const {Fraccio} = M;
const fr = (a, b = 1) => new Fraccio(a, b);


/* ── PETIT ENTORN DE PROVES ────────────────────────────────────────── */

let total = 0, errors = 0;
const MAX_MISSATGES = 25;
const missatges = [];

function comprova(condicio, descripcio) {
  total++;
  if (condicio) return;
  errors++;
  if (missatges.length < MAX_MISSATGES) missatges.push(typeof descripcio === 'function' ? descripcio() : descripcio);
}

/** «node comprova.js binomial» només fa les seccions amb «binomial» al nom (per anar de pressa mentre es treballa). */
const NOMES = process.argv[2] || '';

function seccio(nom, fes) {
  if (!nom.includes(NOMES)) return;
  const [t0, e0, inici] = [total, errors, Date.now()];
  let detall = '';
  try {
    detall = fes() || '';
  } catch (e) {
    errors++;
    missatges.push(`${nom}: excepció inesperada: ${e.stack}`);
  }
  const estat = errors === e0 ? 'OK ' : 'ERR';
  console.log(`  ${estat} ${nom}: ${total - t0} comprovacions${detall ? ', ' + detall : ''}`
    + (errors > e0 ? `, ${errors - e0} errors` : '') + ` (${((Date.now() - inici) / 1000).toFixed(1)} s)`);
}

/** Cert si «fes» llança un ErrorLectura amb un missatge que compleix «patro». */
function errorDeLectura(fes, patro) {
  try { fes(); } catch (e) { return e.name === 'ErrorLectura' && patro.test(e.message); }
  return false;
}

const iguals = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const textCoefs = p => p && p.map(c => (c.esEnter() ? String(c.num) : c.num + '/' + c.den)).join(' ');

/** Generador pseudoaleatori amb llavor (mulberry32): les proves són sempre les mateixes. */
function aleatori(llavor) {
  return () => {
    llavor = (llavor + 0x6D2B79F5) | 0;
    let t = Math.imul(llavor ^ (llavor >>> 15), 1 | llavor);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}


/* ── DE LA PISSARRA A L'ARITMÈTICA ─────────────────────────────────── */

/**
 * Converteix una línia TeX de la pissarra en text pla que Mates.llegeix
 * entén: treu les claus, \mathbin, \mathrel, \left, \right i els espais;
 * \cdot → *, ^{…} → ^(…), ^{\prime} → ', \frac{a}{b} → ((a)/(b)),
 * \sqrt{a} → sqrt(a), \pm → ±, \text{o} → | (disjunció), \text{…} → «…».
 */
function textPla(tex) {
  let i = 0;
  const grup = () => {
    if (tex[i] !== '{') return tex[i++];           // argument d'un sol caràcter
    i++;
    const s = sequencia('}');
    if (tex[i] !== '}') throw new Error(`Falta una «}» a: ${tex}`);
    i++;
    return s;
  };
  function sequencia(fi) {
    let s = '';
    while (i < tex.length && tex[i] !== fi) {
      const c = tex[i];
      if (c === '{') { s += grup(); continue; }
      if (c === '}') throw new Error(`Sobra una «}» a: ${tex}`);
      if (c === '^') { i++; const g = grup(); s += /^'+$/.test(g) ? g : '^(' + g + ')'; continue; }
      if (c === '_') { i++; s += '_' + grup(); continue; }
      if (c === '\\') {
        const ordre = /^\\([A-Za-z]+|.)/.exec(tex.slice(i))[0];
        i += ordre.length;
        switch (ordre) {
          case '\\htmlData': grup(); break;          // l'atribut k=…; el contingut és el grup següent
          case '\\mathbin': case '\\mathrel': case '\\left': case '\\right': case '\\,': case '\\ ': case '\\quad': break;
          case '\\pm': s += '±'; break;
          case '\\lbrack': s += '('; break;
          case '\\leftrightarrow': s += '↔'; break;
          case '\\small': break;            // els claudàtors de Sarrus: [p₁ + p₂ + p₃] − [p₄ + p₅ + p₆]
          case '\\rbrack': s += ')'; break;
          case '\\qquad': break;
          case '\\mathbb': grup(); s += 'ℝ'; break;
          case '\\{': s += '{'; break;
          case '\\}': s += '}'; break;
          case '\\infty': s += '∞'; break;
          case '\\cup': s += '∪'; break;
          case '\\nearrow': s += '↗'; break;
          case '\\searrow': s += '↘'; break;
          case '\\nexists': s += '∄'; break;
          case '\\exists': s += '∃'; break;
          case '\\in': s += '∈'; break;
          case '\\approx': s += '≈'; break;
          case '\\lim': s += 'lim'; break;
          case '\\begin': case '\\end': grup(); break;          // els entorns (array): només en queda el contingut
          case '\\\\': s += ';'; break;                        // salt de línia d'un array
          case '\\xrightarrow': s += `→⟨${grup()}⟩`; break;      // branca d'un arbre, amb la probabilitat
          case '\\boxed': s += grup(); break;
          case '\\phantom': grup(); break;
          case '\\textstyle': case '\\displaystyle': break;
          case '\\overline': s += '¬' + grup(); break;
          case '\\mid': s += '∣'; break;
          case '\\%': s += '%'; break;
          case '\\cap': s += '∩'; break;
          case '\\sim': s += '∼'; break;
          case '\\cdots': s += '…'; break;
          case '\\lambda': s += 'λ'; break;
          case '\\Rightarrow': s += '⇒'; break;
          case '\\overrightarrow': case '\\vec': s += '«' + grup() + '»'; break;
          case '\\tfrac': { const a = grup(), b = grup(); s += `((${a})/(${b}))`; break; }
          case '\\mu': s += 'μ'; break;
          case '\\scriptsize': break;
          case '\\iff': s += '⇔'; break;
          case '\\neq': case '\\ne': s += '≠'; break;
          case '\\hline': break;
          case '\\ge': s += '≥'; break;
          case '\\ln': s += 'ln'; break;
          case '\\le': s += '≤'; break;
          case '\\binom': { const a = grup(), b = grup(); s += `C(${a},${b})`; break; }   // nombre combinatori
          case '\\limits': break;
          case '\\to': s += '→'; break;
          case '\\underset': { const sota = grup(); s += `${grup()}⁽${sota}⁾`; break; }   // un nombre amb un signe a sota
          case '\\sqrt': {
            if (tex[i] === '[') {                     // \sqrt[n]{a} → a^(1/n)
              const fi = tex.indexOf(']', i);
              const n = tex.slice(i + 1, fi);
              i = fi + 1;
              s += `((${grup()})^(1/${n}))`;
            } else s += `sqrt(${grup()})`;
            break;
          }
          case '\\pi': s += '(pi)'; break;
          case '\\text': case '\\textbf': { const t = grup(); s += t.trim() === 'o' ? '|' : `«${t}»`; break; }
          case '\\boldsymbol': case '\\boxed': s += grup(); break;
          case '\\textcolor': grup(); s += grup(); break;          // el color no compta
          case '\\cdot': s += '*'; break;
          case '\\prime': s += "'"; break;
          case '\\frac': case '\\dfrac': { const a = grup(), b = grup(); s += `((${a})/(${b}))`; break; }
          default: throw new Error(`Ordre TeX no prevista per la prova: ${ordre}`);
        }
        continue;
      }
      s += c;
      i++;
    }
    return s;
  }
  const s = sequencia(undefined);
  return s.replace(/\s+/g, '');
}

/**
 * Les solucions tatxades d'una fila (Formules.tatxa: \textcolor{#b91c1c}{\cancel{…}}): {net, tatxades},
 * la fila sense les marques de tatxar (amb el contingut) i el TeX de cada tros tatxat.
 */
function separaTatxades(tex) {
  const OBRE = '\\textcolor{#b91c1c}{\\cancel{';
  const tatxades = [];
  let net = '', i = 0;
  for (;;) {
    const j = tex.indexOf(OBRE, i);
    if (j < 0) { net += tex.slice(i); break; }
    net += tex.slice(i, j);
    let k = j + OBRE.length, nivell = 1;
    const inici = k;
    while (nivell && k < tex.length) {
      if (tex[k] === '\\') k++;
      else if (tex[k] === '{') nivell++;
      else if (tex[k] === '}') nivell--;
      k++;
    }
    const dins = tex.slice(inici, k - 1);
    if (tex[k] !== '}') throw new Error('tatxa mal tancada');
    tatxades.push(dins);
    net += dins;
    i = k + 1;
  }
  return {net, tatxades};
}

/** Claus d'una línia TeX, en ordre. */
const clausDe = tex => [...tex.matchAll(/\\htmlData\{k=([^},]*)[^}]*\}|\{\{([^|}]+)\|/g)].map(m => m[1] || m[2]);

/** Valor exacte (Fraccio) d'un arbre de Mates.llegeix. */
function exacte(n, entorn) {
  const ev = m => exacte(m, entorn);
  switch (n.tipus) {
    case 'nombre':   return n.valor;
    case 'variable': return entorn.variables[n.nom];
    case 'oposat':   return ev(n.a).oposada();
    case 'suma':     return ev(n.a).suma(ev(n.b));
    case 'resta':    return ev(n.a).resta(ev(n.b));
    case 'producte': return ev(n.a).producte(ev(n.b));
    case 'quocient': return ev(n.a).quocient(ev(n.b));
    case 'potencia': {
      const e = ev(n.exponent), b = ev(n.base);
      if (e.esEnter() && e.num >= 0) return b.potencia(e.num);
      if (e.num === 1 && e.den > 1 && b.signe() >= 0) {      // arrel n-èsima exacta
        const arrel = k => { const r = Math.round(Math.pow(k, 1 / e.den)); return r ** e.den === k ? r : null; };
        const [a, d] = [arrel(b.num), arrel(b.den)];
        if (a !== null && d !== null) return fr(a, d);
      }
      throw new Error('Potència no prevista per la prova');
    }
    case 'constant': {
      if (n.nom === 'pi' && entorn.variables.pi) return entorn.variables.pi;   // π com a indeterminada
      throw new Error(`Constant no prevista per la prova: ${n.nom}`);
    }
    case 'crida': {
      if (n.nom !== 'sqrt') return entorn.funcions[n.nom](ev(n.arg));
      const v = ev(n.arg);
      if (v.signe() < 0) throw new SenseValorReal();
      const r = M.arrelExacta(v);
      if (!r) throw new Error(`Arrel irracional: √${v.num}/${v.den}`);
      return r;
    }
  }
  throw new Error(`Node no previst per la prova: ${n.tipus}`);
}

/** L'arrel quadrada d'un nombre negatiu: no hi ha valor real. */
class SenseValorReal extends Error {}

const LECTURA = {variables: ['x', 'y'], funcions: ['f', "f'", "f''"]};

/**
 * Prepara un costat d'una igualtat: torna una funció entorn → Fraccio.
 * «(…)'» és la derivada de l'expressió de dins, calculada amb la fórmula
 * dels cinc punts, que és exacta per als polinomis de grau 4 o menys:
 *   g'(x) = [−g(x+2) + 8·g(x+1) − 8·g(x−1) + g(x−2)] / 12.
 */
function costat(text) {
  const derivada = /^\((.*)\)'$/.exec(text);
  const arbre = M.llegeix(derivada ? derivada[1] : text, LECTURA);
  if (!derivada) return entorn => exacte(arbre, entorn);
  return entorn => {
    const x = entorn.variables.x;
    const g = h => exacte(arbre, {variables: Object.assign({}, entorn.variables, {x: x.suma(h)}), funcions: entorn.funcions});
    return g(2).oposada().suma(g(1).producte(8)).resta(g(-1).producte(8)).suma(g(-2)).quocient(12);
  };
}

/** Polinomi exacte a partir dels coeficients [a0, a1, a2, …] (regla de Horner). */
const polinomiExacte = coefs => t => coefs.reduceRight((s, a) => s.producte(t).suma(a), fr(0));

/*
 * Punts on es comprova cada igualtat. Dos polinomis de grau 3 o menys que
 * coincideixen en 4 punts són iguals: quatre punts ja són una demostració.
 */
const PUNTS = [fr(-2), fr(0), fr(1), fr(5, 2)];


/* ── 1. MATES.JS I FORMULES.JS ─────────────────────────────────────── */

console.log('Proves dels procediments');

seccio('mates.js i formules.js', () => {
  // Fraccions
  comprova(fr(2, 4).igual(fr(1, 2)), '2/4 = 1/2');
  comprova(fr(1, -2).num === -1 && fr(1, -2).den === 2, 'el denominador queda positiu');
  comprova(Object.is(fr(0, -3).num, 0), 'el zero no té signe');
  comprova(fr(1, 2).suma(fr(1, 3)).igual(fr(5, 6)), '1/2 + 1/3 = 5/6');
  comprova(fr(-2, 3).potencia(3).igual(fr(-8, 27)), '(−2/3)³ = −8/27');
  comprova(fr(3, 4).quocient(fr(-3, 2)).igual(fr(-1, 2)), '(3/4) : (−3/2) = −1/2');
  comprova((() => { try { fr(1, 0); return false; } catch (e) { return e instanceof RangeError; } })(), '1/0 llança RangeError');

  // Lectura de polinomis
  const coefs = text => textCoefs(M.polinomi(M.llegeix(text)));
  for (const [text, esperat] of [
    ['2x^2-3x+1', '1 -3 2'], ['x(x-5)', '0 -5 1'], ['(x+1)^2', '1 2 1'], ['-x^2', '0 0 -1'],
    ['2x²−3x+1', '1 -3 2'], ['0,5x', '0 1/2'], ['x/2', '0 1/2'], ['3·x', '0 3'], ['2^3^2', '512'],
    ['-2^2', '-4'], ['(x-1)(x+1)', '-1 0 1'], ['x^0', '1'], ['x-x', ''], ['  x  ', '0 1'],
    ['(1/2)x^2-(3/4)x', '0 -3/4 1/2'], ['2(x+1)^3', '2 6 6 2'], ['x·x·x', '0 0 0 1'],
    ['1/x', null], ['ln(x)', null], ['x^(-1)', null], ['x^(1/2)', null], ['e*x', null], ['2^x', null], ['sqrt(4)', null],
  ]) comprova(coefs(text) === esperat, () => `polinomi(«${text}») hauria de ser «${esperat}» i és «${coefs(text)}»`);

  // Errors de lectura, amb el missatge per a l'alumne
  for (const [text, patro] of [
    ['2x^^2', /abans de «\^»/], ['lnx', /entre parèntesis/], ['x2', /Falta un signe/], ['(x+1', /Falta tancar/],
    ['', /No hi ha cap expressió/], ['y', /No conec «y»/], ['1234567890123', /massa llarg/], ['x)', /de més/],
    ['2x+', /massa aviat/], ['2x$', /No entenc el símbol/], ['.', /punt decimal/], ["g'(x)", /No entenc «g'»/],
  ]) comprova(errorDeLectura(() => M.llegeix(text), patro), `llegeix(«${text}») hauria de donar l'error ${patro}`);

  // Nombres
  comprova(M.llegeixNombre('-2').igual(-2), 'llegeixNombre(«-2»)');
  comprova(M.llegeixNombre('1/2').igual(fr(1, 2)), 'llegeixNombre(«1/2»)');
  comprova(M.llegeixNombre('0,5').igual(fr(1, 2)), 'llegeixNombre(«0,5»)');
  comprova(M.llegeixNombre('(3)').igual(3), 'llegeixNombre(«(3)»)');
  comprova(M.llegeixNombre('−3').igual(-3), 'llegeixNombre(«−3») amb el menys tipogràfic');
  comprova(errorDeLectura(() => M.llegeixNombre('x'), /només hi pot haver un nombre/), 'llegeixNombre(«x») és un error');
  comprova(errorDeLectura(() => M.llegeixNombre('1/0'), /No és un nombre racional/), 'llegeixNombre(«1/0») és un error');

  // Avaluació numèrica
  comprova(M.avalua(M.llegeix('2x^2-3x+1'), {variables: {x: 2}}) === 3, 'avalua 2x²−3x+1 en x = 2');
  comprova(M.avalua(M.llegeix("f'(2)+f(x)", {funcions: ['f', "f'"]}), {variables: {x: 1}, funcions: {f: t => t * t, "f'": t => 2 * t}}) === 5,
    "avalua f'(2) + f(x) amb funcions de l'usuari");

  // Escriptura
  comprova(M.texNombre(fr(-1, 2)) === '-\\frac{1}{2}', 'texNombre(−1/2)');
  comprova(M.texEntreParentesis(-2) === '(-2)' && M.texEntreParentesis(3) === '3', 'texEntreParentesis');
  comprova(M.texPolinomi(M.termes([1, -3, 2])) === '2x^{2} - 3x + 1', 'texPolinomi(2x²−3x+1)');
  comprova(M.textPolinomi(M.termes([fr(1, 2), 0, -1])) === '-x^2+(1/2)', 'textPolinomi(−x²+1/2)');
  comprova(M.textPolinomi([]) === '0' && M.texPolinomi([]) === '0', 'el polinomi zero s\'escriu «0»');

  // Anada i tornada: coeficients → text → coeficients; i les dues escriptures TeX diuen el mateix
  const valors = [-2, -1, 0, 1, 3, fr(1, 2), fr(-3, 4)];
  for (const a of valors) for (const b of valors) for (const c of valors) for (const d of valors) {
    const coeficients = [a, b, c, d].map(v => Fraccio.de(v));
    const esperat = textCoefs(coeficients.slice(0, coeficients.map(v => !v.esZero()).lastIndexOf(true) + 1));
    const t = M.termes(coeficients);
    comprova(textCoefs(M.polinomi(M.llegeix(M.textPolinomi(t)))) === esperat, () => `anada i tornada de «${M.textPolinomi(t)}»`);
    if (t.length) {
      comprova(textCoefs(M.polinomi(M.llegeix(textPla(F.polinomi('P', t))))) === esperat, () => `Formules.polinomi de «${M.textPolinomi(t)}»`);
      comprova(textCoefs(M.polinomi(M.llegeix(textPla(M.texPolinomi(t))))) === esperat, () => `Mates.texPolinomi de «${M.textPolinomi(t)}»`);
    }
  }

  // Claus i guió
  comprova((() => { try { F.clau('a-b', 'x'); return false; } catch (e) { return true; } })(), 'una clau amb «-» no és vàlida');
  comprova(F.marcat('q4: ⟦a:a⟧ + ⟦b:b⟧ = ⟦r:2⟧') === F.clau('q4a', 'a') + ' + ' + F.clau('q4b', 'b') + ' ' + F.rel('q4q', '=') + ' ' + F.clau('q4r', '2'),
    'marcat: prefix, claus i «=» amb clau');
  comprova(F.marcat('⟦x:3⟧ ⟦m:-⟧ ⟦y:1⟧ = 2') === F.clau('x', '3') + ' ' + F.op('m', '-') + ' ' + F.clau('y', '1') + ' = 2', 'marcat: sense prefix, operador amb clau');
  comprova(clausDe(F.marcat('q5: ⟦e:24a + 4b⟧ = ⟦r:0⟧')).join() === 'q5e,q5q,q5r', 'marcat: claus en ordre');
  for (const dolent of ['q1: a = b = c', 'q1: ⟦a:a = ⟦r:2⟧', 'q1: ⟦a-b:a⟧ = 0', 'q1: a ⟧ = 0']) {
    comprova((() => { try { F.marcat(dolent); return false; } catch (e) { return true; } })(), `marcat(«${dolent}») hauria de fallar`);
  }
  const g = F.guio(1);
  g.files[0] = 'x';
  g.afegeix('u');
  g.afegeix('dos');                                   // idèntic: no s'afegeix
  g.classes[0] = 'final';
  g.afegeix('tres');                                  // canvia la classe: s'afegeix
  comprova(g.passos.length === 2 && Object.isFrozen(g.passos[0]), 'el guió no repeteix passos idèntics');
});


/* ── 2. ADREÇA DE LA RECTA TANGENT ─────────────────────────────────── */

seccio('adreça de recta-tangent', () => {
  const lectura = p => RT.llegeixAdreca(p);
  const dades = (a3, a2, a1, a0, x0, m = 1, mode = 'tangent') => ({a3, a2, a1, a0, x0, m, mode});

  for (const [p, esperat] of [
    [{f: '2x^2-3x+1', x0: '2'}, dades(0, 2, -3, 1, 2)],
    [{f: 'x(x-5)', x0: '-1'}, dades(0, 1, -5, 0, -1)],
    [{f: 'x^3 - 3x + 1'}, dades(1, 0, -3, 1, 2)],
    [{f: '−x³+3x²−2', x0: '3'}, dades(-1, 3, 0, -2, 3)],
    [{f: '(x-1)^3', x0: '0'}, dades(1, -3, 3, -1, 0)],
    [{x0: '-5'}, dades(0, 2, -3, 1, -5)],
    [{}, dades(0, 2, -3, 1, 2)],
    [{f: 'x^2-4x+5', x0: '3', recta: 'normal'}, dades(0, 1, -4, 5, 3, 1, 'normal')],
    [{f: 'x^3-3x', m: '9'}, dades(1, 0, -3, 0, 2, 9, 'pendent')],
    [{f: 'x^2-4x+1', m: '-2', x0: '4'}, dades(0, 1, -4, 1, 4, -2, 'pendent')],
  ]) comprova(iguals(lectura(p).valors, esperat), () => `llegeixAdreca(${JSON.stringify(p)}) → ${JSON.stringify(lectura(p))}`);

  for (const [p, patro] of [
    [{recta: 'secant'}, /pot ser «tangent» o «normal»/], [{m: '1', recta: 'normal'}, /alhora/], [{m: '1/2'}, /pendent de l'adreça/],
    [{f: '3x+1', m: '1'}, /posa algun terme de grau 2 o 3/], [{f: 'x^3', m: '2'}, /irracionals/], [{m: '10'}, /entre −9 i 9/],
    [{f: 'ln(x)'}, /no és un polinomi/], [{f: 'x^4'}, /de grau 4/], [{f: 'x/2'}, /no són enters/],
    [{f: '10x'}, /entre −9 i 9/], [{f: '5'}, /ha de dependre de x/], [{f: '2x^^2'}, /^No entenc l'adreça: Hi falta un nombre/],
    [{f: '2x 2'}, /Falta un signe/], [{x0: '1/2'}, /no és un nombre enter/], [{x0: '7'}, /entre −5 i 5/],
    [{x0: 'x'}, /^No entenc l'adreça/], [{f: ''}, /No hi ha cap expressió/],
  ]) comprova(patro.test(lectura(p).error || ''), () => `llegeixAdreca(${JSON.stringify(p)}) hauria de donar l'error ${patro}: ${JSON.stringify(lectura(p))}`);

  // Anada i tornada per a totes les funcions vàlides (el punt va canviant)
  let n = 0;
  for (let a3 = -9; a3 <= 9; a3++) for (let a2 = -9; a2 <= 9; a2++) for (let a1 = -9; a1 <= 9; a1++) for (let a0 = -9; a0 <= 9; a0++) {
    if (!a3 && !a2 && !a1) continue;
    const v = dades(a3, a2, a1, a0, (n++ % 11) - 5);
    const p = RT.escriuAdreca(v);
    comprova(iguals(lectura(p).valors, v), () => `anada i tornada de ${JSON.stringify(p)}`);
  }
  for (const v of RT.exemples) comprova(RT.valida(v) === null, () => `l'exemple ${JSON.stringify(v)} no és vàlid`);
  for (const v of RT.exemples) comprova(iguals(lectura(RT.escriuAdreca(v)).valors, v), () => `anada i tornada de l'exemple ${JSON.stringify(v)}`);
  return `${n} funcions`;
});


/* ── 3 i 4. GUIONS I VERITAT DE LA RECTA TANGENT ───────────────────── */

/**
 * Dades on es proven els guions: una graella densa, els extrems i una mostra aleatòria,
 * per a la recta tangent; i també la recta normal i les tangents d'un pendent donat.
 */
function casosRectaTangent() {
  const casos = [];
  const afegeix = (a3, a2, a1, a0, x0, mode = 'tangent', m = 1) => {
    const v = {a3, a2, a1, a0, x0, m, mode};
    if ((a3 || a2 || a1) && RT.valida(v) === null) casos.push(v);
  };
  const densos = [-3, -1, 0, 1, 2];
  for (const a3 of densos) for (const a2 of densos) for (const a1 of densos) for (const a0 of densos) {
    for (let x0 = -5; x0 <= 5; x0++) afegeix(a3, a2, a1, a0, x0);
    for (const x0 of [-2, 0, 1, 3]) afegeix(a3, a2, a1, a0, x0, 'normal');
    for (const m of [-9, -3, 0, 1, 2, 9]) afegeix(a3, a2, a1, a0, 2, 'pendent', m);
  }
  const extrems = [-9, 0, 9];
  for (const a3 of extrems) for (const a2 of extrems) for (const a1 of extrems) for (const a0 of extrems)
    for (const x0 of [-5, 0, 5]) { afegeix(a3, a2, a1, a0, x0); afegeix(a3, a2, a1, a0, x0, 'normal'); afegeix(a3, a2, a1, a0, x0, 'pendent', x0); }
  const atzar = aleatori(2026);
  const enter = (min, max) => min + Math.floor(atzar() * (max - min + 1));
  for (let i = 0; i < 3000; i++) afegeix(enter(-9, 9), enter(-9, 9), enter(-9, 9), enter(-9, 9), enter(-5, 5));
  for (let i = 0; i < 1500; i++) afegeix(enter(-9, 9), enter(-9, 9), enter(-9, 9), enter(-9, 9), enter(-5, 5), 'normal');
  for (let i = 0; i < 3000; i++) afegeix(enter(-3, 3), enter(-9, 9), enter(-9, 9), enter(-9, 9), 0, 'pendent', enter(-9, 9));
  return casos;
}

/**
 * Estructura d'un guió: claus vàlides i úniques a cada pas; i, a cada
 * transició, el cursor, les fusions i els canvis de nom només fan
 * servir símbols del pas anterior (A) i del pas nou (B).
 */
function comprovaGuio(passos, nFiles, nom) {
  comprova(passos.length >= 2, () => `${nom}: massa pocs passos`);
  let A = null, anterior = null;
  passos.forEach((pas, i) => {
    const on = `${nom}, pas ${i + 1}`;
    comprova(Array.isArray(pas.files) && pas.files.length === nFiles && pas.classes.length === nFiles, () => `${on}: nombre de files`);
    comprova(typeof pas.text === 'string' && pas.text.trim() && pas.text.split('$').length % 2 === 1, () => `${on}: text buit o amb «$» desaparellats`);
    const llista = pas.files.flatMap(clausDe);
    const B = new Set(llista);
    comprova(B.size === llista.length, () => `${on}: claus repetides (${llista.filter((k, j) => llista.indexOf(k) !== j)})`);
    comprova(llista.every(k => /^[A-Za-z][A-Za-z0-9]*$/.test(k)), () => `${on}: clau no vàlida`);
    if (anterior) {
      comprova(anterior.files.join('\n') !== pas.files.join('\n') || anterior.classes.join() !== pas.classes.join(), () => `${on}: idèntic a l'anterior`);
    }

    const reanomena = Object.entries(pas.reanomena || {});
    const fusiona = Object.entries(pas.fusiona || {});
    const cursor = pas.cursor || {};
    if (!A) {
      comprova(!reanomena.length && !fusiona.length && !cursor.clic && !cursor.arrossega, () => `${on}: el primer pas no pot animar res`);
    } else {
      for (const [kb, ka] of reanomena) {
        comprova(B.has(kb) && !A.has(kb), () => `${on}: reanomena ${kb}←${ka}: «${kb}» ha de ser nova`);
        comprova(A.has(ka) && !B.has(ka), () => `${on}: reanomena ${kb}←${ka}: «${ka}» ha de ser vella`);
      }
      const fonts = fusiona.flatMap(([, kas]) => kas);
      comprova(new Set(fonts).size === fonts.length, () => `${on}: un símbol es fusiona dues vegades`);
      for (const [kb, kas] of fusiona) {
        comprova(B.has(kb), () => `${on}: fusiona ${kb}: no és al pas nou`);
        for (const ka of kas) {
          comprova(A.has(ka) && !B.has(ka), () => `${on}: fusiona ${kb}←${ka}: «${ka}» ha de ser al pas anterior i no al nou`);
          comprova(!reanomena.some(([, v]) => v === ka), () => `${on}: «${ka}» es fusiona i es reanomena alhora`);
        }
      }
      if (cursor.clic) comprova(A.has(cursor.clic), () => `${on}: el cursor clica «${cursor.clic}», que no hi és`);
      if (cursor.arrossega) comprova(A.has(cursor.arrossega), () => `${on}: el cursor arrossega «${cursor.arrossega}», que no hi és`);
      if (cursor.fins) comprova(B.has(cursor.fins), () => `${on}: el cursor arrossega fins a «${cursor.fins}», que no hi és`);
    }
    A = B;
    anterior = pas;
  });
}

/**
 * Les rectes que ha de trobar el guió, calculades aquí: la tangent en x₀; la normal
 * (pendent −1/f'(x₀), o vertical si f'(x₀) = 0); o les tangents de pendent m, als
 * punts on f'(x) = m. [{x0, m}] o [{x0, vertical: true}].
 */
function rectesModel(v) {
  const df = polinomiExacte([v.a1, 2 * v.a2, 3 * v.a3].map(c => fr(c)));
  const mode = v.mode || 'tangent', x0 = fr(v.x0);
  if (mode === 'tangent') return [{x0, m: df(x0)}];
  if (mode === 'normal') return df(x0).esZero() ? [{x0, vertical: true}] : [{x0, m: fr(-1).quocient(df(x0))}];
  const sols = arrelsDe(retallaP([fr(v.a1 - v.m), fr(2 * v.a2), fr(3 * v.a3)]));
  return sols.map(a => ({x0: a, m: fr(v.m)}));
}

/**
 * Veritat: cada línia de cada pas és certa.
 *   · Fila 0 (pot tenir diverses línies): l'equació d'una de les rectes del model, amb
 *     x₀ substituït pel seu punt: s'ha de complir en els punts de la recta i no en un punt
 *     de fora. La normal vertical és «x = x₀»; «No n'hi ha cap» només si no n'hi ha.
 *     Si la normal és vertical, la fórmula general −1/f'(x₀) no s'hi pot aplicar: una
 *     línia que divideix per f'(x₀) = 0 s'accepta (és la fórmula, no un càlcul).
 *   · Fila 1: una identitat (els dos costats valen el mateix per a tota x).
 *   · Files 2 i 3 (variant del pendent): «f'(x) = m» tal com es planteja i, després,
 *     equacions amb les mateixes solucions que f'(x) = m (a la 3, la fila de treball;
 *     al final, les solucions en lila).
 * f(a) i f'(a) valen el que valen de veritat.
 */
function comprovaVeritat(passos, v, nom) {
  const f = polinomiExacte([v.a0, v.a1, v.a2, v.a3].map(c => fr(c)));
  const df = polinomiExacte([v.a1, 2 * v.a2, 3 * v.a3].map(c => fr(c)));
  const funcions = {f, "f'": df};
  const rectes = rectesModel(v);
  const solucions = conjunt(rectes.map(r => r.x0));
  let linies = 0;

  /** Cert si la línia (text pla) és la recta r. */
  function esLaRecta(pla, r) {
    const text = pla.replace(/x_0/g, `(${r.x0.num}/${r.x0.den})`);
    const [esquerre, dret] = text.split('=').map(costat);
    const certa = (x, y) => esquerre({variables: {x, y}, funcions}).igual(dret({variables: {x, y}, funcions}));
    if (r.vertical) return /^x=/.test(pla) && !pla.includes('y') && certa(r.x0, fr(0)) && certa(r.x0, fr(7)) && !certa(r.x0.suma(1), fr(0));
    const recta = x => f(r.x0).suma(r.m.producte(x.resta(r.x0)));
    return PUNTS.every(x => certa(x, recta(x))) && !certa(fr(1), recta(fr(1)).suma(1));
  }
  const liniesDe = tex => (tex.trim().startsWith('\\begin{array}') ? liniesDArray(tex) : [textPla(tex)]);

  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    for (const pla of liniesDe(tex)) {
      linies++;
      try {
        if (fila === 0) {
          if (pla === "«Non'hihacap.»") { comprova(!rectes.length, () => `${on}: diu que no n'hi ha cap, i n'hi ha`); continue; }
          if (pla.split('=').length !== 2) { comprova(false, () => `${on}: «${pla}» no és una igualtat`); continue; }
          let bona = false, inaplicable = false;
          for (const r of rectes) {
            if (esLaRecta(pla, r)) bona = true;
            // Normal vertical: la fórmula y − f(x₀) = −1/f'(x₀)·(x − x₀) no s'hi pot aplicar (divideix per f'(x₀) = 0).
            if (r.vertical && pla.includes('y') && pla.includes("f'")) {
              const text = pla.replace(/x_0/g, `(${r.x0.num}/${r.x0.den})`);
              try { text.split('=').map(costat).forEach(c => c({variables: {x: fr(1), y: fr(0)}, funcions})); } catch (e) {
                if (e instanceof RangeError) inaplicable = true; else throw e;
              }
            }
          }
          comprova(bona || inaplicable, () => `${on}: «${pla}» no és cap de les rectes (${rectes.map(r => r.vertical ? 'x = ' + r.x0.valor() : `pendent ${r.m.valor()} en ${r.x0.valor()}`)})`);
        } else if (fila >= 2) {
          comprova(v.mode === 'pendent', () => `${on}: la fila ${fila + 1} només es fa servir amb un pendent donat`);
          if (fila === 2 && pla === `f'(x)=${textPla(M.texNombre(fr(v.m)))}`) continue;     // tal com es planteja
          comprova(!pla.includes('f') && solucionsDeFila(pla) === solucions, () => `${on}: «${pla}» no és una equació equivalent a f'(x) = m`);
          const grupsT = grupsAmbClau(tex);
          const lila = [...tex.matchAll(/\\htmlData\{k=(\w+),marca=solucio\}\{/g)].map(q => exacte(M.llegeix(textPla(grupsT[q[1]].tex), LECTURA), {variables: {}, funcions: {}}));
          if (lila.length) comprova(conjunt(lila) === solucions, () => `${on}: en lila hi ha ${conjunt(lila)}, i les solucions són ${solucions}`);
        } else {
          const costats = pla.split('=');
          const identitat = !pla.includes('|') && !pla.includes('±') && costats.length >= 2 && (() => {
            const parts = costats.map(costat);
            return PUNTS.every(x => parts.every(p => p({variables: {x, y: fr(0)}, funcions}).igual(parts[0]({variables: {x, y: fr(0)}, funcions}))));
          })();
          comprova(identitat, () => `${on}: «${pla}» no és certa`);
        }
      } catch (e) {
        comprova(false, () => `${on}: no es pot llegir «${pla || tex}»: ${e.message}`);
      }
    }
  }));

  if (v.mode === 'pendent') {
    comprova(passos.some(q => q.files[2] && textPla(q.files[2]) === `f'(x)=${textPla(M.texNombre(fr(v.m)))}`), () => `${nom}: falta l'equació f'(x) = m tal com es planteja`);
    if (solucions) comprova(passos.some(q => [2, 3].some(f => (q.files[f] || '').includes('marca=solucio'))), () => `${nom}: les solucions de f'(x) = m no surten en lila`);
  }
  // L'últim pas és la resposta: una recta acabada (y = … sense f, o x = …) per a cada recta del model.
  const final = passos[passos.length - 1];
  const ls = liniesDe(final.files[0]);
  comprova(final.classes[0] === 'final', () => `${nom}: la resposta no està destacada`);
  if (!rectes.length) comprova(ls.length === 1 && ls[0] === "«Non'hihacap.»", () => `${nom}: la resposta hauria de dir que no n'hi ha cap`);
  else {
    comprova(ls.length === rectes.length && ls.every(l => /^(y=[^fy]+|x=[^xyf]+)$/.test(l)), () => `${nom}: la resposta no són ${rectes.length} rectes acabades: ${ls}`);
    comprova(rectes.every(r => ls.some(l => { try { return esLaRecta(l, r); } catch (e) { return false; } })), () => `${nom}: a la resposta hi falta alguna recta`);
  }
  return linies;
}

/* La secció de proves dels guions de la recta tangent s'executa al final: fa servir eines de les seccions 5 i 10. */


/* ── 5. EQUACIONS I EXTREMS RELATIUS ───────────────────────────────── */

/** Clau d'un conjunt de nombres, per comparar conjunts: «-1,2,7/3». */
const conjunt = valors => [...new Set(valors.map(v => v.num + (v.den === 1 ? '' : '/' + v.den)))]
  .sort((a, b) => M.llegeixNombre(a).resta(M.llegeixNombre(b)).signe()).join(',');

/**
 * Solucions reals de «p = 0» (coeficients de grau 0 cap amunt, grau ≤ 2),
 * calculades aquí mateix, sense Formules ni Mates.arrelsRacionals.
 */
function arrelsDe(p) {
  if (!p.length) throw new Error('l\'equació és 0 = 0');
  if (p.length === 1) return [];
  if (p.length === 2) return [p[0].oposada().quocient(p[1])];
  if (p.length > 3) throw new Error('grau més gran que 2');
  const [c, b, a] = p;
  const d = b.producte(b).resta(a.producte(c).producte(4));
  if (d.signe() < 0) return [];
  const r = M.arrelExacta(d);
  if (!r) return null;                                  // irracionals
  const arrels = [b.oposada().resta(r).quocient(a.producte(2)), b.oposada().suma(r).quocient(a.producte(2))];
  return r.esZero() ? arrels.slice(0, 1) : arrels;
}

/**
 * Solucions d'una fila que és una equació en x: «x^2-2x=0», «x(x-2)=0»,
 * «x=0|x-2=0» (| = «o»), «x=±sqrt(4)», «x=((2±sqrt(16))/(2))».
 */
function solucionsDeFila(pla) {
  const valors = [];
  for (const part of pla.split('|')) {
    const costats = part.split('=');
    if (costats.length !== 2) throw new Error(`«${part}» no és una equació`);
    const [esquerre, dret] = costats;
    if (part.includes('±')) {
      if (esquerre !== 'x') throw new Error(`«${part}»: amb ± hi ha d'haver x a l'esquerra`);
      for (const s of ['+', '-']) {
        try {
          valors.push(exacte(M.llegeix(dret.replace('±', s), LECTURA), {variables: {}, funcions: {}}));
        } catch (e) {
          if (!(e instanceof SenseValorReal)) throw e;
        }
      }
    } else {
      const p = M.polinomi(M.llegeix(`(${esquerre})-(${dret})`));
      if (!p) throw new Error(`«${part}» no és polinòmica`);
      const arrels = arrelsDe(p);
      if (!arrels) throw new Error(`«${part}» té solucions irracionals`);
      valors.push(...arrels);
    }
  }
  return conjunt(valors);
}

seccio('equacions de formules.js', () => {
  // arrelsRacionals
  for (const [coefs, esperat, irracionals] of [
    [[-3, 0, 1], '', true], [[-4, 0, 1], '-2,2', false], [[0, -2, 1], '0,2', false], [[1, -2, 1], '1', false],
    [[1, 0, 1], '', false], [[3, 2], '-3/2', false], [[5], '', false], [[1, 4, 3], '-1,-1/3', false],
  ]) {
    const r = M.arrelsRacionals(M.termes(coefs));
    comprova(conjunt(r.arrels) === esperat && r.irracionals === irracionals, () => `arrelsRacionals(${coefs}) → ${JSON.stringify(r)}`);
  }
  // resolPolinomi: totes les equacions a·x² + b·x + c = 0 amb coeficients entre −6 i 6 i solucions racionals.
  let n = 0;
  for (let a = -6; a <= 6; a++) for (let b = -6; b <= 6; b++) for (let c = -6; c <= 6; c++) {
    if (!a && !b) continue;
    const t = M.termes([c, b, a]);
    if (M.arrelsRacionals(t).irracionals) continue;
    n++;
    const nom = `${M.textPolinomi(t)} = 0`;
    const g = F.guio(1);
    const sol = F.resolPolinomi(g, 0, 'e', t, 'Resol.');
    const esperat = conjunt(arrelsDe([c, b, a].map(v => fr(v)).slice(0, a ? 3 : 2)));
    comprova(conjunt(sol.map(s => s.valor)) === esperat, () => `${nom}: solucions ${conjunt(sol.map(s => s.valor))}, i són ${esperat}`);
    if (g.passos.length > 1) comprovaGuio(g.passos, 1, nom);          // «x = 0» ja està resolta: un sol pas
    const ultim = g.passos[g.passos.length - 1].files[0];
    for (const s of sol) comprova(clausDe(ultim).includes(s.clau), () => `${nom}: la clau ${s.clau} no és a l'última fila`);
    for (const [i, pas] of g.passos.entries()) {
      try {
        comprova(solucionsDeFila(textPla(pas.files[0])) === esperat, () => `${nom}, pas ${i + 1}: «${textPla(pas.files[0])}» no és equivalent`);
      } catch (e) {
        comprova(false, () => `${nom}, pas ${i + 1}: ${e.message}`);
      }
    }
  }
  // resolEquacio: l'equació es queda a la fila 0 (sempre equivalent) i els càlculs baixen a la 1 (sempre equivalents);
  // un producte, amb «·»; al final, en lila, les solucions que serveixen, i tatxades les altres (aquí, les negatives).
  let m = 0;
  for (let a = -4; a <= 4; a++) for (let b = -6; b <= 6; b++) for (let c = -6; c <= 6; c++) {
    if (!a && !b) continue;
    const t = M.termes([c, b, a]);
    if (M.arrelsRacionals(t).irracionals) continue;
    m++;
    const nom = `resolEquacio: ${M.textPolinomi(t)} = 0`;
    const g = F.guio(2);
    const sol = F.resolEquacio(g, {fila: 0, treball: 1, P: 'e', termes: t, text: 'Resol.', lila: true, serveix: x => x.signe() >= 0});
    const esperat = conjunt(arrelsDe([c, b, a].map(v => fr(v)).slice(0, a ? 3 : 2)));
    comprova(conjunt(sol.map(s_ => s_.valor)) === esperat, () => `${nom}: solucions ${conjunt(sol.map(s_ => s_.valor))}, i són ${esperat}`);
    g.passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
      if (!tex) return;
      const {net, tatxades} = separaTatxades(tex);
      const pla = textPla(net);
      try {
        comprova(solucionsDeFila(pla) === esperat, () => `${nom}, pas ${i + 1}, fila ${fila + 1}: «${pla}» no és equivalent`);
      } catch (e) {
        comprova(false, () => `${nom}, pas ${i + 1}: ${e.message}`);
      }
      comprova(!/(\)|[a-z])\(/.test(pla.replace(/sqrt\(/g, '√[')), () => `${nom}: «${pla}»: el producte s'escriu amb «·»`);
      tatxades.forEach(q => comprova(M.llegeixNombre(textPla(q).split('=')[1]).signe() < 0, () => `${nom}: s'ha tatxat «${textPla(q)}»`));
    }));
    if (g.passos.length > 1) comprova(Boolean(g.passos[1].files[0]), () => `${nom}: l'equació no es queda a la seva fila`);
    const ultim = g.passos[g.passos.length - 1];
    if (sol.length) {
      const lila = ultim.files.flatMap(tex => [...tex.matchAll(/\\htmlData\{k=(\w+),marca=solucio\}\{/g)].map(q => M.llegeixNombre(textPla(grupsAmbClau(tex)[q[1]].tex))));
      comprova(conjunt(lila) === conjunt(sol.map(s_ => s_.valor).filter(x => x.signe() >= 0)), () => `${nom}: en lila hi ha ${conjunt(lila)}`);
    }
  }
  return `${n} equacions, ${m} amb resolEquacio`;
});

seccio('adreça de extrems', () => {
  const E = arrel => Extrems.llegeixAdreca(arrel);
  const dades = (a3, a2, a1, a0) => ({a3, a2, a1, a0});
  for (const [p, esperat] of [
    [{f: 'x^3-3x^2+1'}, dades(1, -3, 0, 1)], [{f: 'x^3-3x^2-9x+1'}, dades(1, -3, -9, 1)], [{}, dades(1, -3, 0, 1)],
    [{f: 'x(x-2)'}, dades(0, 1, -2, 0)], [{f: '3x+1'}, dades(0, 0, 3, 1)],
  ]) comprova(iguals(E(p).valors, esperat), () => `Extrems.llegeixAdreca(${JSON.stringify(p)}) → ${JSON.stringify(E(p))}`);
  for (const [p, patro] of [
    [{f: 'x^3-2x'}, /irracionals/], [{f: '5'}, /ha de dependre de x/], [{f: 'ln(x)'}, /no és un polinomi/], [{f: 'x^4'}, /de grau 4/], [{f: '2x^^2'}, /^No entenc l'adreça/],
  ]) comprova(patro.test(E(p).error || ''), () => `Extrems.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(E(p))}`);
  for (const v of Extrems.exemples) comprova(Extrems.valida(v) === null, () => `l'exemple ${JSON.stringify(v)} no és vàlid`);
  let n = 0;
  for (let a3 = -9; a3 <= 9; a3++) for (let a2 = -9; a2 <= 9; a2++) for (let a1 = -9; a1 <= 9; a1++) for (const a0 of [-7, 0, 4]) {
    const v = dades(a3, a2, a1, a0);
    if (Extrems.valida(v)) continue;
    n++;
    comprova(iguals(E(Extrems.escriuAdreca(v)).valors, v), () => `anada i tornada de ${JSON.stringify(Extrems.escriuAdreca(v))}`);
  }
  return `${n} funcions vàlides`;
});

/**
 * Veritat d'un guió d'extrems. Files 0 i 1: identitats (f, f', f'' amb el
 * seu valor de veritat), amb un «< 0» o «> 0» final que també es comprova;
 * a la fila 1, una equació en x ha de tenir exactament els punts crítics
 * com a solucions. Files 2 i 3: un candidat (un punt crític, claus Kv…),
 * la conclusió, que es comprova amb f, f' i f'', o (fila 2, mentre es
 * resol f'(x) = 0) la fila de treball: una equació amb les mateixes
 * solucions, i al final els punts crítics en lila.
 */
function comprovaExtrems(passos, v, nom) {
  const coefs = [v.a0, v.a1, v.a2, v.a3].map(c => fr(c));
  const f = polinomiExacte(coefs), d1 = polinomiExacte([v.a1, 2 * v.a2, 3 * v.a3].map(c => fr(c))), d2 = polinomiExacte([2 * v.a2, 6 * v.a3].map(c => fr(c)));
  const funcions = {f, "f'": d1, "f''": d2};
  const p1 = [v.a1, 2 * v.a2, 3 * v.a3].map(c => fr(c));
  while (p1.length && p1[p1.length - 1].esZero()) p1.pop();
  const critics = conjunt(arrelsDe(p1));
  const valor = text => exacte(M.llegeix(text, LECTURA), {variables: {}, funcions});
  let linies = 0;

  const identitat = (pla, on) => {
    const relacio = /^(.*)([<>])0$/.exec(pla);
    const parts = (relacio ? relacio[1] : pla).split('=').map(costat);
    const valors = PUNTS.map(x => parts.map(p => p({variables: {x, y: fr(0)}, funcions})));
    comprova(valors.every(vs => vs.every(w => w.igual(vs[0]))), () => `${on}: «${pla}» no és certa`);
    if (relacio) comprova(valors[0][0].signe() === (relacio[2] === '<' ? -1 : 1), () => `${on}: «${pla}»: el signe no és correcte`);
  };

  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    let pla = '';
    try {
      pla = textPla(tex);
      linies++;
      if (fila <= 1) {
        if (fila === 1 && pla === "f'(x)=0") return;      // l'equació dels punts crítics, tal com es planteja
        if (pla.includes('f')) identitat(pla, on);
        else comprova(solucionsDeFila(pla) === critics, () => `${on}: «${pla}» no té per solucions els punts crítics (${critics})`);
        return;
      }
      let m;
      if (tex.includes('{k=Kv') && (m = /^x=(.+)$/.exec(pla))) {
        comprova(conjunt([valor(m[1])]) !== '' && critics.split(',').includes(conjunt([valor(m[1])])), () => `${on}: «${pla}» no és un punt crític`);
      } else if (fila === 2 && !pla.startsWith('«')) {
        // La fila de treball de f'(x) = 0: sempre les mateixes solucions; les marcades en lila, punts crítics.
        comprova(solucionsDeFila(pla) === critics, () => `${on}: «${pla}» no té per solucions els punts crítics (${critics})`);
        const grupsT = grupsAmbClau(tex);
        const lila = [...tex.matchAll(/\\htmlData\{k=(\w+),marca=solucio\}\{/g)].map(q => valor(textPla(grupsT[q[1]].tex)));
        if (lila.length) comprova(conjunt(lila) === critics, () => `${on}: en lila hi ha ${conjunt(lila)}, i els punts crítics són ${critics}`);
      } else if ((m = /^«(Màxim|Mínim)relatiu:»\((.+),(.+)\)$/.exec(pla))) {
        const a = valor(m[2]), b = valor(m[3]);
        comprova(d1(a).esZero() && f(a).igual(b) && d2(a).signe() === (m[1] === 'Màxim' ? -1 : 1), () => `${on}: «${pla}» és fals`);
      } else if ((m = /^«Nimàximnimínimen»x=(.+)$/.exec(pla))) {
        const a = valor(m[1]);
        comprova(d1(a).esZero() && d2(a).esZero() && v.a3 !== 0, () => `${on}: «${pla}» és fals`);   // f''' = 6·a3 ≠ 0: inflexió
      } else if (pla === '«Nohihapuntscrítics,ipertantnohihaextremsrelatius»') {
        comprova(critics === '', () => `${on}: diu que no hi ha punts crítics, i n'hi ha (${critics})`);
      } else {
        comprova(false, () => `${on}: fila no prevista: «${pla}»`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${pla || tex}»: ${e.message}`);
    }
  }));

  if (critics !== '') comprova(passos.some(q => [1, 2].some(f => (q.files[f] || '').includes('marca=solucio'))), () => `${nom}: els punts crítics no surten mai en lila`);
  comprova(passos.some(q => q.files[1] && textPla(q.files[1]) === "f'(x)=0"), () => `${nom}: falta l'equació f'(x) = 0 tal com es planteja`);
  // L'últim pas: una conclusió per a cada punt crític, i cap més.
  const final = passos[passos.length - 1].files.slice(2).filter(Boolean).map(textPla);
  const xs = final.map(pla => (/x=(.+)$/.exec(pla) || /\((.+),/.exec(pla) || [])[1]).filter(Boolean).map(valor);
  comprova(critics === '' ? final.length === 1 : conjunt(xs) === critics && final.length === xs.length && final.every(pla => pla.startsWith('«')),
    () => `${nom}: el resultat final no correspon als punts crítics (${critics}): ${final}`);
  return linies;
}

seccio('guions i veritat de extrems', () => {
  const casos = [];
  const afegeix = (a3, a2, a1, a0) => casos.push({a3, a2, a1, a0});
  for (let a3 = -3; a3 <= 3; a3++) for (let a2 = -3; a2 <= 3; a2++) for (let a1 = -3; a1 <= 3; a1++) for (let a0 = -3; a0 <= 3; a0++) afegeix(a3, a2, a1, a0);
  for (const a3 of [-9, 0, 9]) for (const a2 of [-9, 0, 9]) for (const a1 of [-9, 0, 9]) for (const a0 of [-9, 0, 9]) afegeix(a3, a2, a1, a0);
  const atzar = aleatori(2027);
  const enter = () => Math.floor(atzar() * 19) - 9;
  for (let i = 0; i < 6000; i++) afegeix(enter(), enter(), enter(), enter());

  let valids = 0, linies = 0, passos = 0, maxim = 0;
  for (const v of casos) {
    const nom = `f = ${Dd.textFuncio(v)}`;
    const error = Extrems.valida(v);
    const p1 = [v.a1, 2 * v.a2, 3 * v.a3].map(c => fr(c));
    while (p1.length && p1[p1.length - 1].esZero()) p1.pop();
    const irracional = p1.length > 0 && arrelsDe(p1) === null;
    comprova(Boolean(error) === (!p1.length || irracional), () => `${nom}: valida() diu «${error}»`);
    if (error) continue;
    valids++;
    let llista;
    try {
      llista = Extrems.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.message}`);
      continue;
    }
    comprovaGuio(llista, Extrems.files, nom);
    linies += comprovaExtrems(llista, v, nom);
    passos += llista.length;
    maxim = Math.max(maxim, llista.length);
  }
  return `${valids} casos vàlids (de ${casos.length}), ${passos} passos (fins a ${maxim} per cas), ${linies} línies comprovades`;
});


/* ── 6. CREIXEMENT I DECREIXEMENT ──────────────────────────────────── */

/* Polinomis com a coeficients Fraccio de grau 0 cap amunt, calculats aquí mateix. */
const retallaP = p => { const q = p.slice(); while (q.length && q[q.length - 1].esZero()) q.pop(); return q; };
const sumaP = (a, b) => retallaP(Array.from({length: Math.max(a.length, b.length)}, (_, i) => (a[i] || fr(0)).suma(b[i] || fr(0))));
const producteP = (a, b) => retallaP(a.length && b.length
  ? Array.from({length: a.length + b.length - 1}, (_, k) => a.reduce((s, c, i) => (k - i >= 0 && k - i < b.length ? s.suma(c.producte(b[k - i])) : s), fr(0)))
  : []);
const derivadaP = a => retallaP(a.slice(1).map((c, i) => c.producte(i + 1)));

/** Files i cel·les d'una taula «\begin{array}{…} … \end{array}», ja en text pla. */
function cellesDeTaula(tex) {
  const m = /^\\begin\{array\}\{[^}]*\}(.*)\\end\{array\}$/.exec(tex.trim());
  if (!m) throw new Error('no és una taula');
  return m[1].split('\\\\').map(fila => fila.replace(/\\hline/g, '').replace(/^\[[^\]]*\]/, '').split('&').map(c => textPla(c.trim())));
}

/** Extrem d'un interval: «-∞», «+∞» o un nombre. */
const extrem = (text, valor) => (text === '-∞' || text === '+∞' ? text : conjunt([valor(text)]));

/**
 * Veritat d'un guió de creixement. Fila 0: el domini. Fila 1: identitats
 * (f, f'). Fila 2: equacions amb les solucions de Q = 0 (abans de la
 * derivada) o del numerador de f' = 0 (després, primer «f'(x) = 0» i, si f
 * és un quocient, la fracció igualada a 0), o un valor de prova amb el seu
 * signe. Fila 3: mentre es resol una equació, la fila de treball (les
 * mateixes solucions; en lila, les que valen; tatxades, les de fora del
 * domini); després, la taula: capçalera completa (cada interval i cada punt
 * «x = a») i cada cel·la, si no és buida, correcta. Fila 4: la conclusió.
 */
function comprovaCreixement(passos, v, nom) {
  const P = retallaP([v.p0, v.p1, v.p2, v.p3].map(c => fr(c))), Q = retallaP([v.q0, v.q1, v.q2].map(c => fr(c)));
  const N = sumaP(producteP(derivadaP(P), Q), producteP(P, derivadaP(Q)).map(c => c.oposada()));
  const val = p => x => p.reduceRight((s, c) => s.producte(x).suma(c), fr(0));
  const f = x => val(P)(x).quocient(val(Q)(x));
  const df = x => val(N)(x).quocient(val(Q)(x).potencia(2));
  const funcions = {f, "f'": df};
  const arrelsQ = Q.length > 1 ? arrelsDe(Q) : [];
  const domini = conjunt(arrelsQ);
  const fora = x => arrelsQ.some(r => r.igual(x));
  const critics = arrelsDe(N).filter(r => !fora(r));
  const punts = arrelsQ.concat(critics).sort((a, b) => a.resta(b).signe());
  const nI = punts.length + 1;
  // Un punt de cada interval, per saber-ne el signe.
  const interior = j => (nI === 1 ? fr(0) : j === 0 ? punts[0].resta(1) : j === nI - 1 ? punts[nI - 2].suma(1) : punts[j - 1].suma(punts[j]).quocient(2));
  const signes = Array.from({length: nI}, (_, j) => val(N)(interior(j)).signe());
  const intervals = s => signes.map((x, j) => (x === s ? j : null)).filter(j => j !== null);
  const PUNTS_R = [-7, -5, -3, -1, 1, 3, 5, 7, 9, 11, -9, 13].map(k => fr(k, 4)).concat([fr(-7, 3), fr(5, 3)]).filter(x => !val(Q)(x).esZero());
  const valor = text => exacte(M.llegeix(text, LECTURA), {variables: {}, funcions});
  let linies = 0;

  const comprovaInterval = (text, j, on) => {
    const m = /^\((.+),(.+)\)$/.exec(text);
    const esperat = [j === 0 ? '-∞' : conjunt([punts[j - 1]]), j === nI - 1 ? '+∞' : conjunt([punts[j]])];
    comprova(m && extrem(m[1], valor) === esperat[0] && extrem(m[2], valor) === esperat[1], () => `${on}: interval «${text}» en lloc de (${esperat})`);
  };

  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      if (fila === 0) {
        const m = /^«Dom»f=ℝ(?:-\{(.+)\})?$/.exec(textPla(tex));
        comprova(m && conjunt(m[1] ? m[1].split(',').map(valor) : []) === domini, () => `${on}: domini «${textPla(tex)}» en lloc de ℝ − {${domini}}`);
      } else if (fila === 2 && !tex.includes('\\cancel') && textPla(tex) === "f'(x)=0") {
        // l'equació dels punts crítics, tal com es planteja
      } else if (fila === 2 && tex.startsWith('\\dfrac')) {
        // f'(x) = 0 amb la fracció: el primer membre és f'(x)
        const [esq, dre] = textPla(tex).split('=');
        comprova(dre === '0' && PUNTS_R.every(x => costat(esq)({variables: {x, y: fr(0)}, funcions}).igual(df(x))), () => `${on}: «${textPla(tex)}» no és f'(x) = 0`);
      } else if ((fila === 3 && !tex.startsWith('\\begin{array}')) || (fila === 2 && /marca=solucio|\\cancel/.test(tex))) {
        // La fila de treball (o l'equació, si ja és la solució): les mateixes solucions que l'equació de la fila 2;
        // en lila, les que valen; tatxades, les de fora del domini.
        const {net, tatxades} = separaTatxades(tex);
        const derivada = Boolean(pas.files[1]);
        const objectiu = conjunt(derivada ? arrelsDe(N) : arrelsQ);
        comprova(solucionsDeFila(textPla(net)) === objectiu, () => `${on}: «${textPla(net)}» no té per solucions ${objectiu}`);
        const grupsT = grupsAmbClau(net);
        const lila = [...net.matchAll(/\\htmlData\{k=(\w+),marca=solucio\}\{/g)].map(q => valor(textPla(grupsT[q[1]].tex)));
        const ratllats = tatxades.map(t => valor(textPla(t).split('=')[1]));
        if (lila.length || ratllats.length) {
          comprova(conjunt(lila) === (derivada ? conjunt(critics) : domini), () => `${on}: en lila hi ha ${conjunt(lila)}`);
          comprova(derivada ? ratllats.every(fora) && conjunt(ratllats) === conjunt(arrelsDe(N).filter(fora)) : !ratllats.length,
            () => `${on}: les solucions tatxades (${conjunt(ratllats)}) han de ser les de fora del domini`);
        }
      } else if (fila === 1 || fila === 2) {
        const pla = textPla(tex);
        const relacio = /^(.*)([<>])0$/.exec(pla);
        if (relacio) {
          const parts = relacio[1].split('=').map(valor);
          comprova(parts.every(w => w.igual(parts[0])) && parts[0].signe() === (relacio[2] === '<' ? -1 : 1), () => `${on}: «${pla}» és fals`);
        } else if (pla.includes('f')) {
          const parts = pla.split('=').map(costat);
          comprova(PUNTS_R.length >= 10 && PUNTS_R.every(x => {
            const vs = parts.map(c => c({variables: {x, y: fr(0)}, funcions}));
            return vs.every(w => w.igual(vs[0]));
          }), () => `${on}: «${pla}» no és certa`);
        } else {
          const objectiu = conjunt(pas.files[1] ? arrelsDe(N) : arrelsQ);
          comprova(solucionsDeFila(pla) === objectiu, () => `${on}: «${pla}» no té per solucions ${objectiu}`);
        }
      } else if (fila === 3) {
        const [cap, derivada, funcio] = cellesDeTaula(tex);
        comprova(cap.length === 2 * nI && cap[0] === 'x' && derivada[0] === "f'(x)" && funcio[0] === 'f(x)', () => `${on}: forma de la taula`);
        for (let j = 0; j < nI; j++) {
          comprovaInterval(cap[1 + 2 * j], j, `${on}: capçalera de l'interval ${j + 1}`);
          const s = derivada[1 + 2 * j], fl = funcio[1 + 2 * j];
          comprova(s === '' || s === (signes[j] > 0 ? '+' : '-'), () => `${on}: signe de f' a l'interval ${j + 1}: «${s}»`);
          comprova(fl === '' || fl === (signes[j] > 0 ? '↗' : '↘'), () => `${on}: fletxa a l'interval ${j + 1}: «${fl}»`);
          if (j === nI - 1) break;
          const p = punts[j], cx = cap[2 + 2 * j], dp = derivada[2 + 2 * j], fp = funcio[2 + 2 * j];
          const c = cx.startsWith('x=') ? cx.slice(2) : '';
          comprova(c !== '' && conjunt([valor(c)]) === conjunt([p]), () => `${on}: punt ${j + 1}: «${cx}» (ha de ser «x = …»)`);
          const esperatF = fora(p) ? '∄'
            : signes[j] > 0 && signes[j + 1] < 0 ? '«màxim»' : signes[j] < 0 && signes[j + 1] > 0 ? '«mínim»' : '';          // sense abreviatures (David)
          comprova(dp === '' || dp === (fora(p) ? '∄' : '0'), () => `${on}: f' al punt ${c}: «${dp}»`);
          comprova(fp === '' || fp === esperatF, () => `${on}: f al punt ${c}: «${fp}» en lloc de «${esperatF}»`);
          if (fora(p)) comprova(val(Q)(p).esZero(), () => `${on}: Q(${c}) no és 0`);
          else comprova(df(p).esZero(), () => `${on}: f'(${c}) no és 0`);
        }
      } else {
        const [[creix], [decreix]] = cellesDeTaula(tex);
        for (const [text, prefix, s] of [[creix, '«Creixent:»', 1], [decreix, '«Decreixent:»', -1]]) {
          comprova(text.startsWith(prefix), () => `${on}: «${text}»`);
          const resta = text.slice(prefix.length);
          const js = intervals(s);
          if (!js.length) { comprova(resta === '«capinterval»', () => `${on}: «${text}» hauria de ser «cap interval»`); continue; }
          const parts = resta.split('∪');
          comprova(parts.length === js.length, () => `${on}: «${text}» no té ${js.length} intervals`);
          parts.forEach((t, k) => comprovaInterval(t, js[k], on));
        }
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex}»: ${e.message}`);
    }
  }));

  // Les solucions de les equacions surten en lila (les del denominador, abans de la derivada; els punts crítics, després).
  const lilaEn = q => [2, 3].some(f => (q.files[f] || '').includes('marca=solucio'));
  if (domini) comprova(passos.some(q => !q.files[1] && lilaEn(q)), () => `${nom}: les solucions de Q(x) = 0 no surten en lila`);
  if (critics.length) comprova(passos.some(q => q.files[1] && lilaEn(q)), () => `${nom}: els punts crítics no surten en lila`);
  comprova(passos.some(q => q.files[2] && !q.files[2].includes('\\cancel') && textPla(q.files[2]) === "f'(x)=0"), () => `${nom}: falta l'equació f'(x) = 0 tal com es planteja`);
  // Al final, la taula és completa i hi ha la conclusió.
  const final = passos[passos.length - 1];
  comprova(Boolean(final.files[4]), () => `${nom}: falta la conclusió`);
  const [, dFinal, fFinal] = cellesDeTaula(final.files[3]);
  const puntsSenseCanvi = punts.filter((p, j) => !fora(p) && signes[j] === signes[j + 1]).length;
  comprova(dFinal.every(c => c !== '') && fFinal.filter(c => c === '').length === puntsSenseCanvi,
    () => `${nom}: la taula final no és completa`);
  return linies;
}

seccio('adreça de creixement', () => {
  const C = p => Creixement.llegeixAdreca(p);
  const d = (p3, p2, p1, p0, q2, q1, q0) => ({p3, p2, p1, p0, q2, q1, q0});
  for (const [p, esperat] of [
    [{f: '(x^2+3)/(x-1)'}, d(0, 1, 0, 3, 0, 1, -1)], [{f: '-x/(2x+1)'}, d(0, 0, -1, 0, 0, 2, 1)], [{f: 'x^3-3x^2+1'}, d(1, -3, 0, 1, 0, 0, 1)], [{f: '1/x'}, d(0, 0, 0, 1, 0, 1, 0)],
    [{f: 'x/(x^2+1)'}, d(0, 0, 1, 0, 1, 0, 1)], [{f: '2x/(x+1)'}, d(0, 0, 2, 0, 0, 1, 1)], [{}, d(0, 1, 0, 3, 0, 1, -1)],
  ]) comprova(iguals(C(p).valors, esperat), () => `Creixement.llegeixAdreca(${JSON.stringify(p)}) → ${JSON.stringify(C(p))}`);
  for (const [p, patro] of [
    [{f: 'x^2/x^2-4'}, /ni un quocient/], [{f: '(x^2-1)/(x-1)'}, /factor comú/], [{f: '(x^2+1)/(2x^2+2)'}, /factor comú/],
    [{f: '1/(x^2-2)'}, /no són del domini són irracionals/], [{f: 'x^3/(x+1)'}, /grau 2 com a màxim/], [{f: '1/(x^3+1)'}, /grau massa alt/],
    [{f: 'x/2'}, /no són enters/], [{f: '5'}, /constant/], [{f: 'x^3-2x'}, /crítics són irracionals/], [{f: 'ln(x)'}, /ni un quocient/],
    [{f: '(x+1'}, /^No entenc l'adreça/],
  ]) comprova(patro.test(C(p).error || ''), () => `Creixement.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(C(p))}`);
  for (const v of Creixement.exemples) comprova(Creixement.valida(v) === null, () => `l'exemple ${JSON.stringify(v)} no és vàlid`);
});

seccio('guions i veritat de creixement', () => {
  const casos = [];
  const xs = [-2, -1, 0, 1, 2];
  for (const p2 of xs) for (const p1 of xs) for (const p0 of xs) for (const q2 of [-1, 0, 1]) for (const q1 of xs) for (const q0 of xs) {
    casos.push({p3: 0, p2, p1, p0, q2, q1, q0});
  }
  for (const p3 of [-2, -1, 1, 2]) for (const p2 of xs) for (const p1 of xs) for (const p0 of [-1, 0, 3]) casos.push({p3, p2, p1, p0, q2: 0, q1: 0, q0: 1});
  const atzar = aleatori(2028);
  const enter = () => Math.floor(atzar() * 19) - 9;
  for (let i = 0; i < 4000; i++) casos.push({p3: 0, p2: enter(), p1: enter(), p0: enter(), q2: enter(), q1: enter(), q0: enter()});

  let valids = 0, linies = 0, passos = 0, maxim = 0;
  for (const v of casos) {
    const error = Creixement.valida(v);
    if (error) continue;
    valids++;
    const nom = `f = ${Creixement.escriuAdreca(v).f}`;
    comprova(iguals(Creixement.llegeixAdreca(Creixement.escriuAdreca(v)).valors, v), () => `${nom}: l'anada i tornada per l'adreça no funciona`);
    let llista;
    try {
      llista = Creixement.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, Creixement.files, nom);
    linies += comprovaCreixement(llista, v, nom);
    passos += llista.length;
    maxim = Math.max(maxim, llista.length);
  }
  return `${valids} casos vàlids (de ${casos.length}), ${passos} passos (fins a ${maxim} per cas), ${linies} línies comprovades`;
});


/* ── 7. OPTIMITZACIÓ ───────────────────────────────────────────────── */

/*
 * Model de cada problema, escrit aquí de manera independent del guió:
 *   v, w, f     variable principal, l'altra i el nom de la funció
 *   O(v, w, π)  la funció amb dues variables;   W(v, π) l'altra variable aïllada de la condició
 *   d1, d2      la primera i la segona derivada de O(v, W(v)) (es comproven numèricament)
 *   domini      el domini, com el text pla de la pissarra
 *   optim(π)    el valor òptim de v;   maxim   cert si és un màxim
 *   mostres     valors de v dins del domini, diferents de l'òptim
 *   pis         valors de π amb què es prova (π fa d'indeterminada)
 */
const OPT = (() => {
  const q = (a, b = 1) => fr(a, b);
  const sense = [q(1)];
  return {
    hort: {v: 'x', w: 'y', f: 'A', maxim: true, domini: '0<x<20', mostres: [q(1), q(5), q(13, 2), q(19)], pis: sense,
      O: (x, y) => x.producte(y), W: x => q(40).resta(x.producte(2)),
      d1: x => q(40).resta(x.producte(4)), d2: () => q(-4), optim: () => q(10)},
    capsa: {v: 'x', w: 'b', f: 'V', maxim: true, domini: '0<x<6', mostres: [q(1, 2), q(1), q(3), q(5)], pis: sense,
      O: (x, b) => b.producte(b).producte(x), W: x => q(12).resta(x.producte(2)),
      d1: x => x.producte(x).producte(12).resta(x.producte(96)).suma(144), d2: x => x.producte(24).resta(96), optim: () => q(2)},
    llauna: {v: 'r', w: 'h', f: 'V', maxim: true, domini: '0<r<sqrt(27)', mostres: [q(1), q(2), q(5, 2), q(4), q(5)], pis: [q(3), q(22, 7)],
      O: (r, h, pi) => pi.producte(r).producte(r).producte(h), W: r => q(27).resta(r.producte(r)).quocient(r.producte(2)),
      d1: (r, pi) => pi.producte(27).resta(pi.producte(3).producte(r).producte(r)).quocient(2), d2: (r, pi) => pi.producte(-3).producte(r), optim: () => q(3)},
    diposit: {v: 'x', w: 'h', f: 'C', maxim: false, domini: 'x>0', mostres: [q(1, 2), q(1), q(3), q(5)], pis: sense,
      O: (x, h) => x.producte(x).producte(20).suma(x.producte(h).producte(40)), W: x => q(8).quocient(x.producte(x)),
      d1: x => x.producte(40).resta(q(320).quocient(x.producte(x))), d2: x => q(40).suma(q(640).quocient(x.potencia(3))), optim: () => q(2)},
    pista: {v: 'r', w: 'x', f: 'A', maxim: true, domini: '0<r<((200)/((pi)))', mostres: [q(10), q(20), q(40), q(50)], pis: [q(3), q(22, 7)],
      O: (r, x) => r.producte(x).producte(2), W: (r, pi) => q(200).resta(pi.producte(r)),
      d1: (r, pi) => q(400).resta(pi.producte(4).producte(r)), d2: (r, pi) => pi.producte(-4), optim: pi => q(100).quocient(pi)},
    nombres: {v: 'y', w: 'x', f: 'P', maxim: true, domini: '0<y<12', mostres: [q(1), q(3), q(10), q(11)], pis: sense,
      O: (y, x) => x.producte(y).producte(y), W: y => q(12).resta(y),
      d1: y => y.producte(24).resta(y.producte(y).producte(3)), d2: y => q(24).resta(y.producte(6)), optim: () => q(8)},
  };
})();

/** Veritat d'un guió d'optimització, per a un valor de π. */
function comprovaOptimitzacio(passos, model, pi, nom) {
  const {v, w, f} = model;
  const lectura = {variables: [v, w], funcions: [f, f + "'", f + "''"]};
  const W = x => model.W(x, pi);
  const funcio = x => model.O(x, W(x), pi);
  const funcions = {[f]: funcio, [f + "'"]: x => model.d1(x, pi), [f + "''"]: x => model.d2(x, pi)};
  const valor = (text, x = fr(0), y = fr(0)) => exacte(M.llegeix(text, lectura), {variables: {[v]: x, [w]: y, pi}, funcions});
  const optim = model.optim(pi);
  const totsIguals = vs => vs.every(a => a.igual(vs[0]));
  let linies = 0;

  const FILA = Optimitzacio.FILA;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex || fila === FILA.enunciat) return;                      // l'enunciat no és una igualtat
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    let pla = '';
    try {
      pla = textPla(separaTatxades(tex).net);                       // (les solucions tatxades es comproven a part)
      linies++;
      let m;
      if (fila === FILA.funcio) {
        if ((m = new RegExp(`^${f}=(.*)$`).exec(pla))) {                        // amb dues variables
          const parelles = model.mostres.map((x, k) => [x, fr(k + 2, 3)]);
          comprova(parelles.every(([x, y]) => valor(m[1], x, y).igual(model.O(x, y, pi))), () => `${on}: «${pla}» no és la funció`);
        } else {
          comprova(model.mostres.every(x => totsIguals(pla.split('=').map(part => valor(part, x)).concat([funcio(x)]))), () => `${on}: «${pla}» no és certa`);
        }
      } else if (fila === FILA.condicio) {
        if ((m = new RegExp(`^${w}=(.*)$`).exec(pla))) {
          comprova(model.mostres.every(x => valor(m[1], x).igual(W(x))), () => `${on}: «${pla}» no és la condició aïllada`);
        } else {
          const [esq, dre] = pla.split('=');
          const zero = (x, y) => valor(esq, x, y).resta(valor(dre, x, y));
          comprova(model.mostres.every(x => zero(x, W(x)).esZero() && !zero(x, W(x).suma(1)).esZero()), () => `${on}: «${pla}» no és equivalent a la condició`);
        }
      } else if (fila === FILA.domini) {
        comprova(pla === model.domini, () => `${on}: domini «${pla}» en lloc de «${model.domini}»`);
      } else if (fila === FILA.derivada) {
        comprova(model.mostres.every(x => totsIguals(pla.split('=').map(part => valor(part, x)))), () => `${on}: «${pla}» no és certa`);
      } else if (fila === FILA.resposta && !tex.includes('{k=R')) {
        // La fila de treball de f'(v) = 0 (abans de la resposta): equacions equivalents; en lila, l'òptim; tatxades,
        // les altres solucions de f'(v) = 0 (fora del domini).
        const {net, tatxades} = separaTatxades(tex);
        equacioDerivada(textPla(net), on);
        const grupsT = grupsAmbClau(net);
        const lila = [...net.matchAll(/\\htmlData\{k=(\w+),marca=solucio\}\{/g)].map(q => valor(textPla(grupsT[q[1]].tex)));
        comprova(lila.every(a => a.igual(optim)), () => `${on}: en lila hi ha d'haver només l'òptim`);
        const ratllats = tatxades.map(t => valor(textPla(t).split('=')[1]));
        ratllats.forEach(a => comprova(!a.igual(optim) && funcions[f + "'"](a).esZero(), () => `${on}: ${a.num}/${a.den} no s'havia de tatxar`));
        if (lila.length) {
          // Al pas de la lila, cada solució escrita és l'òptim (en lila) o una de tatxada.
          const parts = textPla(net).split('|').map(q => q.split('='));
          comprova(parts.every(([esq, dre]) => esq === v && (valor(dre).igual(optim) || ratllats.some(a => a.igual(valor(dre))))),
            () => `${on}: les solucions que no són l'òptim s'han de tatxar`);
        }
      } else if (fila === FILA.calcul) {
        equacioDerivada(pla, on);
      } else {
        for (const part of pla.split(',')) {
          const [nomPart, text] = part.split('=');
          const esperat = nomPart === v ? optim : nomPart === w ? W(optim) : nomPart === f ? funcio(optim) : null;
          comprova(esperat && valor(text).igual(esperat), () => `${on}: «${part}» no és la solució`);
        }
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${pla || tex}»: ${e.message}`);
    }
  }));
  /** Una fila de càlcul: «f''(…) = … < 0», una identitat amb f, f' o w, o una equació equivalent a f'(v) = 0. */
  function equacioDerivada(pla, on) {
    {
      {
        const relacio = /^(.*)([<>])0$/.exec(pla);
        if (relacio) {
          const parts = relacio[1].split('=').map(part => valor(part, optim));
          comprova(totsIguals(parts) && parts[0].signe() === (relacio[2] === '<' ? -1 : 1), () => `${on}: «${pla}» és fals`);
        } else if (pla.includes(f + '(') || pla.includes(f + "'") || pla.startsWith(w + '=')) {
          const parts = pla.split('=').map(part => (part === w ? W(optim) : valor(part, optim)));
          comprova(totsIguals(parts), () => `${on}: «${pla}» no és certa`);
        } else {
          const disjuncions = pla.split('|').map(part => part.split('='));
          const esExplicita = ([esq, dre]) => esq === v && !dre.replace(/sqrt|pi/g, '').includes(v);
          if (disjuncions.length > 1 || esExplicita(disjuncions[0])) {
            // Solucions escrites: cada part és «v = valor» (amb ± o no) o una equació polinòmica.
            const valors = disjuncions.flatMap(([esq, dre]) => {
              if (esExplicita([esq, dre])) return (dre.includes('±') ? [dre.replace('±', '+'), dre.replace('±', '-')] : [dre]).map(t => valor(t));
              const p = M.polinomi(M.llegeix(`(${esq})-(${dre})`, {variables: [v]}), v);
              if (!p) throw new Error(`«${esq}=${dre}» no és polinòmica`);
              return arrelsDe(p);
            });
            comprova(valors.some(a => a.igual(optim)) && valors.every(a => funcions[f + "'"](a).esZero()),
              () => `${on}: «${pla}»: les solucions no són les de ${f}'(${v}) = 0`);
          } else {
            const [esq, dre] = pla.split('=');
            const E = x => valor(esq, x).resta(valor(dre, x));
            comprova(E(optim).esZero() && model.mostres.every(x => !E(x).esZero() && !funcions[f + "'"](x).esZero()),
              () => `${on}: «${pla}» no és equivalent a ${f}'(${v}) = 0 dins del domini`);
          }
        }
      }
    }
  }
  const final = textPla(passos[passos.length - 1].files[FILA.resposta]).split(',').map(t => t.split('=')[0]);
  // L'equació dels candidats, primer tal com es planteja (David), i l'òptim en lila a la fila de treball.
  comprova(passos.some(q => q.files[FILA.calcul] && textPla(q.files[FILA.calcul]) === `${f}'(${v})=0`), () => `${nom}: falta l'equació ${f}'(${v}) = 0 abans de substituir`);
  comprova(passos.some(q => (q.files[FILA.resposta] || '').includes('marca=solucio')), () => `${nom}: el candidat no surt en lila`);
  // La lectura: al final, l'enunciat té frases marcades de les dues categories, i cap més marca.
  const enunciat = passos[passos.length - 1].files[FILA.enunciat];
  const marques = [...enunciat.matchAll(/\{\{[^|]*\|([^|]*)\|/g)].map(m => m[1]);
  comprova(enunciat.startsWith('§') && marques.includes('objectiu') && marques.includes('condicio') && marques.every(m => m === 'objectiu' || m === 'condicio'),
    () => `${nom}: l'enunciat no té les frases marcades (objectiu i condició)`);
  comprova(final.join() === [v, w, f].join(), () => `${nom}: la resposta final no té ${v}, ${w} i ${f}`);
  comprova(model.d2(optim, pi).signe() === (model.maxim ? -1 : 1), () => `${nom}: el model no té un ${model.maxim ? 'màxim' : 'mínim'}`);
  comprova(funcions[f + "'"](optim).esZero(), () => `${nom}: el model no té f' = 0 a l'òptim`);
  return linies;
}

seccio('optimització', () => {
  let linies = 0, passos = 0;
  for (const problema of Optimitzacio.problemes) {
    const model = OPT[problema.id];
    comprova(model && problema.v === model.v && problema.w === model.w && problema.f === model.f, () => `${problema.id}: no hi ha model, o no coincideix`);
    if (!model) continue;
    // El model es comprova a si mateix: les derivades, amb diferències finites.
    const h = fr(1, 16);
    for (const pi of model.pis) {
      const F0 = x => model.O(x, model.W(x, pi), pi), F1 = x => model.d1(x, pi), F2 = x => model.d2(x, pi);
      // Diferència central amb extrapolació de Richardson: error de l'ordre de h⁴.
      const central = (g, x, k) => g(x.suma(k)).resta(g(x.resta(k))).quocient(k.producte(2));
      const aprox = (g, x) => central(g, x, h.quocient(2)).producte(4).resta(central(g, x, h)).quocient(3).valor();
      const prop = (a, b) => Math.abs(a - b) < 1e-3 * Math.max(1, Math.abs(b));
      let fetes = 0;
      for (const x of model.mostres) {
        let parells;
        try {
          parells = [[aprox(F0, x), F1(x).valor()], [aprox(F1, x), F2(x).valor()]];
        } catch (e) {
          if (e instanceof RangeError) continue;     // fraccions massa grans: aquest punt no es pot fer exacte
          throw e;
        }
        fetes++;
        comprova(prop(...parells[0]), () => `${problema.id}: la primera derivada del model no quadra en ${x.valor()}`);
        comprova(prop(...parells[1]), () => `${problema.id}: la segona derivada del model no quadra en ${x.valor()}`);
      }
      comprova(fetes >= 2, () => `${problema.id}: el model no s'ha pogut comprovar`);
      const llista = Optimitzacio.passos({p: problema.id});
      comprovaGuio(llista, Optimitzacio.files, problema.id);
      linies += comprovaOptimitzacio(llista, model, pi, `${problema.id} (π = ${pi.num}/${pi.den})`);
      passos += llista.length;
    }
    comprova(iguals(Optimitzacio.llegeixAdreca(Optimitzacio.escriuAdreca({p: problema.id})).valors, {p: problema.id}), () => `${problema.id}: adreça`);
  }
  comprova(/no existeix/.test(Optimitzacio.llegeixAdreca({p: 'res'}).error || ''), 'problema inexistent a l\'adreça');
  return `${Optimitzacio.problemes.length} problemes, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 8. POLINOMI DE GRAU 3 A PARTIR DE CONDICIONS ──────────────────── */

/*
 * Model de cada problema, escrit aquí de manera independent del guió:
 *   condicions  [[ordre, x, valor], …]: f(x), f'(x) o f''(x) val «valor», en l'ordre de l'enunciat
 *   frases      quantes condicions dona cada frase de dades (2: es marca «×2»)
 *   extrems     [[x, 'maxim' | 'minim' | 'extrem'], …]     inflexions [x, …]
 *   solucio     [a, b, c, d]
 */
const PC = {
  ordenades: {condicions: [[0, 0, 4], [1, 0, 0], [1, 2, 0], [0, 1, 2]], frases: [1, 2, 1], extrems: [[0, 'extrem'], [2, 'extrem']], inflexions: [], solucio: [1, -3, 0, 4]},
  maxim: {condicions: [[0, 0, 0], [1, 1, 0], [0, 1, 2], [1, -1, 0]], frases: [1, 2, 1], extrems: [[1, 'maxim']], inflexions: [], solucio: [-1, 0, 3, 0]},
  tangent: {condicions: [[1, 1, 2], [0, 1, 1], [1, 0, 0], [0, -1, -3]], frases: [2, 1, 1], extrems: [[0, 'extrem']], inflexions: [], solucio: [2, -2, 0, 1]},
  inflexio: {condicions: [[2, 0, 0], [0, 0, 0], [0, 1, -2], [0, 2, 2]], frases: [2, 2], extrems: [], inflexions: [0], solucio: [1, 0, -3, 0]},
  beneficis: {condicions: [[0, 0, 0], [1, 2, 0], [0, 2, 20], [2, 3, 0]], frases: [1, 2, 1], extrems: [[2, 'maxim']], inflexions: [3], solucio: [1, -9, 24, 0]},
  maxmin: {condicions: [[1, 1, 0], [0, 1, 3], [1, 3, 0], [0, 3, -1]], frases: [2, 2], extrems: [[1, 'maxim'], [3, 'minim']], inflexions: [], solucio: [1, -6, 9, -1]},
};

/* f, f' i f'' amb els paràmetres u = [a, b, c, d] (Fraccio). */
const DERIVADES_PC = [
  ([a, b, c, d]) => t => a.producte(t.potencia(3)).suma(b.producte(t.potencia(2))).suma(c.producte(t)).suma(d),
  ([a, b, c]) => t => a.producte(t.potencia(2)).producte(3).suma(b.producte(t).producte(2)).suma(c),
  ([a, b]) => t => a.producte(t).producte(6).suma(b.producte(2)),
];
const LECTURA_PC = {variables: ['a', 'b', 'c', 'd', 'x'], funcions: ['f', "f'", "f''"]};
const funcionsPC = u => ({f: DERIVADES_PC[0](u), "f'": DERIVADES_PC[1](u), "f''": DERIVADES_PC[2](u)});
/** Valor d'una expressió en text pla, amb els paràmetres u i la x. */
const valorPC = (text, u, x = fr(0)) => exacte(M.llegeix(text, LECTURA_PC), {variables: {a: u[0], b: u[1], c: u[2], d: u[3], x}, funcions: funcionsPC(u)});

const BASE_PC = [0, 1, 2, 3].map(i => [0, 1, 2, 3].map(j => fr(i === j ? 1 : 0)));
const ZERO_PC = [fr(0), fr(0), fr(0), fr(0)];
const PROVA_PC = [[fr(2), fr(-3), fr(5, 2), fr(7)], [fr(-1, 3), fr(4), fr(-2), fr(1, 5)]];

/**
 * Forma afí d'una funció dels paràmetres, E(u) = α·u + β, com a [α0, α1, α2, α3, β].
 * Llança un error si E no és afí (es comprova en dos punts més).
 */
function afiPC(E) {
  const b = E(ZERO_PC);
  const forma = BASE_PC.map(e => E(e).resta(b)).concat([b]);
  for (const u of PROVA_PC) {
    const previst = u.reduce((s, ui, i) => s.suma(forma[i].producte(ui)), b);
    if (!E(u).igual(previst)) throw new Error('no és una equació lineal en a, b, c i d');
  }
  return forma;
}
/** Forma afí (membre esquerre − membre dret) d'una igualtat «A = B» en text pla. */
const formaDe = pla => {
  const parts = pla.split('=');
  if (parts.length !== 2) throw new Error(`«${pla}» no és una igualtat simple`);
  return afiPC(u => valorPC(parts[0], u).resta(valorPC(parts[1], u)));
};
/** Cert si dues formes afins són proporcionals (amb un factor diferent de 0): la mateixa equació. */
function proporcionals(A, B) {
  const j = B.findIndex(v => !v.esZero());
  if (j < 0 || A[j].esZero()) return false;
  const l = A[j].quocient(B[j]);
  return A.every((v, i) => v.igual(B[i].producte(l)));
}
/** Solució única del sistema de formes afins (4 equacions), o null si no n'hi ha una de sola. */
function resolPC(formes) {
  const m = formes.map(f => f.slice(0, 4).concat([f[4].oposada()]));
  for (let col = 0; col < 4; col++) {
    const piv = m.findIndex((fila, i) => i >= col && !fila[col].esZero());
    if (piv < 0) return null;
    [m[col], m[piv]] = [m[piv], m[col]];
    for (let i = 0; i < m.length; i++) {
      if (i === col || m[i][col].esZero()) continue;
      const k = m[i][col].quocient(m[col][col]);
      m[i] = m[i].map((v, j) => v.resta(m[col][j].producte(k)));
    }
  }
  return m.map((fila, i) => fila[4].quocient(fila[i]));
}
const satisfa = (forma, u) => u.reduce((s, ui, i) => s.suma(forma[i].producte(ui)), forma[4]).esZero();
/** Línies d'un sistema «\begin{cases} … \\ … \end{cases}», en text pla. */
function liniesDeSistema(tex) {
  // Cada equació amb «(EQ.n)» a la dreta, d'un altre color (David): «… & \quad \textcolor{#b45309}{\text{(EQ.n)}}».
  const m = /^\\left\\\{\\begin\{array\}\{ll\}(.*)\\end\{array\}\\right\.$/.exec(tex.trim());
  if (!m) throw new Error('no és un sistema amb (EQ.n)');
  return m[1].split('\\\\').map((l, i) => {
    const [eq, etiqueta] = l.split('&');
    if (!etiqueta || etiqueta.trim() !== `\\quad \\textcolor{#b45309}{\\text{(EQ.${i + 1})}}`) throw new Error(`l'equació ${i + 1} no porta l'etiqueta (EQ.${i + 1})`);
    return textPla(eq.trim());
  });
}

/**
 * Les línies d'una reducció de polinomi-condicions (Matrius.passosCombina, passosReduccio2), a la fila de càlcul:
 * «(EQ.n) · m: equació» és m vegades l'equació n del sistema del mateix pas (o, amb valors ja substituïts, una
 * equació certa); la primera línia després de la ratlla és la suma de les dues anteriors; totes són certes per a la
 * solució; un valor («a = 1») va requadrat, i res més no ho va.
 */
function comprovaReduccioPC(tex, sistemaTex, sol, on) {
  const m = /^\\begin\{array\}\{rl\}(.*)\\end\{array\}$/.exec(tex.trim());
  if (!m) throw new Error('la reducció no és un array {rl}');
  const formesSistema = liniesDeSistema(sistemaTex).map(formaDe);
  const files = m[1].split(/\\\\(?:\[6pt\])?/).map(l => l.trim());
  const etiquetades = [];
  let suma = false, anterior = null;
  files.forEach(fl => {
    const [esq, dre] = fl.split('&');
    const ratlla = esq.includes('\\hline');
    const etiqueta = textPla(esq.replace('\\hline', ''));
    const pla = textPla(dre.trim());
    const forma = formaDe(pla);
    comprova(satisfa(forma, sol), () => `${on}: «${pla}» no és certa per a la solució`);
    const caixa = /\\boxed\{/.test(dre);
    const unica = forma.slice(0, 4).filter(c => !c.esZero());
    const esValor = unica.length === 1 && /^[abcd]=/.test(pla) && !/[abcd]/.test(pla.split('=')[1]);
    comprova(caixa === esValor, () => `${on}: «${pla}» ${esValor ? 'és un valor trobat: ha d\'anar requadrat' : 'no és un valor: no va requadrat'}`);
    if (etiqueta) {
      const e = /^«\(EQ\.(\d)\)»(?:\*\(?(-?\d+)\)?)?:$/.exec(etiqueta);
      comprova(e && esq.includes('\\textcolor{#b45309}{\\text{(EQ.'), () => `${on}: etiqueta «${etiqueta}» no prevista (ha de ser «(EQ.n) · m:», de color)`);
      if (!e) return;
      const n = Number(e[1]), k = fr(e[2] ? Number(e[2]) : 1);
      const objectiu = formesSistema[n - 1].map(c => c.producte(k));
      const mateixes = [0, 1, 2, 3].every(j => forma[j].esZero() === objectiu[j].esZero());
      if (mateixes) comprova(forma.every((c, j) => c.igual(objectiu[j])), () => `${on}: «${pla}» no és (EQ.${n}) · ${k.num}`);
      etiquetades.push(forma);
    } else if (ratlla) {
      suma = true;
      const [A, B] = etiquetades.slice(-2);
      comprova(A && B && forma.every((c, j) => c.igual(A[j].suma(B[j]))), () => `${on}: «${pla}» no és la suma de les dues equacions de sobre`);
    } else if (anterior) {
      comprova(proporcionals(forma, anterior) || esValor, () => `${on}: «${pla}» no surt de la línia anterior`);
    }
    anterior = forma;
  });
  comprova(suma || files.length === etiquetades.length, () => `${on}: a la reducció hi falta la ratlla de la suma`);
}

/** Veritat d'un guió del polinomi de grau 3: cada fila, a cada pas. */
function comprovaPolinomi(passos, problema, model, nom) {
  const FILA = PolinomiCondicions.FILA;
  const conds = model.condicions.map(([o, x, v]) => afiPC(u => DERIVADES_PC[o](u)(fr(x)).resta(fr(v))));
  const sol = resolPC(conds);
  comprova(sol && sol.every((v, i) => v.igual(model.solucio[i])), () => `${nom}: el model no té la solució única ${model.solucio}`);
  if (!sol) return 0;
  comprova(['a', 'b', 'c', 'd'].every((v, i) => fr(problema.solucio[v]).igual(sol[i])), () => `${nom}: la solució de les dades no és la del model`);
  // Les dades del problema diuen el mateix que el model: condicions, frases, extrems i inflexions.
  const dades = problema.dades.flatMap(d => d.condicions);
  comprova(iguals(dades.map(c => [c.ordre, c.x, c.valor]), model.condicions), () => `${nom}: les condicions de les dades no són les del model`);
  comprova(iguals(problema.dades.map(d => d.condicions.length), model.frases), () => `${nom}: les frases de les dades no són les del model`);
  const extremsDades = dades.filter(c => c.extrem).map(c => [c.x, c.extrem]).filter(([x], k, l) => l.findIndex(e => e[0] === x) === k);
  comprova(iguals(extremsDades, model.extrems), () => `${nom}: els extrems de les dades (${extremsDades}) no són els del model`);
  comprova(iguals(dades.filter(c => c.inflexio).map(c => c.x), model.inflexions), () => `${nom}: les inflexions de les dades no són les del model`);
  const NOMS = ['f(x)', "f'(x)", "f''(x)"];
  const PARAMS = [sol].concat(PROVA_PC);
  let linies = 0, primerSistemaComplet = true;
  const comprovacions = new Set();          // abscisses comprovades amb f''

  passos.forEach((pas, i) => {
    const sistemaTex = pas.files[FILA.sistema];
    let nLinies = 0;
    pas.files.forEach((tex, fila) => {
      if (!tex || fila === FILA.enunciat) return;
      const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
      let pla = '';
      try {
        linies++;
        if (fila === FILA.sistema) {
          const ls = liniesDeSistema(tex);
          nLinies = ls.length;
          const formes = ls.map(formaDe);
          if (ls.length < 4 || primerSistemaComplet) {
            comprova(formes.every((f, j) => proporcionals(f, conds[j])), () => `${on}: les equacions «${ls}» no són les de les dades, en ordre`);
            if (ls.length === 4) primerSistemaComplet = false;
          }
          if (ls.length === 4) {
            comprova(resolPC(formes) !== null && formes.every(f => satisfa(f, sol)), () => `${on}: el sistema «${ls}» no és equivalent`);
          }
          comprova(ls.length <= 4, () => `${on}: massa equacions`);
          // Pel mètode de reducció, mai aïllant una incògnita en funció d'una altra (b = −3a): mètode de substitució.
          comprova(ls.every(l => !/[abcd]/.test(l.split('=')[1] || '')), () => `${on}: «${ls.join('; ')}»: una incògnita aïllada en funció d'una altra`);
          return;
        }
        pla = textPla(tex);
        if (fila === FILA.calcul) {
          const relacio = /^(.*)([<>])0$/.exec(pla);
          const enTraduccio = (sistemaTex ? liniesDeSistema(sistemaTex).length : 0) < 4;
          if (relacio) {
            const parts = relacio[1].split('=');
            const valors = parts.map(t => valorPC(t, sol));
            comprova(valors.every(v => v.igual(valors[0])) && valors[0].signe() === (relacio[2] === '<' ? -1 : 1), () => `${on}: «${pla}» és fals`);
            const m = /^f''\((.+)\)$/.exec(parts[0]);
            if (m) comprovacions.add(conjunt([valorPC(m[1], sol)]));
          } else if (enTraduccio) {
            const k = sistemaTex ? liniesDeSistema(sistemaTex).length : 0;
            comprova(proporcionals(formaDe(pla), conds[k]), () => `${on}: «${pla}» no és la traducció de la dada ${k + 1}`);
          } else if (tex.startsWith('\\begin{array}{rl}')) {
            comprovaReduccioPC(tex, sistemaTex, sol, on);
          } else {
            const valors = pla.split('=').map(t => valorPC(t, sol));
            comprova(valors.length >= 2 && valors.every(v => v.igual(valors[0])), () => `${on}: «${pla}» no és certa per a la solució`);
          }
          return;
        }
        // Files de f, f', f'' i de la resposta: identitats en x.
        const [esq, dre] = pla.split('=');
        const ordre = fila === FILA.resposta ? 0 : fila - FILA.funcio;
        comprova(esq === NOMS[ordre] && pla.split('=').length === 2, () => `${on}: «${pla}» no és de la forma ${NOMS[ordre]} = …`);
        const params = /[abcd]/.test(dre) ? PARAMS : [sol];
        comprova(params.every(u => PUNTS.every(x => valorPC(esq, u, x).igual(valorPC(dre, u, x)))), () => `${on}: «${pla}» no és certa`);
      } catch (e) {
        comprova(false, () => `${on}: no es pot llegir «${pla || tex}»: ${e.message}`);
      }
    });
    if (i > 0) {
      const anterior = passos[i - 1].files[FILA.sistema];
      const n0 = anterior ? liniesDeSistema(anterior).length : 0;
      comprova(nLinies >= n0, () => `${nom}, pas ${i + 1}: el sistema ha perdut equacions`);
    }
  });

  // Al final: el sistema resolt, la resposta i l'enunciat marcat.
  const final = passos[passos.length - 1];
  const ls = liniesDeSistema(final.files[FILA.sistema]);
  const resolt = ls.map(l => /^([abcd])=(-?\d+)$/.exec(l));
  comprova(resolt.every(Boolean) && conjuntLletres(resolt) === 'abcd'
    && resolt.every(m => fr(Number(m[2])).igual(sol['abcd'.indexOf(m[1])])), () => `${nom}: el sistema final no és la solució: ${ls}`);
  comprova(final.classes[FILA.resposta] === 'final' && !final.files[FILA.calcul], () => `${nom}: la resposta final no està destacada`);
  comprova((final.files[FILA.sistema].match(/\\boxed\{/g) || []).length === 4, () => `${nom}: els quatre valors trobats han d'anar requadrats`);
  comprova(!/[abcd]/.test(textPla(final.files[FILA.resposta]).split('=')[1]), () => `${nom}: la resposta final encara té lletres`);
  const enunciat = final.files[FILA.enunciat];
  model.frases.forEach((n, j) => {
    const m = new RegExp(`\\{\\{E${j + 1}1\\|([^|]*)\\|`).exec(enunciat);
    comprova(m && m[1] === (n === 2 ? 'doble' : 'condicio'), () => `${nom}: la frase ${j + 1} hauria d'estar marcada «${n === 2 ? 'doble' : 'condicio'}»`);
  });
  comprova(model.frases.reduce((s, n) => s + n, 0) === 4, () => `${nom}: les frases no donen quatre condicions`);
  // Els extrems i les inflexions de l'enunciat hi són de debò, i els extrems s'han comprovat amb f''.
  const d2 = DERIVADES_PC[2](sol);
  for (const [x, tipus] of model.extrems) {
    const s = d2(fr(x)).signe();
    comprova(DERIVADES_PC[1](sol)(fr(x)).esZero() && (tipus === 'maxim' ? s < 0 : tipus === 'minim' ? s > 0 : s !== 0), () => `${nom}: en x = ${x} no hi ha un ${tipus}`);
    comprova(comprovacions.has(conjunt([fr(x)])), () => `${nom}: falta la comprovació amb f'' en x = ${x}`);
  }
  for (const x of model.inflexions) comprova(d2(fr(x)).esZero() && !sol[0].esZero(), () => `${nom}: en x = ${x} no hi ha inflexió`);
  comprova(comprovacions.size === model.extrems.length, () => `${nom}: hi ha comprovacions amb f'' de més`);
  return linies;
}
const conjuntLletres = ms => ms.map(m => m[1]).sort().join('');

seccio('polinomi a partir de condicions', () => {
  let linies = 0, passos = 0;
  for (const problema of PolinomiCondicions.problemes) {
    const model = PC[problema.id];
    comprova(model, () => `${problema.id}: no hi ha model`);
    if (!model) continue;
    const llista = PolinomiCondicions.passos({p: problema.id});
    comprovaGuio(llista, PolinomiCondicions.files, problema.id);
    linies += comprovaPolinomi(llista, problema, model, problema.id);
    passos += llista.length;
    comprova(iguals(PolinomiCondicions.llegeixAdreca(PolinomiCondicions.escriuAdreca({p: problema.id})).valors, {p: problema.id}), () => `${problema.id}: adreça`);
  }
  comprova(Object.keys(PC).length === PolinomiCondicions.problemes.length, 'hi ha models de problemes que no existeixen');
  comprova(/no existeix/.test(PolinomiCondicions.llegeixAdreca({p: 'res'}).error || ''), 'problema inexistent a l\'adreça');
  comprova(iguals(PolinomiCondicions.llegeixAdreca({}).valors, {p: 'ordenades'}), 'problema per defecte');
  return `${PolinomiCondicions.problemes.length} problemes, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 9. TEOREMA DE BOLZANO I BISECCIÓ ──────────────────────────────── */

/** Nombre escrit amb coma decimal («-0,375») → Fraccio, calculat aquí mateix. */
function llegeixDecimal(t) {
  const m = /^(-?)(\d+)(?:,(\d+))?$/.exec(t);
  if (!m) throw new Error(`«${t}» no és un nombre decimal`);
  const dec = m[3] || '';
  const v = fr(Number(m[2] + dec), 10 ** dec.length);
  return m[1] ? v.oposada() : v;
}
/** Cel·la de f(m): «v<0», «≈v>0» o «0». Torna {valor, aprox, decimals, signe}. */
function cellaValor(t) {
  if (t === '0') return {valor: fr(0), aprox: false, decimals: 0, signe: 0};
  const m = /^(≈?)(-?[\d,]+)([<>])0$/.exec(t);
  if (!m) throw new Error(`cel·la de valor «${t}» no prevista`);
  return {valor: llegeixDecimal(m[2]), aprox: m[1] === '≈', decimals: (m[2].split(',')[1] || '').length, signe: m[3] === '<' ? -1 : 1};
}
/** Interval amb signes «[l⁽s⁾;r⁽t⁾]». */
function cellaInterval(t) {
  const m = /^\[(-?[\d,]+)⁽([+-])⁾;(-?[\d,]+)⁽([+-])⁾\]$/.exec(t);
  if (!m) throw new Error(`interval «${t}» no previst`);
  return {l: llegeixDecimal(m[1]), sl: m[2] === '-' ? -1 : 1, r: llegeixDecimal(m[3]), sr: m[4] === '-' ? -1 : 1};
}

/**
 * Veritat d'un guió de Bolzano, amb un model calculat aquí: f, f(a), f(b), i la bisecció
 * feta de nou. Files: f(x) (identitat); la continuïtat (text amb l'interval); f(a) i f(b)
 * (cadenes d'igualtats, amb el signe final); la conclusió; la taula (cada interval amb els
 * signes certs de f, cada punt mitjà, cada valor exacte o ben arrodonit, i l'interval
 * següent, la meitat amb canvi de signe); la resposta.
 */
function comprovaBolzano(passos, v, nom) {
  const FILA = Bolzano.FILA;
  const coefs = [v.a0, v.a1, v.a2, v.a3].map(c => fr(c));
  const f = polinomiExacte(coefs);
  const funcions = {f};
  const [a, b] = [fr(v.a), fr(v.b)];
  const s = x => f(x).signe();
  const aplica = s(a) * s(b) < 0;
  // La bisecció del model.
  const model = [];                       // {l, r, m, fm}
  let arrel = null;
  if (aplica) {
    let [l, r] = [a, b];
    for (let k = 0; k < v.n; k++) {
      const m = l.suma(r).quocient(2);
      model.push({l, r, m, fm: f(m)});
      if (f(m).esZero()) { arrel = m; break; }
      if (s(m) !== s(l)) r = m; else l = m;
    }
    if (!arrel) model.push({l, r});
  }
  const valor = t => exacte(M.llegeix(t, LECTURA), {variables: {}, funcions});
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    let pla = '';
    linies++;
    try {
      if (fila === FILA.continuitat) {
        comprova(tex.startsWith('§') && tex.includes(`$[${v.a}, ${v.b}]$`), () => `${on}: la continuïtat no parla de [${v.a}, ${v.b}]`);
        return;
      }
      if (fila === FILA.taula) {
        const [cap, ...files] = cellesDeTaula(tex);
        comprova(cap.join('|') === '«Interval»|m|f(m)' && tex.includes('\\textbf{Interval}'), () => `${on}: capçalera «${cap}» (en negreta i amb majúscula)`);
        files.forEach((c, k) => {
          const mod = model[k];
          const iv = cellaInterval(c[0]);
          comprova(mod && iv.l.igual(mod.l) && iv.r.igual(mod.r) && iv.sl === s(iv.l) && iv.sr === s(iv.r) && iv.sl !== iv.sr,
            () => `${on}: l'interval ${k + 1} «${c[0]}» no és el de la bisecció o té els signes malament`);
          if (c[1]) comprova(mod.m && llegeixDecimal(c[1]).igual(mod.m), () => `${on}: el punt mitjà «${c[1]}» no és ${mod.m && mod.m.valor()}`);
          if (c[2]) {
            const cv = cellaValor(c[2]);
            const error = cv.valor.resta(mod.fm).abs();
            comprova(cv.signe === mod.fm.signe() && (cv.aprox ? !cv.valor.esZero() && error.producte(2 * 10 ** cv.decimals).resta(1).signe() <= 0 : error.esZero()),
              () => `${on}: «f(${c[1]})» val ${mod.fm.valor()}, no «${c[2]}»`);
          }
          if (k < files.length - 1) comprova(c[1] && c[2], () => `${on}: una fila de la taula sense acabar`);
        });
        return;
      }
      pla = textPla(tex);
      if (fila === FILA.bolzano) {
        comprova(aplica ? pla === `∃c∈(${v.a},${v.b}):f(c)=0` : pla === "«mateixsigne:Bolzanonos'hipotaplicar»", () => `${on}: conclusió «${pla}»`);
      } else if (fila === FILA.resposta) {
        const esperat = arrel ? `c=${pla.slice(2)}` : `c∈(${pla.slice(3, -1)})`;
        if (arrel) comprova(pla === esperat && llegeixDecimal(pla.slice(2)).igual(arrel), () => `${on}: «${pla}» no és l'arrel`);
        else {
          const [l, r] = pla.slice(3, -1).split(';').map(llegeixDecimal);
          const ultim = model[model.length - 1];
          comprova(pla === esperat && l.igual(ultim.l) && r.igual(ultim.r) && r.resta(l).igual(b.resta(a).quocient(2 ** v.n)), () => `${on}: resposta «${pla}»`);
        }
      } else if (fila === FILA.funcio) {
        const [esq, dre] = pla.split('=').map(costat);
        comprova(PUNTS.every(x => esq({variables: {x}, funcions}).igual(dre({variables: {x}, funcions}))), () => `${on}: «${pla}» no és certa`);
      } else {
        const x = fila === FILA.fa ? v.a : v.b;
        const relacio = /^(.*)([<>])0$/.exec(pla);
        const parts = (relacio ? relacio[1] : pla).split('=');
        comprova(parts[0] === `f(${x})` && parts.map(valor).every(w => w.igual(f(fr(x)))), () => `${on}: «${pla}» no és certa`);
        if (relacio) comprova(s(fr(x)) === (relacio[2] === '<' ? -1 : 1), () => `${on}: «${pla}»: signe`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${pla || tex}»: ${e.message}`);
    }
  }));
  // Al final: la conclusió o la resposta destacada, i la taula completa.
  const final = passos[passos.length - 1];
  if (!aplica) {
    comprova(final.classes[FILA.bolzano] === 'final' && !final.files[FILA.taula], () => `${nom}: amb el mateix signe, el procediment ha d'acabar a la conclusió`);
  } else {
    comprova(final.classes[FILA.resposta] === 'final', () => `${nom}: la resposta no està destacada`);
    comprova(cellesDeTaula(final.files[FILA.taula]).length - 1 === model.length, () => `${nom}: la taula final no té ${model.length} files`);
  }
  return linies;
}

seccio('Bolzano i bisecció', () => {
  const B = p => Bolzano.llegeixAdreca(p);
  const d = (a3, a2, a1, a0, a, b, n) => ({a3, a2, a1, a0, a, b, n});
  for (const [p, esperat] of [
    [{}, d(1, 0, 1, -1, 0, 1, 3)], [{f: 'x^2-2', a: '1', b: '2', n: '4'}, d(0, 1, 0, -2, 1, 2, 4)], [{f: 'x^3+3x+2', a: '-2', b: '0'}, d(1, 0, 3, 2, -2, 0, 3)],
  ]) comprova(iguals(B(p).valors, esperat), () => `Bolzano.llegeixAdreca(${JSON.stringify(p)}) → ${JSON.stringify(B(p))}`);
  for (const [p, patro] of [
    [{a: '2', b: '1'}, /a < b/], [{n: '0'}, /bisseccions/], [{n: '6'}, /bisseccions/], [{a: '1/2'}, /no és un nombre enter/],
    [{f: 'x^2-1', a: '1', b: '2'}, /ja és una arrel/], [{b: '7'}, /entre −5 i 5/], [{f: 'x^4'}, /grau 4/], [{f: '(x'}, /^No entenc l'adreça/],
  ]) comprova(patro.test(B(p).error || ''), () => `Bolzano.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(B(p))}`);
  for (const v of Bolzano.exemples) comprova(Bolzano.valida(v) === null, () => `l'exemple ${JSON.stringify(v)} no és vàlid`);
  // L'arrodoniment: exacte fins a 4 decimals; si no, amb ≈ i prou decimals perquè no surti 0.
  for (const [x, tex, aprox] of [[fr(-3, 8), '-0{,}375', false], [fr(121, 64), '1{,}891', true], [fr(1, 4096), '0{,}0002', true], [fr(-5), '-5', false], [fr(1, 3), '0{,}333', true]]) {
    const r = Bolzano.decimal(x);
    comprova(r.tex === tex && r.aprox === aprox, () => `decimal(${x.num}/${x.den}) → ${JSON.stringify(r)}`);
  }
  const casos = Bolzano.exemples.slice();
  const atzar = aleatori(2029);
  const enter = (min, max) => min + Math.floor(atzar() * (max - min + 1));
  for (let i = 0; i < 3000; i++) casos.push(d(enter(-3, 3), enter(-5, 5), enter(-9, 9), enter(-9, 9), enter(-5, 4), 0, enter(1, 5)));
  for (const c of casos) if (!c.b) c.b = enter(c.a + 1, 5);
  let valids = 0, linies = 0, passos = 0, exactes = 0, sense = 0;
  for (const v of casos) {
    if (Bolzano.valida(v)) continue;
    valids++;
    const nom = `f = ${Dd.textFuncio(v)}, [${v.a}, ${v.b}], n = ${v.n}`;
    comprova(iguals(B(Bolzano.escriuAdreca(v)).valors, v), () => `${nom}: anada i tornada de l'adreça`);
    const llista = Bolzano.passos(v);
    comprovaGuio(llista, Bolzano.files, nom);
    linies += comprovaBolzano(llista, v, nom);
    passos += llista.length;
    if (llista[llista.length - 1].text.includes('arrel exacta')) exactes++;
    if (llista[llista.length - 1].files[Bolzano.FILA.taula] === '') sense++;
  }
  comprova(exactes > 0 && sense > 0, 'la mostra no té casos d\'arrel exacta o de mateix signe');
  return `${valids} casos vàlids, ${passos} passos, ${linies} línies comprovades (${exactes} amb arrel exacta, ${sense} sense Bolzano)`;
});


/* ── 10. ASÍMPTOTES D'UNA FUNCIÓ RACIONAL ──────────────────────────── */

/**
 * Una expressió en x (amb f) com a funció racional exacta [N, D]: coeficients
 * Fraccio de grau 0 cap amunt. f(x) és P/Q. Serveix per calcular límits.
 */
function racional(n, P, Q) {
  const r = m => racional(m, P, Q);
  const u = [fr(1)];
  switch (n.tipus) {
    case 'nombre': return [[n.valor], u];
    case 'variable': if (n.nom === 'x') return [[fr(0), fr(1)], u]; break;
    case 'oposat': { const [a, b] = r(n.a); return [a.map(c => c.oposada()), b]; }
    case 'suma': case 'resta': {
      const [a, b] = r(n.a), [c, d] = r(n.b);
      const cd = producteP(c, b).map(x => (n.tipus === 'resta' ? x.oposada() : x));
      return [sumaP(producteP(a, d), cd), producteP(b, d)];
    }
    case 'producte': { const [a, b] = r(n.a), [c, d] = r(n.b); return [producteP(a, c), producteP(b, d)]; }
    case 'quocient': { const [a, b] = r(n.a), [c, d] = r(n.b); return [producteP(a, d), producteP(b, c)]; }
    case 'potencia': {
      const e = exacte(n.exponent, {variables: {}, funcions: {}});
      if (!e.esEnter() || e.num < 0) break;
      let res = [u, u];
      const [a, b] = r(n.base);
      for (let i = 0; i < e.num; i++) res = [producteP(res[0], a), producteP(res[1], b)];
      return res;
    }
    case 'crida': if (n.nom === 'f' && n.arg.tipus === 'variable' && n.arg.nom === 'x') return [P, Q]; break;
  }
  throw new Error(`expressió no prevista en un límit: ${n.tipus}`);
}
const LECTURA_LIM = {variables: ['x'], funcions: ['f']};
/** Límit a +∞ (cap = 1) o −∞ (cap = −1) d'una funció racional [N, D]: «+∞», «-∞» o un nombre en text. */
function limitRacional([N, D], cap) {
  const [n, d] = [retallaP(N), retallaP(D)];
  if (!d.length) throw new Error('denominador 0');
  if (!n.length) return '0';
  const k = (n.length - 1) - (d.length - 1), c = n[n.length - 1].quocient(d[d.length - 1]);
  if (k < 0) return '0';
  if (k === 0) return conjunt([c]);
  return c.signe() * (cap < 0 && k % 2 ? -1 : 1) < 0 ? '-∞' : '+∞';
}
/** Valor d'un costat d'una línia de límit: «lim_x→+∞EXPR», «+∞», «-∞» o un nombre. */
function valorLimit(text, cap, P, Q) {
  const m = /^lim_x→([+-]|±)∞(.*)$/.exec(text);
  if (m) {
    const caps = m[1] === '±' ? [1, -1] : [m[1] === '+' ? 1 : -1];
    if (!caps.includes(cap)) throw new Error(`«${text}»: el límit no és cap a ${cap > 0 ? '+' : '-'}∞`);
    const vals = caps.map(c => limitRacional(racional(M.llegeix(m[2], LECTURA_LIM), P, Q), c));
    if (vals.some(v => v !== vals[0])) throw new Error(`«${text}»: el límit no és el mateix a +∞ i a −∞`);
    return vals[0];
  }
  if (text === '+∞' || text === '-∞') return text;
  return conjunt([exacte(M.llegeix(text, {variables: []}), {variables: {}, funcions: {}})]);
}
/** Les línies del resum d'asímptotes que diuen que no n'hi ha (en text pla), i de quin tipus és cada línia. */
const RESUM_SENSE = {V: '«Nohihaasímptotesverticals»', H: '«Nohihaasímptoteshoritzontals»', O: '«Nohihaasímptotesobliqües»'};
const tipusResum = l => (/^«Asímptotavertical|^«Nohihaasímptotesverticals/.test(l) ? 'V'
  : /^«Asímptotahoritzontal|^«Nohihaasímptoteshoritzontals/.test(l) ? 'H'
    : /^«Asímptotaobliqua|^«Nohihaasímptotesobliqües/.test(l) ? 'O' : null);
/** Línies d'un «\begin{array}{l} … \end{array}», en text pla. */
const liniesDArray = tex => {
  const m = /^\\begin\{array\}\{l\}(.*)\\end\{array\}$/.exec(tex.trim());
  if (!m) throw new Error('no és una llista de línies');
  return m[1].split('\\\\').map(l => textPla(l.replace(/^\[[^\]]*\]/, '').trim()));
};

/**
 * Veritat d'un guió d'asímptotes, amb un model calculat aquí: les arrels de Q (asímptotes
 * verticals), el signe de Q a cada costat d'una arrel (per la seva multiplicitat), els graus
 * (horitzontal) i la divisió P = Q·S + R (obliqua, si S és de grau 1).
 */
function comprovaAsimptotes(passos, v, nom) {
  const FILA = Asimptotes.FILA;
  const P = retallaP([v.p0, v.p1, v.p2, v.p3].map(c => fr(c))), Q = retallaP([v.q0, v.q1, v.q2].map(c => fr(c)));
  const val = p => x => p.reduceRight((s, c) => s.producte(x).suma(c), fr(0));
  const f = x => val(P)(x).quocient(val(Q)(x));
  const arrelsQ = arrelsDe(Q);
  // Signe de Q just a la dreta (s = 1) o a l'esquerra (s = −1) d'una arrel a: la primera derivada que no s'anul·la.
  const signeCostat = (a, s) => {
    let d = Q, m = 0;
    while (val(d)(a).esZero()) { d = derivadaP(d); m++; }
    return val(d)(a).signe() * (s < 0 && m % 2 ? -1 : 1);
  };
  // Divisió P = Q·S + R.
  const S = [], Rr = P.slice();
  for (let i = Rr.length - 1; i >= Q.length - 1; i--) {
    const q = Rr[i].quocient(Q[Q.length - 1]);
    S[i - (Q.length - 1)] = q;
    for (let j = 0; j < Q.length; j++) Rr[i - (Q.length - 1) + j] = Rr[i - (Q.length - 1) + j].resta(Q[j].producte(q));
  }
  const grauP = P.length - 1, grauQ = Q.length - 1;
  const AH = grauP < grauQ ? fr(0) : grauP === grauQ ? P[grauP].quocient(Q[grauQ]) : null;
  const AO = grauP === grauQ + 1 ? {m: S[1], n: S[0]} : null;
  const limF = cap => limitRacional([P, Q], cap);
  let linies = 0;

  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      if (fila === FILA.funcio) {
        const [esq, dre] = textPla(tex).split('=').map(costat);
        const punts = [-7, -3, -1, 1, 3, 5, 9, 11, -9, 13].map(k => fr(k, 4)).filter(x => !val(Q)(x).esZero());
        comprova(punts.every(x => esq({variables: {x}, funcions: {f}}).igual(dre({variables: {x}, funcions: {f}}))), () => `${on}: «${textPla(tex)}» no és certa`);
      } else if (fila === FILA.calcul) {
        comprova(solucionsDeFila(textPla(tex)) === conjunt(arrelsQ), () => `${on}: «${textPla(tex)}» no té per solucions les arrels de Q`);
      } else if (fila === FILA.domini && !tex.includes('{k=Vt}')) {
        // Mentre es resol Q(x) = 0, la fila del domini fa de fila de treball (sota l'equació, que es queda a la fila de
        // càlcul): les mateixes solucions; en lila, totes.
        comprova(Boolean(pas.files[FILA.calcul]), () => `${on}: la fila de treball no té l'equació a sobre`);
        comprova(solucionsDeFila(textPla(tex)) === conjunt(arrelsQ), () => `${on}: «${textPla(tex)}» no té per solucions les arrels de Q`);
        const grupsT = grupsAmbClau(tex);
        const valor = t => exacte(M.llegeix(t, {variables: []}), {variables: {}, funcions: {}});
        const lila = [...tex.matchAll(/\\htmlData\{k=(\w+),marca=solucio\}\{/g)].map(q => valor(textPla(grupsT[q[1]].tex)));
        if (lila.length) comprova(conjunt(lila) === conjunt(arrelsQ), () => `${on}: en lila hi ha ${conjunt(lila)}, i les arrels de Q són ${conjunt(arrelsQ)}`);
      } else if (fila === FILA.domini) {
        const m = /^«Dom»f=ℝ(?:-\{(.+)\})?$/.exec(textPla(tex));
        const valor = t => exacte(M.llegeix(t, {variables: []}), {variables: {}, funcions: {}});
        comprova(m && conjunt(m[1] ? m[1].split(',').map(valor) : []) === conjunt(arrelsQ), () => `${on}: domini «${textPla(tex)}»`);
      } else if (fila === FILA.laterals) {
        for (const l of liniesDArray(tex)) {
          // Directament el resultat (sense la notació k/0⁻): lim_{x→a^±} f(x) = ±∞.
          const m = /^lim_x→(.+)\^\(([+-])\)f\(x\)=([+-])∞$/.exec(l);
          if (!m) throw new Error(`línia «${l}» no prevista`);
          const valor = t => exacte(M.llegeix(t, {variables: []}), {variables: {}, funcions: {}});
          const a = valor(m[1]), s = m[2] === '-' ? -1 : 1;
          const k = arrelsQ.some(r => r.igual(a)) ? val(P)(a) : fr(0);
          comprova(!k.esZero() && (m[3] === '-' ? -1 : 1) === k.signe() * signeCostat(a, s), () => `${on}: «${l}» és fals`);
        }
      } else if (fila === FILA.infinit || fila === FILA.obliqua) {
        for (const l of liniesDArray(tex)) {
          const [esq, dre] = l.split('=');
          let m;
          if ((m = /^lim_x→([+-])∞f\(x\)$/.exec(esq))) {
            const cap = m[1] === '+' ? 1 : -1;
            comprova(fila === FILA.infinit && valorLimit(dre, cap, P, Q) === limF(cap), () => `${on}: «${l}» és fals (el límit és ${limF(cap)})`);
          } else if (esq === 'm' || esq === 'n') {
            const model = AO && conjunt([AO[esq]]);
            comprova(fila === FILA.obliqua && AO && [1, -1].every(cap => valorLimit(dre, cap, P, Q) === model), () => `${on}: «${l}»: ${esq} no és ${model}`);
          } else if (esq === 'lim_x→+∞((f(x))/(x))') {
            const lim = limitRacional([P, producteP(Q, [fr(0), fr(1)])], 1);
            comprova(fila === FILA.obliqua && !AO && !AH && valorLimit(dre, 1, P, Q) === lim && lim.endsWith('∞'), () => `${on}: «${l}» és fals`);
          } else {
            throw new Error(`línia «${l}» no prevista`);
          }
        }
      } else if (fila === FILA.resum) {
        const valor = t => exacte(M.llegeix(t, {variables: []}), {variables: {}, funcions: {}});
        for (const l of liniesDArray(tex)) {
          let m;
          if ((m = /^«Asímptotaverticald'equació»x=(.+)$/.exec(l))) comprova(arrelsQ.some(r => r.igual(valor(m[1]))), () => `${on}: «${l}» no és una asímptota vertical`);
          else if (l === RESUM_SENSE.V) comprova(!arrelsQ.length, () => `${on}: diu que no hi ha asímptotes verticals`);
          else if ((m = /^«Asímptotahoritzontald'equació»y=(.+)$/.exec(l))) comprova(AH && valor(m[1]).igual(AH), () => `${on}: «${l}» és fals`);
          else if (l === RESUM_SENSE.H) comprova(!AH, () => `${on}: sí que hi ha asímptota horitzontal`);
          else if ((m = /^«Asímptotaobliquad'equació»y=(.+)$/.exec(l))) {
            const recta = M.polinomi(M.llegeix(m[1]));
            comprova(AO && recta && conjunt([recta[1] || fr(0)]) === conjunt([AO.m]) && conjunt([recta[0] || fr(0)]) === conjunt([AO.n]), () => `${on}: «${l}» és fals`);
          } else if (l === RESUM_SENSE.O) comprova(!AO, () => `${on}: sí que hi ha asímptota obliqua`);
          else throw new Error(`línia «${l}» no prevista`);
        }
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  // Al final: el resum, complet i destacat; i, si el límit a l'infinit és infinit, la fila destacada.
  const final = passos[passos.length - 1];
  const resum = liniesDArray(final.files[FILA.resum]);
  comprova(final.classes[FILA.resum] === 'final', () => `${nom}: el resum no està destacat`);
  comprova(resum.filter(l => tipusResum(l) === 'V').length === Math.max(1, arrelsQ.length) && resum.some(l => tipusResum(l) === 'H') && resum.some(l => tipusResum(l) === 'O'),
    () => `${nom}: al resum hi falten asímptotes: ${resum}`);
  comprova((final.classes[FILA.infinit] === 'destacat') === !AH, () => `${nom}: la fila dels límits a l'infinit s'ha de destacar si i només si són infinits`);
  comprova(liniesDArray(final.files[FILA.laterals] || '\\begin{array}{l}\\end{array}').length === 2 * arrelsQ.length || (!arrelsQ.length && !final.files[FILA.laterals]),
    () => `${nom}: falten límits laterals`);
  if (arrelsQ.length) comprova(passos.some(q => [FILA.calcul, FILA.domini].some(f => (q.files[f] || '').includes('marca=solucio'))), () => `${nom}: les arrels de Q no surten en lila`);
  return linies;
}

seccio('asímptotes', () => {
  const A = p => Asimptotes.llegeixAdreca(p);
  const d = (p3, p2, p1, p0, q2, q1, q0) => ({p3, p2, p1, p0, q2, q1, q0});
  for (const [p, esperat] of [
    [{}, d(0, 1, 0, 3, 0, 1, -1)], [{f: '3x/(x^2-4)'}, d(0, 0, 3, 0, 1, 0, -4)], [{f: 'x^3/(x+1)'}, d(1, 0, 0, 0, 0, 1, 1)],
  ]) comprova(iguals(A(p).valors, esperat), () => `Asimptotes.llegeixAdreca(${JSON.stringify(p)}) → ${JSON.stringify(A(p))}`);
  for (const [p, patro] of [
    [{f: 'x^2+1'}, /ha de dependre de x/], [{f: '(x^2-1)/(x-1)'}, /factor comú/], [{f: '(x^3+x)/(x^2+1)'}, /factor comú/],
    [{f: '1/(x^2-2)'}, /irracionals/], [{f: 'x^4/(x+1)'}, /grau massa alt/], [{f: '(x'}, /^No entenc l'adreça/],
  ]) comprova(patro.test(A(p).error || ''), () => `Asimptotes.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(A(p))}`);
  for (const v of Asimptotes.exemples) comprova(Asimptotes.valida(v) === null, () => `l'exemple ${JSON.stringify(v)} no és vàlid`);
  const casos = Asimptotes.exemples.slice();
  const atzar = aleatori(2030);
  const enter = (min, max) => min + Math.floor(atzar() * (max - min + 1));
  for (let i = 0; i < 4000; i++) casos.push(d(enter(-2, 2), enter(-4, 4), enter(-9, 9), enter(-9, 9), enter(-2, 2), enter(-5, 5), enter(-9, 9)));
  let valids = 0, linies = 0, passos = 0;
  const tipus = new Set();
  for (const v of casos) {
    if (Asimptotes.valida(v)) continue;
    valids++;
    const nom = `f = ${Asimptotes.escriuAdreca(v).f}`;
    comprova(iguals(A(Asimptotes.escriuAdreca(v)).valors, v), () => `${nom}: anada i tornada de l'adreça`);
    let llista;
    try { llista = Asimptotes.passos(v); } catch (e) { comprova(false, () => `${nom}: passos() llança ${e.stack}`); continue; }
    comprovaGuio(llista, Asimptotes.files, nom);
    linies += comprovaAsimptotes(llista, v, nom);
    passos += llista.length;
    const res = liniesDArray(llista[llista.length - 1].files[Asimptotes.FILA.resum]).join();
    tipus.add((res.includes("«Asímptotahoritzontal") ? 'H' : '') + (res.includes("«Asímptotaobliqua") ? 'O' : '') + (res.includes(RESUM_SENSE.V) ? '' : 'V'));
  }
  comprova(['HV', 'OV', 'V', 'H', 'O'].every(t => tipus.has(t)), () => `la mostra no té tots els tipus de casos: ${[...tipus]}`);
  return `${valids} casos vàlids, ${passos} passos, ${linies} línies comprovades (tipus: ${[...tipus].sort().join(' ')})`;
});


/* ── 11. ARBRE DE PROBABILITATS I PROBABILITAT TOTAL ──────────────── */

/*
 * Model de cada problema, escrit aquí de manera independent: les probabilitats del primer
 * nivell, les condicionades del segon (com a text pla, «¬D» és el contrari de D), els camins
 * de l'esdeveniment que es busca i la probabilitat total.
 */
const PT = {
  peces: {primer: {F: '7/10', A: '3/10'}, fills: {F: {D: '1/10', '¬D': '9/10'}, A: {D: '4/100', '¬D': '96/100'}}, camins: [['F', 'D'], ['A', 'D']], total: '82/1000', dades: 3},
  dau: {primer: {R: '1/2', I: '1/2'}, fills: {R: {C: '8/10', '¬C': '2/10'}, I: {C: '3/10', '¬C': '7/10'}}, camins: [['R', 'C'], ['I', 'C']], total: '55/100', dades: 3},
  prova: {primer: {M: '1/10', '¬M': '9/10'}, fills: {M: {T: '9/10', '¬T': '1/10'}, '¬M': {T: '5/100', '¬T': '95/100'}}, camins: [['M', 'T'], ['¬M', 'T']], total: '135/1000', dades: 3},
  correu: {primer: {B: '3/10', '¬B': '7/10'}, fills: {B: {C: '9/10', '¬C': '1/10'}, '¬B': {C: '5/100', '¬C': '95/100'}}, camins: [['B', 'C'], ['¬B', 'C']], total: '305/1000', dades: 3},
  maquines: {primer: {A: '5/10', B: '3/10', C: '2/10'}, fills: {A: {D: '2/100', '¬D': '98/100'}, B: {D: '3/100', '¬D': '97/100'}, C: {D: '5/100', '¬D': '95/100'}},
    camins: [['A', 'D'], ['B', 'D'], ['C', 'D']], total: '29/1000', dades: 5},
  bossa: {primer: {V_1: '3/5', B_1: '2/5'}, fills: {V_1: {V_2: '2/4', B_2: '2/4'}, B_1: {V_2: '3/4', B_2: '1/4'}}, camins: [['V_1', 'V_2'], ['B_1', 'B_2']], total: '2/5', dades: 1},
};
const fraccioPT = t => { const [a, b] = t.split('/').map(Number); return fr(a, b || 1); };
/** Un valor escrit a la pissarra (text pla): «70%», «0,7», «((3)/(5))». */
const valorPT = t => (t.endsWith('%') ? valorPT(t.slice(0, -1)).quocient(100) : exacte(M.llegeix(t, {variables: []}), {variables: {}, funcions: {}}));
/** P(X) o P(Y∣X) del model, o null. */
function probabilitatPT(model, text) {
  const m = /^P\(([^∣∩]+)(?:∣(.+))?\)$/.exec(text);
  if (!m) return null;
  if (!m[2]) return model.primer[m[1]] ? fraccioPT(model.primer[m[1]]) : null;
  return model.fills[m[2]] && model.fills[m[2]][m[1]] ? fraccioPT(model.fills[m[2]][m[1]]) : null;
}

/**
 * L'arbre (TeX) d'un problema del model: les branques en ordre, amb el seu esdeveniment;
 * cada probabilitat escrita, la del model; i els productes, només als camins indicats.
 */
function comprovaArbrePT(tex, model, camins, on) {
  const primers = Object.keys(model.primer);
  const pla = textPla(tex);
  const trossos = pla.split('→⟨').slice(1);
  // L'ordre: per a cada branca del primer nivell, ella i les dues que en surten.
  const esperat = primers.flatMap(a => [[a, null]].concat(Object.keys(model.fills[a]).map(b => [a, b])));
  comprova(trossos.length === esperat.length, () => `${on}: l'arbre té ${trossos.length} branques, i n'hi ha d'haver ${esperat.length}`);
  trossos.forEach((tros, k) => {
    const [a, b] = esperat[k] || [];
    const [etiqueta, resta] = tros.split('⟩');
    const event = b === null ? a : b;
    comprova(resta.startsWith(event), () => `${on}: la branca ${k + 1} hauria de ser ${event}: «${resta}»`);
    const valor = b === null ? fraccioPT(model.primer[a]) : fraccioPT(model.fills[a][b]);
    if (etiqueta) comprova(valorPT(etiqueta).igual(valor), () => `${on}: la branca ${event} porta «${etiqueta}» i val ${valor.valor()}`);
    const producte = /^[^;{.]*?([^;{.]*\*[^;{.]*=[^;{.\[]*)/.exec(resta.slice(event.length));
    if (producte) {
      const [esq, dre] = producte[1].split('=');
      const [x, y] = esq.split('*').map(valorPT);
      comprova(b !== null && camins.some(([p, q]) => p === a && q === b) && x.igual(fraccioPT(model.primer[a])) && y.igual(valor)
        && x.producte(y).igual(valorPT(dre)), () => `${on}: el producte «${producte[1]}» de ${a} → ${b} és fals`);
    }
  });
}

/** Veritat d'un guió de probabilitat total. */
function comprovaProbabilitatTotal(passos, problema, model, nom) {
  const FILA = ProbabilitatTotal.FILA;
  const primers = Object.keys(model.primer);
  // El model es comprova a si mateix: cada nivell suma 1, i la total és la suma dels camins.
  const suma1 = vs => vs.map(fraccioPT).reduce((s, v) => s.suma(v), fr(0)).igual(1);
  comprova(suma1(Object.values(model.primer)) && primers.every(e => suma1(Object.values(model.fills[e]))), () => `${nom}: el model no suma 1`);
  const total = model.camins.map(([a, b]) => fraccioPT(model.primer[a]).producte(fraccioPT(model.fills[a][b]))).reduce((s, v) => s.suma(v));
  comprova(total.igual(fraccioPT(model.total)), () => `${nom}: el model no quadra amb la probabilitat total`);
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex || fila === FILA.enunciat || fila === FILA.llegenda) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      if (fila === FILA.arbre) {
        comprovaArbrePT(tex, model, model.camins, on);
        return;
      }
      const linies_ = fila === FILA.dades ? liniesDArray(tex) : [textPla(tex)];
      for (const l of linies_) {
        const parts = l.split('=');
        const esq = probabilitatPT(model, parts[0]);
        const pregunta = /^P\(.*\)$/.test(parts[0]) && !esq;          // P(D) o P(«mateixcolor»): la probabilitat que es busca
        const valor = esq || (pregunta ? total : null);
        comprova(valor && parts.slice(1).every(t => {
          const termes = t.includes('+') && !t.startsWith('1-') ? t.split('+') : null;
          const v = termes ? termes.map(valorPT).reduce((s, w) => s.suma(w)) : valorPT(t.replace(/^1-/, '1-'));
          return v.igual(valor);
        }), () => `${on}: «${l}» és fals`);
        if (pregunta) comprova(fila !== FILA.dades && total.igual(valor), () => `${on}: «${l}»`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 100)}»: ${e.message}`);
    }
  }));
  // Al final: totes les branques amb la seva probabilitat, els productes només als camins, la resposta i les dades marcades.
  const final = passos[passos.length - 1];
  const pla = textPla(final.files[FILA.arbre]);
  comprova(!pla.includes('→⟨⟩'), () => `${nom}: a l'arbre final hi falten probabilitats`);
  comprova((pla.match(/\*/g) || []).length === model.camins.length, () => `${nom}: l'arbre final no té un producte per camí`);
  comprova(final.classes[FILA.resposta] === 'final' && valorPT(textPla(final.files[FILA.resposta]).split('=')[1]).igual(total), () => `${nom}: la resposta final`);
  comprova(liniesDArray(final.files[FILA.dades]).length === model.dades, () => `${nom}: la llista de dades no té ${model.dades} línies`);
  const marques = [...final.files[FILA.enunciat].matchAll(/\{\{[^|]*\|([^|]*)\|/g)].map(m => m[1]);
  comprova(marques.length && marques.every(m => m === 'condicio'), () => `${nom}: hi ha frases sense marcar`);
  return linies;
}

/**
 * Colors dels camins (arbres.js): el producte del camí i-èsim dels que se sumen (Pr<a><b>) i el seu terme
 * a la suma (S<i>) han de tenir el mateix color, cami<i>, i cada camí un color diferent.
 */
function comprovaColorsCamins(llista, FILA, camins, nom) {
  llista.forEach((pas, n) => {
    const on = `${nom}, pas ${n + 1}`;
    for (const [, i, c] of (pas.files[FILA.calcul] || '').matchAll(/\\htmlData\{k=S(\d+),marca=(cami\d)\}/g)) {
      comprova(c === `cami${Number(i) % 3}`, () => `${on}: el terme ${i} de la suma té el color ${c}`);
    }
    for (const [, a, b, c] of (pas.files[FILA.arbre] || '').matchAll(/\\htmlData\{k=P[pr](\d)(\d),marca=(cami\d)\}/g)) {
      const i = camins.findIndex(([x, y]) => x === Number(a) && y === Number(b));
      comprova(i >= 0 && c === `cami${i % 3}`, () => `${on}: el camí ${a}${b} té el color ${c}`);
    }
  });
}

seccio('arbre i probabilitat total', () => {
  let linies = 0, passos = 0;
  for (const problema of ProbabilitatTotal.problemes) {
    const model = PT[problema.id];
    comprova(model, () => `${problema.id}: no hi ha model`);
    if (!model) continue;
    const llista = ProbabilitatTotal.passos({p: problema.id});
    comprovaGuio(llista, ProbabilitatTotal.files, problema.id);
    linies += comprovaProbabilitatTotal(llista, problema, model, problema.id);
    comprovaColorsCamins(llista, ProbabilitatTotal.FILA, problema.objectiu, problema.id);
    passos += llista.length;
    comprova(iguals(ProbabilitatTotal.llegeixAdreca(ProbabilitatTotal.escriuAdreca({p: problema.id})).valors, {p: problema.id}), () => `${problema.id}: adreça`);
  }
  comprova(Object.keys(PT).length === ProbabilitatTotal.problemes.length, 'models de més');
  return `${ProbabilitatTotal.problemes.length} problemes, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 12. TEOREMA DE BAYES ──────────────────────────────────────────── */

/*
 * Model de cada pregunta de Bayes, escrit aquí: P(A ∣ B) amb el camí A → B (numerador) i els
 * camins que acaben en B (denominador, si no són els de la probabilitat total). Els valors
 * surten del model PT de la secció anterior.
 */
const BY = {
  peces: {A: 'F', B: 'D'}, dau: {A: 'R', B: 'C'}, prova: {A: 'M', B: 'T'}, correu: {A: '¬B', B: 'C'}, maquines: {A: 'C', B: 'D'},
  bossa: {A: 'V_1', B: 'V_2', camins: [['V_1', 'V_2'], ['B_1', 'V_2']]},
};

/** Un resultat escrit «= v» (exacte) o «≈ v» (dins de mig ordre de l'última xifra). */
function resultatCert(relacio, text, valor) {
  const v = valorPT(text);
  if (relacio === '=') return v.igual(valor);
  const decimals = (/,(\d+)$/.exec(text) || ['', ''])[1].length;
  return v.resta(valor).abs().producte(2 * 10 ** decimals).resta(1).signe() <= 0 && !v.igual(valor);
}

/** Tanca el parèntesi que obre a «text[i]»: torna l'índex del «)» corresponent. */
function tancament(text, i) {
  let nivell = 0;
  for (let k = i; k < text.length; k++) {
    if (text[k] === '(') nivell++;
    else if (text[k] === ')' && --nivell === 0) return k;
  }
  throw new Error(`parèntesis desaparellats a «${text}»`);
}
/**
 * La fórmula de Bayes en text pla: «P(A∣B)», «P(A∣B)=((N)/(D))» o «…=((N)/(D))≈v».
 * Torna [tot, «A∣B», N, D, relació, resultat] (com un resultat d'exec), o null.
 */
function formulaBayes(pla) {
  const m = /^P\(([^)]*)\)(.*)$/.exec(pla);
  if (!m) return null;
  if (!m[2]) return [pla, m[1]];
  if (!m[2].startsWith('=((')) return null;
  const cos = m[2].slice(1), fi = tancament(cos, 0);
  const dins = cos.slice(1, fi);                   // «(N)/(D)»
  const fiN = tancament(dins, 0);
  if (dins[fiN + 1] !== '/') return null;
  const resta = cos.slice(fi + 1), r = /^(=|≈)(.*)$/.exec(resta);
  if (resta && !r) return null;
  return [pla, m[1], dins.slice(1, fiN), dins.slice(fiN + 3, -1), r && r[1], r && r[2]];
}

/** Veritat d'un guió de Bayes. */
function comprovaBayes(passos, problema, model, by, nom) {
  const FILA = Bayes.FILA;
  const camins = by.camins || model.camins;
  const prob = ([a, b]) => fraccioPT(model.primer[a]).producte(fraccioPT(model.fills[a][b]));
  comprova(camins.some(([a, b]) => a === by.A && b === by.B) && camins.every(([, b]) => b === by.B), () => `${nom}: el model de Bayes no és coherent`);
  const num = prob([by.A, by.B]), den = camins.map(prob).reduce((s, v) => s.suma(v));
  const resultat = num.quocient(den);
  const pregunta = `P(${by.A}∣${by.B})`;
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex || fila === FILA.enunciat || fila === FILA.llegenda) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      if (fila === FILA.arbre) { comprovaArbrePT(tex, model, camins, on); return; }
      const pla = textPla(tex);
      if (fila === FILA.formula) {
        const m = formulaBayes(pla);
        comprova(m && `P(${m[1]})` === pregunta, () => `${on}: «${pla}» no és ${pregunta}`);
        if (m && m[2] !== undefined) {
          const numOk = m[2] === `P(${by.A}∩${by.B})` || valorPT(m[2]).igual(num);
          const denOk = m[3] === `P(${by.B})` || valorPT(m[3]).igual(den);
          comprova(numOk && denOk, () => `${on}: «${pla}»: el numerador o el denominador no són els de Bayes`);
          if (m[4]) {
            const final = m[5].split('=');             // «1/2 = 0,5» en format fracció
            comprova(final.every((t, k) => resultatCert(k === 0 ? m[4] : '=', t, resultat)), () => `${on}: «${pla}»: el resultat val ${resultat.valor()}`);
          }
        }
      } else if (fila === FILA.calcul) {
        const parts = pla.split('=');
        comprova(parts.length === 3 && parts[0] === (by.camins ? `P(${by.B})` : parts[0]) && valorPT(parts[2]).igual(den)
          && parts[1].split('+').map(valorPT).reduce((s, v) => s.suma(v)).igual(den), () => `${on}: «${pla}» no és ${den.valor()}`);
      } else if (fila === FILA.resposta) {
        const m = /^P\(([^)]*)\)(=|≈)(.*)$/.exec(pla);
        comprova(m && `P(${m[1]})` === pregunta && m[3].split('=').every((t, k) => resultatCert(k === 0 ? m[2] : '=', t, resultat)), () => `${on}: resposta «${pla}»`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 100)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  comprova(final.classes[FILA.resposta] === 'final', () => `${nom}: la resposta no està destacada`);
  comprova((textPla(final.files[FILA.arbre]).match(/\*/g) || []).length === camins.length, () => `${nom}: l'arbre final no té un producte per camí`);
  const marques = [...final.files[FILA.enunciat].matchAll(/\{\{([^|]*)\|([^|]*)\|/g)];
  comprova(marques.every(([, k, m]) => (k === 'Eq1' ? m === 'objectiu' : m === 'condicio')), () => `${nom}: les marques de l'enunciat`);
  return linies;
}

seccio('Bayes', () => {
  let linies = 0, passos = 0;
  for (const problema of Bayes.problemes) {
    const model = PT[problema.id], by = BY[problema.id];
    comprova(model && by, () => `${problema.id}: no hi ha model`);
    if (!model || !by) continue;
    const llista = Bayes.passos({p: problema.id});
    comprovaGuio(llista, Bayes.files, problema.id);
    linies += comprovaBayes(llista, problema, model, by, problema.id);
    comprovaColorsCamins(llista, Bayes.FILA, problema.bayes.objectiu || problema.objectiu, problema.id);
    // Quan s'escriu P(A | B), la llegenda ja diu què vol dir cada lletra.
    const primeraFormula = llista.findIndex(pas => pas.files[Bayes.FILA.formula]);
    comprova(primeraFormula > 0 && Boolean(llista[primeraFormula].files[Bayes.FILA.llegenda]), () => `${problema.id}: P(A | B) surt abans que la llegenda`);
    passos += llista.length;
  }
  // L'arrodoniment: «≈» exigeix que el valor no sigui exacte i que la diferència sigui com a màxim mitja unitat de l'última xifra.
  comprova(resultatCert('≈', '0,8537', fr(35, 41)) && !resultatCert('≈', '0,8536', fr(35, 41)) && !resultatCert('≈', '0,5', fr(1, 2)), 'resultatCert');
  return `${Bayes.problemes.length} problemes, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 13. DISTRIBUCIÓ BINOMIAL ──────────────────────────────────────── */

/*
 * Aritmètica exacta amb BigInt (les fraccions de Mates no hi arriben: 100¹⁰ = 10²⁰).
 * Un racional és {n, d}, amb d > 0.
 */
const Bq = (n, d = 1n) => ({n: BigInt(n), d: BigInt(d)});
const sumaB = (a, b) => Bq(a.n * b.d + b.n * a.d, a.d * b.d);
const restaB = (a, b) => Bq(a.n * b.d - b.n * a.d, a.d * b.d);
const producteB = (a, b) => Bq(a.n * b.n, a.d * b.d);
const igualB = (a, b) => a.n * b.d === b.n * a.d;
const absB = a => Bq(a.n < 0n ? -a.n : a.n, a.d);
const finsB = (a, b) => a.n * b.d <= b.n * a.d;          // a ≤ b
const factorialB = n => (n <= 1 ? 1n : BigInt(n) * factorialB(n - 1));
const SIMBOLS_B = ['=', '≥', '≤', '>', '<'];             // les relacions de l'editor, en ordre

/** Un nombre de la pissarra (text pla): «0,0146», «12», «4,2*10^(-5)». {valor, mitja}: mitja és mitja unitat de l'última xifra. */
function llegeixB(t) {
  const m = /^(\d+)(?:,(\d+))?(?:\*10\^\((-?\d+)\))?$/.exec(t);
  if (!m) throw new Error(`«${t}» no és un nombre previst`);
  const dec = m[2] || '', e = m[3] ? BigInt(m[3]) : 0n;
  const escala = e >= 0n ? Bq(10n ** e) : Bq(1n, 10n ** -e);
  return {valor: producteB(Bq(BigInt(m[1] + dec), 10n ** BigInt(dec.length)), escala), mitja: producteB(Bq(1n, 2n * 10n ** BigInt(dec.length)), escala)};
}
/** «= t» exacte, o «≈ t» arrodonit: no exacte, i dins de mitja unitat de l'última xifra (més «marge»). */
function certB(relacio, t, valor, marge = Bq(0)) {
  const x = llegeixB(t);
  if (relacio === '=') return igualB(x.valor, valor);
  return relacio === '≈' && !igualB(x.valor, valor) && finsB(absB(restaB(x.valor, valor)), sumaB(x.mitja, marge));
}
/** P(X r m), en text pla, com a indicador: [0 o 1 per a cada valor 0…n de X]. */
function conjuntB(t, n) {
  const m = /^P\(X(=|≥|≤|>|<)(\d+)\)$/.exec(t);
  if (!m) throw new Error(`«${t}» no és P(X r m)`);
  const k = Number(m[2]);
  const entra = {'=': j => j === k, '≥': j => j >= k, '≤': j => j <= k, '>': j => j > k, '<': j => j < k}[m[1]];
  return Array.from({length: n + 1}, (_, j) => (entra(j) ? 1 : 0));
}
/** Una combinació de probabilitats («P(X=0)+P(X=1)», «1-P(X≤1)», «1-[…]») com a suma d'indicadors. */
function indicadorB(t, n) {
  if (t.startsWith('1-')) {
    const r = t.slice(2), dins = r.startsWith('[') && r.endsWith(']') ? r.slice(1, -1) : r;
    return indicadorB(dins, n).map(x => 1 - x);
  }
  const termes = t.split('+');
  const parts = termes.map((u, i) => {
    if (u !== '…') return conjuntB(u, n);
    // «P(X=a)+…+P(X=b)»: els valors entre a i b (com a mínim dos), sense comptar-los.
    const [a, b] = [termes[i - 1], termes[i + 1]].map(w => /^P\(X=(\d+)\)$/.exec(w || ''));
    if (!a || !b || Number(b[1]) - Number(a[1]) < 3) throw new Error(`«…» mal posat a «${t}»`);
    return Array.from({length: n + 1}, (_, j) => (j > Number(a[1]) && j < Number(b[1]) ? 1 : 0));
  });
  return parts.reduce((s, c) => s.map((x, j) => x + c[j]));
}

/**
 * Veritat d'un guió de la binomial, amb un model calculat aquí: P(X = j) amb factorials,
 * en BigInt. Files: les dades (n; p, en % i en tant per u; q = 1 − p; X ~ B(n; p)); la
 * fórmula; la pregunta descomposta (mateix conjunt de valors de X, comptats una vegada);
 * cada cas (substitució i valor, exacte o ben arrodonit); la suma (amb el marge dels
 * arrodoniments) i la resposta. I el camí: es calculen els casos de la pregunta o, si en
 * té menys, els del contrari.
 */
function comprovaBinomial(passos, v, nom) {
  const FILA = Binomial.FILA;
  const prob = j => Bq(factorialB(v.n) / (factorialB(j) * factorialB(v.n - j)) * BigInt(v.p) ** BigInt(j) * BigInt(100 - v.p) ** BigInt(v.n - j), 100n ** BigInt(v.n));
  const P = `P(X${SIMBOLS_B[v.r]}${v.k})`;
  const S = conjuntB(P, v.n);
  const exacte = S.reduce((s, x, j) => (x ? sumaB(s, prob(j)) : s), Bq(0));
  const pB = Bq(v.p, 100), qB = Bq(100 - v.p, 100);
  const iguals = (a, b) => a.length === b.length && a.every((x, j) => x === b[j]);
  let linies = 0, termes = [];
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      if (fila === FILA.dades) {
        // Una dada per línia: «fórmula & \quad\textcolor{…}{\text{què és}}»; es comprova la fórmula.
        const m0 = /^\\begin\{array\}\{ll\}(.*)\\end\{array\}$/.exec(tex.trim());
        comprova(Boolean(m0), () => `${on}: les dades no són una taula d'una dada per línia`);
        const linies = m0 ? m0[1].split(/\\\\\[\d+pt\]/) : [];
        comprova(linies.every(l => /&\s*\\quad\\textcolor\{#64748b\}\{\\small\\text\{[^}]+\}\}\s*$/.test(l)), () => `${on}: a cada dada li falta què és`);
        const trossos = linies.map(l => textPla(l.split('&')[0].trim()));
        comprova(trossos[0] === `n=${v.n}`, () => `${on}: «${trossos[0]}»`);
        const [nomP, ...ps] = trossos[1].split('=');
        comprova(nomP === 'p' && ps.length && ps.every(t => (t.endsWith('%') ? igualB(llegeixB(t.slice(0, -1)).valor, Bq(v.p)) : igualB(llegeixB(t).valor, pB)))
          && ps[0].endsWith('%') === (v.mode === 'cent'), () => `${on}: «${trossos[1]}»`);
        if (trossos[2]) {
          const m = /^q=1-p=(.*)$/.exec(trossos[2]);
          comprova(m && igualB(llegeixB(m[1]).valor, qB), () => `${on}: «${trossos[2]}»`);
        }
        if (trossos[3]) {
          const m = /^X∼B\((\d+);(.*)\)$/.exec(trossos[3]);
          comprova(m && Number(m[1]) === v.n && igualB(llegeixB(m[2]).valor, pB), () => `${on}: «${trossos[3]}»`);
        }
        comprova(trossos.length <= 4, () => `${on}: massa dades`);
      } else if (fila === FILA.formula) {
        comprova(textPla(tex) === 'P(X=k)=C(n,k)*p^(k)*q^(n-k)', () => `${on}: «${textPla(tex)}»`);
      } else if (fila === FILA.pregunta) {
        const m = /^(P\(X[^)]*\))=(.*)$/.exec(textPla(tex));
        comprova(m && m[1] === P && iguals(indicadorB(m[2], v.n), S), () => `${on}: «${textPla(tex)}» no és la mateixa probabilitat`);
      } else if (fila === FILA.termes) {
        // El lila (cas actual): com a molt un, a l'última línia, i el mateix cas marcat a la pregunta si hi surt.
        const marcats = (tex.match(/marca=actual/g) || []).length;
        const ultimaMarcada = /marca=actual[^\\]*$|marca=actual(?!.*\\\\\[)/.test(tex);
        comprova(marcats <= 1 && (!marcats || ultimaMarcada), () => `${on}: el cas en lila no és l'últim`);
        const mPreg = /\\htmlData\{marca=actual\}\{P\(X = (\d+)\)\}/.exec(pas.files[FILA.pregunta] || '');
        const mTerme = /\\htmlData\{k=T(\d+)l,marca=actual\}/.exec(tex);
        comprova(!mPreg || (mTerme && mTerme[1] === mPreg[1]), () => `${on}: el lila de la pregunta i el del cas no coincideixen`);
        termes = liniesDArray(tex).map(l => {
          const m = /^P\(X=(\d+)\)=C\((\d+),(\d+)\)\*([\d,]+)\^\((\d+)\)\*([\d,]+)\^\((\d+)\)(?:(=|≈)(.+))?$/.exec(l);
          if (!m) throw new Error(`cas «${l}» no previst`);
          const j = Number(m[1]);
          comprova(Number(m[2]) === v.n && Number(m[3]) === j && igualB(llegeixB(m[4]).valor, pB) && Number(m[5]) === j
            && igualB(llegeixB(m[6]).valor, qB) && Number(m[7]) === v.n - j, () => `${on}: la substitució «${l}» és falsa`);
          if (m[8]) comprova(certB(m[8], m[9], prob(j)), () => `${on}: «${l}»: P(X=${j}) val ${prob(j).n}/${prob(j).d}`);
          return {j, valor: m[9]};
        });
      } else if (fila === FILA.suma) {
        const pla = tex.startsWith('\\begin{array}') ? liniesDArray(tex).join('') : textPla(tex);
        const m = /^(P\(X[^)]*\))(=|≈)(.*)(=|≈)([^=≈]*)$/.exec(pla);
        if (!m) throw new Error('suma no prevista');
        const contrari = m[3].startsWith('1-');
        const cos = contrari ? m[3].slice(2).replace(/^\[(.*)\]$/, '$1') : m[3];
        const xs = cos.split('+').map(llegeixB);
        const suma = xs.reduce((s, x) => sumaB(s, x.valor), Bq(0)), marge = xs.reduce((s, x) => sumaB(s, x.mitja), Bq(0));
        const mig = contrari ? restaB(Bq(1), suma) : suma;
        comprova(m[1] === P && iguals(cos.split('+'), termes.map(t => t.valor)), () => `${on}: la suma no és la dels casos calculats`);
        comprova(m[2] === '=' ? igualB(mig, exacte) : finsB(absB(restaB(mig, exacte)), marge), () => `${on}: «${m[3]}» no és ${P}`);
        comprova(m[4] === '=' ? m[2] === '=' && certB('=', m[5], exacte) : finsB(absB(restaB(llegeixB(m[5]).valor, exacte)), llegeixB(m[5]).mitja),
          () => `${on}: el total «${m[5]}» no és ${P} = ${exacte.n}/${exacte.d}`);
      } else if (fila === FILA.resposta) {
        const m = /^(P\(X[^)]*\))(=|≈)(.*)$/.exec(textPla(tex));
        comprova(m && m[1] === P && certB(m[2], m[3], exacte), () => `${on}: resposta «${textPla(tex)}»`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  // El camí: els casos de la pregunta o els del contrari, el més curt (si empaten, directament).
  const final = passos[passos.length - 1];
  const nS = S.filter(Boolean).length, nC = v.n + 1 - nS;
  const calculats = Array.from({length: v.n + 1}, (_, j) => (termes.some(t => t.j === j) ? 1 : 0));
  const perContrari = nC < nS;
  comprova(termes.length === Math.min(nS, nC) && iguals(calculats, perContrari ? S.map(x => 1 - x) : S), () => `${nom}: no calcula els casos del camí més curt`);
  comprova(!perContrari || textPla(final.files[FILA.pregunta]).startsWith(`${P}=1-`), () => `${nom}: el contrari no surt a la pregunta`);
  comprova(final.classes[FILA.resposta] === 'final', () => `${nom}: la resposta no està destacada`);
  comprova(passos.some(pas => pas.files[FILA.dades].includes('\\sim')) && passos.some(pas => /\\binom\{n\}/.test(pas.files[FILA.formula])), () => `${nom}: falten la distribució o la fórmula`);
  // El text de la resposta: el mateix valor, i el percentatge (si n'hi ha), exacte o ben arrodonit.
  const text = final.text;
  const r = /^(P\(X[^)]*\))(=|≈)(.*)$/.exec(textPla(final.files[FILA.resposta]));
  const valor = /és (aproximadament )?\$([^$]*)\$/.exec(text);
  comprova(valor && valor[2].replace('{,}', ',').replace(/\s/g, '') === r[3].replace(/\*/g, '\\cdot') .replace(/\(([^)]*)\)$/, '{$1}') || valor && textPla(valor[2]) === r[3],
    () => `${nom}: el text de la resposta no diu el valor de la pissarra`);
  comprova(valor && Boolean(valor[1]) === (r[2] === '≈'), () => `${nom}: «aproximadament» al text de la resposta`);
  const pc = /un \$([^$]*)\\,\\%\$/.exec(text);
  if (pc) {
    const aprox = /aproximadament un \$/.test(text);
    comprova(certB(aprox ? '≈' : '=', textPla(pc[1]), producteB(exacte, Bq(100))), () => `${nom}: el percentatge «${pc[1]}» és fals`);
  } else {
    comprova(finsB(producteB(exacte, Bq(100)), Bq(5, 1000)), () => `${nom}: falta el percentatge`);
  }
  return linies;
}

seccio('distribució binomial', () => {
  const L = p => Binomial.llegeixAdreca(p);
  const d = (n, p, r, k, mode) => ({n, p, r, k, mode});
  for (const [p, esperat] of [
    [{}, d(5, 25, 1, 4, 'cent')], [{n: '10', p: '0,1', r: 'gt', k: '1'}, d(10, 10, 3, 1, 'u')], [{n: '8', pc: '30', r: 'le', k: '2'}, d(8, 30, 2, 2, 'cent')],
    [{n: '6', p: '0.5', r: 'eq', k: '3'}, d(6, 50, 0, 3, 'u')], [{n: '3', pc: '5', r: 'lt', k: '1'}, d(3, 5, 4, 1, 'cent')],
  ]) comprova(iguals(L(p).valors, esperat), () => `Binomial.llegeixAdreca(${JSON.stringify(p)}) → ${JSON.stringify(L(p))}`);
  for (const [p, patro] of [
    [{p: '0,25', pc: '25'}, /alhora/], [{r: 'ne'}, /eq, ge, le, gt o lt/], [{n: '11'}, /entre 1 i 10/], [{n: '0'}, /entre 1 i 10/], [{n: '2,5'}, /enter/],
    [{p: '0,125'}, /dues xifres decimals/], [{pc: '12,5'}, /dues xifres decimals/], [{p: '1'}, /de 0,01 a 0,99/], [{pc: '0'}, /de 0,01 a 0,99/],
    [{k: '6'}, /de 0 a n = 5/], [{r: 'ge', k: '0'}, /Tots els valors/], [{r: 'gt', k: '5'}, /Cap valor/], [{r: 'lt', k: '0'}, /Cap valor/],
    [{r: 'le', k: '5'}, /Tots els valors/], [{n: 'x'}, /^No entenc l'adreça/],
  ]) comprova(patro.test(L(p).error || ''), () => `Binomial.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  for (const v of Binomial.exemples) comprova(Binomial.valida(v) === null, () => `l'exemple ${JSON.stringify(v)} no és vàlid`);
  for (const [n, k, c] of [[10, 5, 252n], [10, 0, 1n], [7, 3, 35n], [1, 1, 1n]]) comprova(Binomial.combinatori(n, k) === c, () => `C(${n}, ${k})`);

  const casos = Binomial.exemples.slice();
  for (const p of [1, 5, 10, 13, 25, 30, 37, 50, 63, 75, 90, 99]) {
    for (let n = 1; n <= 10; n++) for (let r = 0; r < 5; r++) for (let k = 0; k <= n; k++) casos.push(d(n, p, r, k, (n + k + r) % 2 ? 'u' : 'cent'));
  }
  const atzar = aleatori(2031);
  const enter = (min, max) => min + Math.floor(atzar() * (max - min + 1));
  for (let i = 0; i < 2000; i++) { const n = enter(1, 10); casos.push(d(n, enter(1, 99), enter(0, 4), enter(0, n), atzar() < 0.5 ? 'u' : 'cent')); }
  let valids = 0, linies = 0, passos = 0, contrari = 0, cientifica = 0, arrodonits = 0;
  for (const v of casos) {
    if (Binomial.valida(v)) continue;
    valids++;
    const nom = `n = ${v.n}, p = ${v.p}/100 (${v.mode}), P(X ${SIMBOLS_B[v.r]} ${v.k})`;
    comprova(iguals(L(Binomial.escriuAdreca(v)).valors, v), () => `${nom}: anada i tornada de l'adreça`);
    let llista;
    try {
      llista = Binomial.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, Binomial.files, nom);
    linies += comprovaBinomial(llista, v, nom);
    passos += llista.length;
    const final = llista[llista.length - 1];
    if (final.files[Binomial.FILA.pregunta].includes('1 -')) contrari++;
    if (final.files[Binomial.FILA.resposta].includes('10^')) cientifica++;
    if (final.files[Binomial.FILA.suma].includes('\\approx')) arrodonits++;
  }
  comprova(contrari > 0 && cientifica > 0 && arrodonits > 0, 'la mostra no té casos pel contrari, en notació científica o amb sumes arrodonides');
  return `${valids} casos vàlids, ${passos} passos, ${linies} línies comprovades (${contrari} pel contrari, ${cientifica} en notació científica, ${arrodonits} sumes amb arrodoniments)`;
});


/* ── 14. DETERMINANT 3×3 AMB UN PARÀMETRE (SARRUS) ─────────────────── */

/** Els grups amb clau d'un TeX: {clau: {tex, marca}} (el contingut, amb les claus de dins). */
function grupsAmbClau(tex) {
  const r = {};
  const re = /\\htmlData\{([^}]*)\}\{/g;
  let m;
  while ((m = re.exec(tex))) {
    const atributs = Object.fromEntries(m[1].split(',').map(x => x.split('=')));
    let i = re.lastIndex, nivell = 1;
    const inici = i;
    while (nivell && i < tex.length) {
      if (tex[i] === '\\') i++;                    // «\{» i «\}» no compten (són claus escrites, com a \left\{)
      else if (tex[i] === '{') nivell++;
      else if (tex[i] === '}') nivell--;
      i++;
    }
    if (nivell) throw new Error('claus desaparellades');
    r[atributs.k] = {tex: tex.slice(inici, i - 1), marca: atributs.marca || ''};
  }
  return r;
}
/** Els elements (TeX) d'una matriu «\begin{pmatrix} … \end{pmatrix}» (o vmatrix) d'una fila. */
function elementsDeMatriu(tex) {
  const m = /\\begin\{([pv])matrix\}(.*)\\end\{\1matrix\}/.exec(tex);
  if (!m) throw new Error('no hi ha cap matriu');
  return {tipus: m[1], files: m[2].split('\\\\').map(f => f.split('&').map(c => c.trim()))};
}

const PUNTS_DET = [-3, -2, -1, 0, 1, 2, 3, 5].map(t => fr(t));
/** Valor exacte d'un text pla en la variable X, al punt t. */
const valorX = (text, X, t) => exacte(M.llegeix(text, {variables: [X]}), {variables: {[X]: t}, funcions: {}});
/** Determinant numèric 3×3, desenvolupat per la primera fila (no per Sarrus). */
const detLaplace = B => B[0][0].producte(B[1][1].producte(B[2][2]).resta(B[1][2].producte(B[2][1])))
  .resta(B[0][1].producte(B[1][0].producte(B[2][2]).resta(B[1][2].producte(B[2][0]))))
  .suma(B[0][2].producte(B[1][0].producte(B[2][1]).resta(B[1][1].producte(B[2][0]))));

/** Arrels racionals de p (coeficients Fraccio, de grau 0 cap amunt), amb el teorema de les arrels racionals; null si n'hi ha d'irracionals. */
function arrelsX(p) {
  p = p.slice();
  while (p.length && p[p.length - 1].esZero()) p.pop();
  if (!p.length) throw new Error('l\'equació és 0 = 0');
  const arrels = [];
  while (p.length > 1 && p[0].esZero()) { arrels.push(fr(0)); p.shift(); }
  const L = p.reduce((l, c) => l / M.mcd(l, c.den) * c.den, 1);
  const enters = () => p.map(c => c.producte(L).num);
  const divs = n => Array.from({length: Math.abs(n)}, (_, i) => i + 1).filter(d => n % d === 0);
  let canvi = true;
  while (canvi && p.length > 1) {
    canvi = false;
    const a = enters();
    for (const d of divs(a[0])) for (const e of divs(a[a.length - 1])) for (const s of [1, -1]) {
      if (canvi) continue;
      const r = fr(s * d, e);
      if (!p.reduce((v, c, i) => v.suma(c.producte(r.potencia(i))), fr(0)).esZero()) continue;
      arrels.push(r);
      // Divideix per (X − r): coeficients de més a menys grau.
      const dalt = p.slice().reverse(), baix = [dalt[0]];
      for (let i = 1; i < dalt.length - 1; i++) baix.push(dalt[i].suma(baix[i - 1].producte(r)));
      p = baix.reverse();
      canvi = true;
    }
  }
  if (p.length === 1) return arrels;
  if (p.length === 3) {
    const disc = p[1].producte(p[1]).resta(p[0].producte(p[2]).producte(4));
    return disc.signe() < 0 ? arrels : null;
  }
  return null;
}
/** Solucions d'una fila (text pla) en la variable X: «|» és «o»; «X=a±b»; o una equació polinòmica. */
function solucionsX(pla, X) {
  const valors = [];
  for (const part of pla.split('|')) {
    const costats = part.split('=');
    if (costats.length !== 2) throw new Error(`«${part}» no és una equació`);
    const [e, d] = costats;
    if (part.includes('±')) {
      if (e !== X) throw new Error(`«${part}»: amb ± hi ha d'haver ${X} a l'esquerra`);
      for (const s of ['+', '-']) {
        try {
          valors.push(exacte(M.llegeix(d.replace('±', s), {variables: []}), {variables: {}, funcions: {}}));
        } catch (err) {
          if (!(err instanceof SenseValorReal)) throw err;
        }
      }
    } else {
      const p = M.polinomi(M.llegeix(`(${e})-(${d})`, {variables: [X]}), X);
      if (!p) throw new Error(`«${part}» no és polinòmica`);
      const r = arrelsX(p);
      if (!r) throw new Error(`«${part}» té solucions irracionals`);
      valors.push(...r);
    }
  }
  return conjunt(valors);
}

/**
 * Veritat d'un guió del determinant, amb un model calculat aquí: la matriu llegida de les
 * dades i el determinant desenvolupat per la primera fila, en 8 punts (el determinant és
 * de grau ≤ 3). Files: la matriu (els seus elements, i a cada producte de Sarrus, marcats
 * exactament els tres elements del producte, verds si és + i vermells si és −); els
 * productes (cada un, el de la seva posició, amb els factors en ordre de files, i la
 * fila sencera igual a |A|); el càlcul (sempre igual a |A|; al final, agrupat); les
 * equacions (mateixes solucions que |A| = 0, i la factoritzada, proporcional a |A|);
 * les proves d'arrels; la taula de Ruffini; l'equació de segon grau; la resposta.
 */
const textPlaBase = textPla, liniesDArrayBase = liniesDArray;
function comprovaDeterminant(passos, v, nom, opcions = {}) {
  // λ es llegeix com la variable «L» (Mates no coneix «λ»).
  const textPla = t => textPlaBase(t).replace(/λ/g, 'L');
  const liniesDArray = t => liniesDArrayBase(t).map(l => l.replace(/λ/g, 'L'));
  const nomD = opcions.nomDet || '|A|=';                // el nom del determinant a la pissarra, en text pla
  // opcions (per a altres pàgines): FILA (files matriu, sarrus, calcul, equacio, lliures), P (prefix de les claus de Sarrus),
  // X, A (text de la matriu 3×3), rapid (Sarrus sense marques), nomesDet (sense la resposta del determinant),
  // fase (els passos en què les files lliures són de |A| = 0: vegeu comprovadorTalls).
  const FILA = opcions.FILA || Determinant.FILA;
  const P = opcions.P || '';
  const X = opcions.X || (v.A.match(/[a-z]/) || [])[0];
  const A = (opcions.A || v.A).split(';').map(f => f.split(',').map(e => M.llegeix(e, {variables: [X]})));
  const valorA = (i, j, t) => exacte(A[i][j], {variables: {[X]: t}, funcions: {}});
  const det = t => detLaplace([0, 1, 2].map(i => [0, 1, 2].map(j => valorA(i, j, t))));
  const SARRUS_MODEL = [['00', '11', '22', '+'], ['01', '12', '20', '+'], ['02', '10', '21', '+'], ['02', '11', '20', '-'], ['00', '12', '21', '-'], ['01', '10', '22', '-']];
  const igualDet = text => PUNTS_DET.every(t => valorX(text, X, t).igual(det(t)));
  // |A| = 0: les solucions, amb un polinomi interpolat pels punts (grau ≤ 3, coeficients exactes).
  const coefsDet = (() => {
    const xs = PUNTS_DET.slice(0, 4), ys = xs.map(det);
    // Lagrange → coeficients: resol el sistema de Vandermonde 4×4 per Gauss.
    const Mx = xs.map((x, i) => [0, 1, 2, 3].map(k => x.potencia(k)).concat([ys[i]]));
    for (let c = 0; c < 4; c++) {
      const f = Mx.findIndex((r, i) => i >= c && !r[c].esZero());
      [Mx[c], Mx[f]] = [Mx[f], Mx[c]];
      for (let i = 0; i < 4; i++) if (i !== c) { const k = Mx[i][c].quocient(Mx[c][c]); Mx[i] = Mx[i].map((x, j) => x.resta(Mx[c][j].producte(k))); }
    }
    return Mx.map((r, i) => r[4].quocient(r[i]));
  })();
  comprova(PUNTS_DET.every(t => coefsDet.reduce((s, c, i) => s.suma(c.producte(t.potencia(i))), fr(0)).igual(det(t))), () => `${nom}: el model del determinant no és de grau ≤ 3`);
  const solucionsDet = conjunt(arrelsX(coefsDet) || []);
  const proporcional = text => {
    const p = M.polinomi(M.llegeix(text, {variables: [X]}), X);
    const k = coefsDet.find(c => !c.esZero()) && p && p[coefsDet.findIndex(c => !c.esZero())];
    if (!k || k.esZero()) return false;
    const r = coefsDet.find(c => !c.esZero()).quocient(k);
    return coefsDet.every((c, i) => c.igual((p[i] || fr(0)).producte(r)));
  };
  let linies = 0, sarrusVist = 0;
  const arrels = comprovadorTalls({passos, FILA, X, coefs: coefsDet, nom, nomEq: nomD.slice(0, -1), fase: opcions.fase, textPla});
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      if (fila === FILA.matriu) {
        const {tipus, files} = elementsDeMatriu(tex);
        comprova(files.length === 3 && files.every((f, a) => f.length === 3 && f.every((c, b) => PUNTS_DET.every(t => valorX(textPla(c), X, t).igual(valorA(a, b, t))))),
          () => `${on}: la matriu no és A`);
        const nomM = textPla(tex.slice(0, tex.indexOf('\\begin')));
        comprova(nomM === (tipus === 'p' ? 'A=' : nomD), () => `${on}: «${nomM}» davant de la matriu`);
        // Les marques: res, o exactament un producte de Sarrus (el que s'afegeix en aquest pas).
        const marcats = Object.entries(grupsAmbClau(tex)).filter(([, g]) => g.marca).map(([k, g]) => [k.slice(P.length + 1), g.marca]);
        if (marcats.length) {
          const n = Object.keys(grupsAmbClau(pas.files[FILA.sarrus] || '')).filter(k => new RegExp(`^${P}S\\d$`).test(k)).length - 1;
          const s = SARRUS_MODEL[n];
          comprova(s && marcats.length === 3 && marcats.every(([ij, mc]) => s.slice(0, 3).includes(String(Number(ij[0]) - 1) + String(Number(ij[1]) - 1)) && mc === (s[3] === '+' ? 'mes' : 'menys')),
            () => `${on}: les marques ${JSON.stringify(marcats)} no són les del producte ${n + 1} de Sarrus`);
          sarrusVist = Math.max(sarrusVist, n + 1);
        }
      } else if (fila === FILA.sarrus) {
        const grups = grupsAmbClau(tex);
        const n = Object.keys(grups).filter(k => new RegExp(`^${P}S\\d$`).test(k)).length;
        for (let k = 0; k < n; k++) {
          const factors = textPla(grups[`${P}S${k}`].tex).split('*');
          const s = SARRUS_MODEL[k];
          comprova(factors.length === 3 && factors.every((f, q) => PUNTS_DET.every(t => valorX(f, X, t).igual(valorA(Number(s[q][0]), Number(s[q][1]), t)))),
            () => `${on}: el producte ${k + 1} («${factors.join('·')}») no és el de Sarrus`);
        }
        const pla = tex.startsWith('\\begin{array}') ? liniesDArray(tex).join('') : textPla(tex);
        comprova(pla.startsWith(nomD), () => `${on}: «${pla}»`);
        if (n === 6) comprova(igualDet(pla.slice(nomD.length)), () => `${on}: «${pla}» no és |A|`);
        // Els signes dels productes: + els tres primers, − els tres últims.
        const ops = tex.replace(/\\htmlData\{[^}]*\}\{(?:[^{}]|\{[^{}]*\})*\}/g, 'P').replace(/\\begin\{array\}\{l\}|\\end\{array\}|\\\\\[4pt\]|\\qquad|\\mathrel|\{|\}|=|\s/g, '');
        // Els claudàtors: [P + P + P] - [P + P + P], cada un tancat després de l'últim producte que ja hi és.
        const esperatOps = Array.from({length: n}, (_, k) => (k === 0 ? '\\lbrack' : k === 3 ? '-\\lbrack' : '+') + 'P'
          + (k === Math.min(n, 3) - 1 || (k >= 3 && k === n - 1) ? '\\rbrack' : '')).join('');
        comprova(ops === 'PP' + esperatOps, () => `${on}: els claudàtors i signes dels productes («${ops}»)`);
      } else if (fila === FILA.calcul) {
        const pla = tex.startsWith('\\begin{array}') ? liniesDArray(tex).join('') : textPla(tex);
        comprova(pla.startsWith(nomD) && igualDet(pla.slice(nomD.length)), () => `${on}: «${pla}» no és |A|`);
      } else if (arrels.fila(tex, fila, i, on)) {
        // (les files de les arrels: comprovadorTalls)
      } else if (fila === FILA.resposta) {
        const pla = textPla(tex);
        const m = /^\|A\|=0⇔(.*)$/.exec(pla);
        comprova(m ? solucionsX(m[1], X) === solucionsDet : pla === `|A|≠0«peratot»${X}` && solucionsDet === '', () => `${on}: resposta «${pla}» (les solucions són ${solucionsDet})`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  if (!opcions.rapid) comprova(sarrusVist === 6, () => `${nom}: no es marquen els sis productes de Sarrus (${sarrusVist})`);
  if (!opcions.nomesDet) comprova(final.classes[FILA.resposta] === 'final', () => `${nom}: la resposta no està destacada`);
  // El càlcul final, agrupat: un terme per grau, sense zeros ni parèntesis.
  const calcul = grupsAmbClau(final.files[FILA.calcul]);
  comprova(Object.keys(calcul).filter(k => new RegExp(`^${P}C\\d$`).test(k)).length === Object.keys(calcul).length - 2 && !/[()]/.test(final.files[FILA.calcul]),
    () => `${nom}: el càlcul final no està agrupat`);
  arrels.final();
  // El text final: «invertible si i només si m ≠ …» amb totes les solucions.
  if (opcions.nomesDet) return {linies, solucionsDet};
  const diferents = [...final.text.matchAll(new RegExp(`\\$${X} \\\\neq (-?[\\d]+|-?\\\\frac\\{\\d+\\}\\{\\d+\\})\\$`, 'g'))].map(m => exacte(M.llegeix(textPla(m[1]), {variables: []}), {variables: {}, funcions: {}}));
  comprova(conjunt(diferents) === solucionsDet, () => `${nom}: el text final diu que A no és invertible per a ${conjunt(diferents)}, i és per a ${solucionsDet}`);
  return linies;
}

seccio('determinant amb paràmetre', () => {
  const L = p => Determinant.llegeixAdreca(p);
  for (const [p, esperat] of [
    [{}, 'm,1,1;1,m,1;1,1,m'], [{A: 'k, 1, 2; 1, k, 0; 0, 1, 1'}, 'k,1,2;1,k,0;0,1,1'], [{A: '1,2,3;0,m,1;1,0,2'}, '1,2,3;0,m,1;1,0,2'],
    [{A: 'm+1,1,1;1,m,1;1,1,1-m'}, null], [{A: '2a,1,0;1,a,1;0,1,a-1'}, null],
  ]) {
    const r = L(p);
    comprova(esperat ? r.valors && r.valors.A === esperat : true, () => `Determinant.llegeixAdreca(${JSON.stringify(p)}) → ${JSON.stringify(r)}`);
  }
  for (const [p, patro] of [
    [{A: '1,2,3;4,5,6;7,8,9'}, /paràmetre/], [{A: 'm,1;1,m'}, /3 files/], [{A: 'm,1,1;1,m;1,1,m'}, /fila 2 ha de tenir 3/], [{A: 'm,k,1;1,m,1;1,1,m'}, /més d'una lletra/],
    [{A: 'x,1,1;1,x,1;1,1,x'}, /«x» no es pot fer servir/], [{A: 'm^2,1,1;1,m,1;1,1,m'}, /ha de ser un nombre enter/], [{A: '10,1,1;1,m,1;1,1,m'}, /de −9 a 9/],
    [{A: 'm,1,1;1,m,1;1,1,'}, /buit/], [{A: '1,0,0;0,1,0;0,0,m-m+1'}, /paràmetre|no depèn/], [{A: 'm,1,0;1,m,1;0,1,m'}, /irracionals/],
    [{A: '1/2,1,1;1,m,1;1,1,m'}, /enter/], [{A: 'm,1,1;1,m,1;1,1,(m'}, /^No entenc/],
  ]) comprova(patro.test(L(p).error || ''), () => `Determinant.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  for (const v of Determinant.exemples) comprova(Determinant.valida(v) === null, () => `l'exemple ${v.A} no és vàlid: ${Determinant.valida(v)}`);
  // Les arrels del comprovador, i Ruffini de matrius.js, en uns quants casos.
  comprova(conjunt(arrelsX([fr(2), fr(-3), fr(0), fr(1)])) === '-2,1' && arrelsX([fr(-2), fr(0), fr(1)]) === null && conjunt(arrelsX([fr(1), fr(0), fr(1)])) === '', 'arrelsX');

  const casos = Determinant.exemples.map(v => v.A);
  const atzar = aleatori(2033);
  const ELEMENTS = ['m', 'm+1', 'm-1', '2m', '-m', '1-m', '2m-1', '-1', '0', '0', '1', '1', '2', '3', '-2'];
  for (let i = 0; i < 2500; i++) {
    const X = ['m', 'm', 'm', 'k', 'a', 'p', 't'][Math.floor(atzar() * 7)];
    casos.push(Array.from({length: 3}, () => Array.from({length: 3}, () => ELEMENTS[Math.floor(atzar() * ELEMENTS.length)].replace(/m/g, X)).join(',')).join(';'));
  }
  let valids = 0, linies = 0, passos = 0;
  const tipus = {};
  for (const text of casos) {
    const r = L({A: text});
    if (r.error) continue;
    const v = r.valors;
    valids++;
    const nom = `A = ${v.A}`;
    comprova(L(Determinant.escriuAdreca(v)).valors.A === v.A, () => `${nom}: anada i tornada de l'adreça`);
    let llista;
    try {
      llista = Determinant.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, Determinant.files, nom);
    linies += comprovaDeterminant(llista, v, nom);
    passos += llista.length;
    const f = llista[llista.length - 1].files;
    const t = llista.some(q => q.files.some(x => x.startsWith('\\begin{array}{r|'))) ? 'Ruffini' : /^\\htmlData\{k=Ef[,}]/.test(f[Determinant.FILA.equacio]) ? 'factor comú'
      : f[Determinant.FILA.resposta].includes('\\neq') ? 'sense solucions' : 'grau ≤ 2';
    tipus[t] = (tipus[t] || 0) + 1;
  }
  comprova(['Ruffini', 'factor comú', 'sense solucions', 'grau ≤ 2'].every(t => tipus[t] > 0), () => `falten tipus de casos: ${JSON.stringify(tipus)}`);
  return `${valids} matrius vàlides, ${passos} passos, ${linies} línies comprovades (${Object.entries(tipus).map(([k, n]) => `${k} ${n}`).join(', ')})`;
});


/* ── 15. RANG D'UNA MATRIU (ORLANT MENORS) ─────────────────────────── */

/** Rang per Gauss (el model: un altre mètode que el de la pàgina). */
function rangGauss(N) {
  const B = N.map(f => f.slice());
  let r = 0;
  for (let c = 0; c < B[0].length && r < B.length; c++) {
    const f = B.findIndex((x, i) => i >= r && !x[c].esZero());
    if (f < 0) continue;
    [B[r], B[f]] = [B[f], B[r]];
    for (let i = r + 1; i < B.length; i++) { const k = B[i][c].quocient(B[r][c]); B[i] = B[i].map((x, j) => x.resta(B[r][j].producte(k))); }
    r++;
  }
  return r;
}
/** Determinant d'un menor quadrat (1, 2 o 3), per cofactors. */
const detMenor = B => (B.length === 1 ? B[0][0] : B.length === 2 ? B[0][0].producte(B[1][1]).resta(B[0][1].producte(B[1][0])) : detLaplace(B));
/** Les files de nombres d'una «\begin{vmatrix} … \end{vmatrix}». */
const nombresDeMatriu = tex => elementsDeMatriu(tex).files.map(f => f.map(c => M.llegeixNombre(textPla(c))));
/** Tots els llocs on és B dins de N: [{fs, cs}]. */
function llocsDeMenor(N, B) {
  const n = B.length, r = [];
  const triar = (k, d) => (k === 0 ? [[]] : Array.from({length: d}, (_, i) => i).flatMap(i => triar(k - 1, d).filter(x => !x.length || x[0] > i).map(x => [i].concat(x))));
  for (const fs of triar(n, N.length)) for (const cs of triar(n, N[0].length)) {
    if (fs.every((i, a) => cs.every((j, b) => N[i][j].igual(B[a][b])))) r.push({fs, cs});
  }
  return r;
}
/** On és B dins de N: {fs, cs} (files i columnes, en ordre), o null. */
function llocDeMenor(N, B) {
  const n = B.length;
  const triar = (k, d) => (k === 0 ? [[]] : Array.from({length: d}, (_, i) => i).flatMap(i => triar(k - 1, d).filter(r => !r.length || r[0] > i).map(r => [i].concat(r))));
  for (const fs of triar(n, N.length)) for (const cs of triar(n, N[0].length)) {
    if (fs.every((i, a) => cs.every((j, b) => N[i][j].igual(B[a][b])))) return {fs, cs};
  }
  return null;
}

/**
 * Veritat d'un guió del rang, amb el model de Gauss. Files: la matriu (els elements, i les
 * marques: un menor, amb el no nul ja trobat en verd dins seu); l'element no nul; cada menor
 * d'ordre 2 (un tros de A que conté l'element; el càlcul a·d − b·c i el valor; «≠ 0» si no
 * és 0) i cada menor d'ordre 3 (un tros de A que conté el menor d'ordre 2 no nul; els sis
 * productes de Sarrus, en ordre i amb signe; el valor); el rang (cada «≥ k» o «= k», cert).
 * I el mètode: el rang 1 només després de provar tots els menors d'ordre 2 que contenen
 * l'element; el rang 2 (amb 3 files i columnes), després de tots els d'ordre 3 que orlen.
 */
function comprovaRang(passos, v, nom) {
  const FILA = Rang.FILA;
  const N = v.A.split(';').map(f => f.split(',').map(e => M.llegeixNombre(e)));
  const [f, c] = [N.length, N[0].length];
  const r = rangGauss(N);
  let linies = 0, base1 = null, base2 = null;
  const menors2 = new Map(), menors3 = new Map();
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const grups = grupsAmbClau(tex);
      if (fila === FILA.matriu) {
        const files = nombresDeMatriu(tex);
        comprova(files.length === f && files.every((x, a) => x.length === c && x.every((y, b) => y.igual(N[a][b]))), () => `${on}: la matriu no és A`);
        const marcats = Object.entries(grups).filter(([, g]) => g.marca).map(([k, g]) => ({i: Number(k[1]) - 1, j: Number(k[2]) - 1, marca: g.marca}));
        if (marcats.length) {
          const fs = [...new Set(marcats.map(x => x.i))].sort(), cs = [...new Set(marcats.map(x => x.j))].sort();
          const verds = marcats.filter(x => x.marca === 'mes');
          const fv = [...new Set(verds.map(x => x.i))].sort(), cv = [...new Set(verds.map(x => x.j))].sort();
          comprova(fs.length === cs.length && marcats.length === fs.length * fs.length && verds.length === fv.length * cv.length && fv.length === cv.length
            && fv.length === fs.length - (marcats.some(x => x.marca === 'tria') ? 1 : 0) && marcats.every(x => x.marca === (fv.includes(x.i) && cv.includes(x.j) ? 'mes' : 'tria'))
            && !detMenor(fv.map(a => cv.map(b => N[a][b]))).esZero(), () => `${on}: les marques ${JSON.stringify(marcats)} no són un menor orlant un menor no nul`);
        }
      } else if (fila === FILA.ordre1) {
        const m = /^a_(\d)(\d)=(-?\d+)≠0$/.exec(textPla(tex));
        comprova(m && N[m[1] - 1][m[2] - 1].igual(fr(Number(m[3]))) && !N[m[1] - 1][m[2] - 1].esZero(), () => `${on}: «${textPla(tex)}»`);
        if (m) base1 = {fs: [m[1] - 1], cs: [m[2] - 1]};
      } else if (fila === FILA.ordre2 || fila === FILA.ordre3) {
        const ordre = fila === FILA.ordre2 ? 2 : 3, P = ordre === 2 ? 'D' : 'T';
        for (let t = 0; grups[`${P}${t}m`]; t++) {
          const B = nombresDeMatriu(grups[`${P}${t}m`].tex);
          const lloc = llocDeMenor(N, B);
          const base = ordre === 2 ? base1 : base2;
          comprova(B.length === ordre && lloc && base && base.fs.every(a => lloc.fs.includes(a)) && base.cs.every(b => lloc.cs.includes(b)),
            () => `${on}: el menor ${t + 1} d'ordre ${ordre} no orla el menor no nul anterior`);
          const d = detMenor(B);
          const valor = grups[`${P}${t}v`];
          if (grups[`${P}${t}p`]) {
            const pla = textPla(grups[`${P}${t}p`].tex);
            if (ordre === 2) {
              const esperat = `${M.texEntreParentesis(B[0][0])}*${M.texEntreParentesis(B[1][1])}-${M.texEntreParentesis(B[0][1])}*${M.texEntreParentesis(B[1][0])}`;
              comprova(pla === esperat.replace(/\s/g, ''), () => `${on}: «${pla}» no és a·d − b·c`);
            } else {
              const ps = SARRUS_POS.map(s => s.slice(0, 3).reduce((p, [a, b]) => p.producte(B[a][b]), fr(1)));
              const trossos = productesSarrus(pla);
              comprova(trossos && trossos.every((x, k) => x.igual(ps[k])), () => `${on}: «${pla}» no són els productes de Sarrus`);
            }
            if (valor) comprova(valorX(pla, 'x', fr(0)).igual(d), () => `${on}: «${pla}» no val ${d.num}`);
          }
          if (valor) {
            const pv = textPla(valor.tex);
            comprova(pv === `${d.num}${d.esZero() ? '' : '≠0'}`, () => `${on}: el menor val ${d.num}, i diu «${pv}»`);
            (ordre === 2 ? menors2 : menors3).set(t, d);
            if (!d.esZero() && ordre === 2) base2 = lloc;
          }
        }
      } else if (fila === FILA.resposta) {
        const m = /^«rang»\(A\)(≥|=)(\d)$/.exec(textPla(tex));
        comprova(m && (m[1] === '=' ? r === Number(m[2]) : r >= Number(m[2])), () => `${on}: «${textPla(tex)}», i el rang és ${r}`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  comprova(final.classes[FILA.resposta] === 'final' && textPla(final.files[FILA.resposta]) === `«rang»(A)=${r}`, () => `${nom}: la resposta final no és rang(A) = ${r}`);
  // El mètode: abans de dir «rang 1» o «rang 2», s'han provat tots els menors que orlen.
  if (r === 1) comprova(menors2.size === (f - 1) * (c - 1) && [...menors2.values()].every(d => d.esZero()), () => `${nom}: rang 1 sense provar tots els menors d'ordre 2 que orlen`);
  if (r === 2 && Math.min(f, c) === 3) comprova(menors3.size === (f - 2) * (c - 2) && [...menors3.values()].every(d => d.esZero()), () => `${nom}: rang 2 sense provar tots els menors d'ordre 3 que orlen`);
  // Cap menor no nul s'ignora: després del primer menor no nul d'un ordre, no se'n calcula cap més d'aquell ordre.
  comprova([...menors2.values()].filter(d => !d.esZero()).length <= 1 && [...menors3.values()].filter(d => !d.esZero()).length <= 1, () => `${nom}: continua després d'un menor no nul`);
  return linies;
}
/**
 * Els sis productes de Sarrus d'una línia numèrica «(a+b+c)-(d+e+f)» (els claudàtors, ja en text pla, són
 * parèntesis): cada claudàtor té tres termes amb el seu signe, i cada terme és un producte. null si no té aquesta forma.
 */
function productesSarrus(pla) {
  const m = /^\(([^()]+)\)-\(([^()]+)\)$/.exec(pla);
  if (!m) return null;
  const termes = t => (t.startsWith('-') ? t : '+' + t).match(/[+-]\d+/g);
  const [u, v] = [termes(m[1]), termes(m[2])];
  if (!u || !v || u.join('') !== (m[1].startsWith('-') ? m[1] : '+' + m[1]) || v.join('') !== (m[2].startsWith('-') ? m[2] : '+' + m[2]) || u.length !== 3 || v.length !== 3) return null;
  return u.concat(v).map(x => fr(Number(x)));
}

const SARRUS_POS = [[[0, 0], [1, 1], [2, 2]], [[0, 1], [1, 2], [2, 0]], [[0, 2], [1, 0], [2, 1]], [[0, 2], [1, 1], [2, 0]], [[0, 0], [1, 2], [2, 1]], [[0, 1], [1, 0], [2, 2]]];

seccio('rang orlant menors', () => {
  const L = p => Rang.llegeixAdreca(p);
  for (const [p, esperat] of [[{}, '1,2,3;2,4,1;3,6,4'], [{A: '1, 2; 3, 4'}, '1,2;3,4'], [{A: '1,2,3,4;5,6,7,8;9,1,2,3'}, '1,2,3,4;5,6,7,8;9,1,2,3']]) {
    comprova(L(p).valors && L(p).valors.A === esperat, () => `Rang.llegeixAdreca(${JSON.stringify(p)}) → ${JSON.stringify(L(p))}`);
  }
  for (const [p, patro] of [
    [{A: 'm,1;1,2'}, /paràmetre/], [{A: '1,2,3'}, /2 o 3 files/], [{A: '1;2;3'}, /de 2 a 4 columnes/], [{A: '1,2,3,4,5;1,2,3,4,5'}, /de 2 a 4 columnes/],
    [{A: '1,2;3,4;5,6;7,8'}, /2 o 3 files/], [{A: '0,0;0,0'}, /el rang és 0/], [{A: '1,2;3'}, /fila 2 ha de tenir 2/], [{A: '1,2;3,10'}, /de −9 a 9/], [{A: '1,2;3,(4'}, /^No entenc/],
  ]) comprova(patro.test(L(p).error || ''), () => `Rang.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  for (const v of Rang.exemples) comprova(Rang.valida(v) === null, () => `l'exemple ${v.A} no és vàlid`);
  comprova(rangGauss([[fr(1), fr(2)], [fr(2), fr(4)]]) === 1 && rangGauss([[fr(0), fr(1)], [fr(1), fr(0)]]) === 2, 'rangGauss');

  const casos = Rang.exemples.map(v => v.A);
  const atzar = aleatori(2034);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  for (let i = 0; i < 3000; i++) {
    const f = enter(2, 3), c = enter(2, 4);
    const tipus = enter(0, 3);
    let N;
    if (tipus === 0) N = Array.from({length: f}, () => Array.from({length: c}, () => enter(-3, 3)));
    else {
      // Rang baix: combinacions de 1 o 2 files.
      const fonts = Array.from({length: tipus === 1 ? 1 : 2}, () => Array.from({length: c}, () => enter(-2, 2)));
      N = Array.from({length: f}, () => { const a = enter(-2, 2), b = enter(-1, 1); return fonts[0].map((x, j) => a * x + (fonts[1] ? b * fonts[1][j] : 0)); });
      if (atzar() < 0.3) N[enter(0, f - 1)][enter(0, c - 1)] += 1;
    }
    if (N.some(fl => fl.some(x => Math.abs(x) > 9))) continue;
    casos.push(N.map(fl => fl.join(',')).join(';'));
  }
  let valids = 0, linies = 0, passos = 0;
  const rangs = {};
  for (const text of casos) {
    const res = L({A: text});
    if (res.error) continue;
    const v = res.valors;
    valids++;
    const nom = `A = ${v.A}`;
    comprova(L(Rang.escriuAdreca(v)).valors.A === v.A, () => `${nom}: anada i tornada de l'adreça`);
    let llista;
    try {
      llista = Rang.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, Rang.files, nom);
    linies += comprovaRang(llista, v, nom);
    passos += llista.length;
    const N = v.A.split(';').map(fl => fl.split(',').map(e => M.llegeixNombre(e)));
    const clau = `${N.length}×${N[0].length} rang ${rangGauss(N)}`;
    rangs[clau] = (rangs[clau] || 0) + 1;
  }
  comprova(['3×3 rang 1', '3×3 rang 2', '3×3 rang 3', '3×4 rang 2', '3×4 rang 3', '2×3 rang 1', '2×3 rang 2'].every(k => rangs[k] > 0), () => `falten tipus de casos: ${JSON.stringify(rangs)}`);
  return `${valids} matrius vàlides, ${passos} passos, ${linies} línies comprovades (${Object.keys(rangs).length} tipus de forma i rang)`;
});


/* ── 16. SISTEMA COMPATIBLE INDETERMINAT ───────────────────────────── */

const PUNTS_LAMBDA = [-2, -1, 0, 1, 2, 3].map(t => fr(t));
/** Valor d'un text pla amb x, y, z i λ (que es llegeix com «t»). */
const valorXYZ = (text, vals) => exacte(M.llegeix(text.replace(/λ/g, 't'), {variables: ['x', 'y', 'z', 't']}), {variables: vals, funcions: {}});
/** Les parts d'un text separades per comes de primer nivell (fora de parèntesis). */
function partsPerComes(text) {
  const parts = [];
  let nivell = 0, ara = '';
  for (const c of text) {
    if (c === '(') nivell++;
    if (c === ')') nivell--;
    if (c === ',' && nivell === 0) { parts.push(ara); ara = ''; } else ara += c;
  }
  return parts.concat([ara]);
}
/** Els cossos (TeX) de les vmatrix d'un TeX, en ordre. */
const cossosVmatrix = tex => [...tex.matchAll(/\\begin\{vmatrix\}(.*?)\\end\{vmatrix\}/g)].map(m => m[1].split('\\\\').map(f => f.split('&').map(c => textPla(c.trim()))));

/**
 * Les matrius d'una cadena de Gauss (una fila de la pissarra: «A^* = (…)» i després «∼ (…)  etiquetes»),
 * comprovades amb l'algorisme del David: la primera és S; cada matriu nova surt de l'anterior amb les
 * operacions de les etiquetes, i només amb aquestes; Fᵢ → a·Fᵢ + b·Fⱼ amb j la fila del pivot, a = pivot i
 * b = −(l'element de sota), que queda 0; un canvi de files només si cal (pivot 0, o fila de zeros al final);
 * tot nombres enters. Torna la darrera matriu, i si és esglaonada.
 */
function comprovaCadenaGauss(tex, S, on) {
  const liniesG = /^\\begin\{array\}\{l\}(.*)\\end\{array\}$/.exec(tex.trim());
  const ls = liniesG ? liniesG[1].split(/\\\\\[\d+pt\]/) : [tex];
  const mats = [], ets = [];
  for (const l of ls) {
    const m = /\\begin\{array\}\{(r+\|?r*)\}(.*?)\\end\{array\}/.exec(l);
    if (!m) throw new Error(`línia de Gauss sense matriu: «${l.slice(0, 80)}»`);
    mats.push(m[2].split('\\\\').map(f => f.split('&').map(c => M.llegeixNombre(textPla(c.trim())))));
    const e = /\\end\{array\}\\right\)\\quad\\begin\{array\}\{l\}(.*?)\\end\{array\}/.exec(l);
    ets.push(e ? e[1].split('\\\\').map(c => textPla(c.replace('\\small', '').trim())) : null);
  }
  const igualsF = (f, g_) => f.length === g_.length && f.every((x, k) => x.igual(g_[k]));
  comprova(mats[0].length === S.length && mats[0].every((f, i) => igualsF(f, S[i])), () => `${on}: la primera matriu no és la de les dades`);
  comprova(mats.every(Mx => Mx.every(f => f.every(x => x.esEnter()))), () => `${on}: hi ha fraccions a les matrius`);
  const nC = S[0].length, cols = nC;            // esglaonada tota la matriu (també la columna dels termes independents)
  const lider = f => f.slice(0, cols).findIndex(x => !x.esZero());
  for (let t = 1; t < mats.length; t++) {
    const P = mats[t - 1], N = mats[t], et = ets[t] || ['', '', ''];
    const canvis = et.map(e => /^F_(\d)↔F_(\d)$/.exec(e || '')).filter(Boolean);
    if (canvis.length) {
      const [i, k] = [Number(canvis[0][1]) - 1, Number(canvis[0][2]) - 1];
      const zeroP = f => f.every(x => x.esZero());
      // Cal: la fila i té un 0 on hauria d'anar el pivot (i la k, la primera que no), o la fila i és de zeros.
      const col = [...Array(cols).keys()].find(c => [0, 1, 2].some(q => q >= i && !P[q][c].esZero()));
      const justificat = zeroP(P[i]) ? !zeroP(P[k]) && k === i + 1 : P[i][col].esZero() && k === [0, 1, 2].find(q => q > i && !P[q][col].esZero());
      comprova(canvis.length === 2 && justificat && igualsF(N[i], P[k]) && igualsF(N[k], P[i]) && [0, 1, 2].every(q => q === i || q === k || igualsF(N[q], P[q])),
        () => `${on}: el canvi de files ${i + 1} ↔ ${k + 1} no és correcte o no cal`);
      continue;
    }
    for (let i = 0; i < 3; i++) {
      const e = et[i] || '';
      if (!e) { comprova(igualsF(N[i], P[i]), () => `${on}, matriu ${t + 1}: la fila ${i + 1} ha canviat sense cap operació`); continue; }
      const m = /^(-?\d*)F_(\d)\+(?:\((-?\d+)\)|(\d*))F_(\d)$/.exec(e);
      if (!m) throw new Error(`operació «${e}» no prevista`);
      const coef = x => (x === '' ? 1 : x === '-' ? -1 : Number(x));
      const a = coef(m[1]), b = m[3] !== undefined ? Number(m[3]) : coef(m[4]), fi = Number(m[2]) - 1, j = Number(m[5]) - 1;
      const c = lider(P[j]);
      comprova(fi === i && j < i && c >= 0
        && P[j][c].igual(fr(a)) && P[i][c].oposada().igual(fr(b)) && N[i][c].esZero() && !P[i][c].esZero(),
      () => `${on}, matriu ${t + 1}: «${e}» no és l'operació de l'algorisme (a = pivot, b = −element)`);
      comprova(N[i].every((x, q) => x.igual(P[i][q].producte(a).suma(P[j][q].producte(b)))), () => `${on}, matriu ${t + 1}: la fila ${i + 1} no és ${e}`);
    }
  }
  const B = mats[mats.length - 1];
  const lids = B.map(lider);
  const esglaonada = lids.every((l, i) => (l < 0 ? lids.slice(i).every(x => x < 0) : i === 0 || (lids[i - 1] >= 0 && lids[i - 1] < l)))
    && B.every((f, i) => lids[i] >= 0 || f.slice(0, cols).every(x => x.esZero()));
  return {B, esglaonada, mats};
}

/**
 * Veritat d'un guió de «Resol el sistema» (compatible indeterminat) per Gauss. Model: el sistema
 * de les dades; la incògnita lliure és la columna sense pivot de la forma esglaonada reduïda
 * (calculada aquí, sense Matrius); per a cada λ, les altres dues incògnites. Files: el sistema (les
 * equacions de les dades); la cadena de Gauss (comprovaCadenaGauss: algorisme, enters, acaba
 * esglaonada amb l'última fila de zeros); el sistema esglaonat (files de la darrera matriu; «0 = 0»
 * només marcat); els càlculs (cada línia és una equació certa per a la solució del model, per a
 * tot λ); els valors (cada «v = …» val el del model); les solucions; la recta, P + λ·v.
 */
function comprovaSCI(passos, v, nom) {
  const FILA = SistemaSCI.FILA;
  const S = v.S.split(';').map(f => f.split(',').map(e => M.llegeixNombre(e)));
  const A = S.map(f => f.slice(0, 3));
  comprova(rangGauss(A) === 2 && rangGauss(S) === 2, () => `${nom}: el model no és de rang 2`);
  // Forma esglaonada reduïda (Gauss–Jordan amb fraccions, aquí mateix): columnes pivot i incògnita lliure.
  const R_ = S.map(f => f.slice());
  const pc = [];
  for (let c = 0, r = 0; c < 3 && r < 3; c++) {
    const p = R_.findIndex((x, i) => i >= r && !x[c].esZero());
    if (p < 0) continue;
    [R_[r], R_[p]] = [R_[p], R_[r]];
    R_[r] = R_[r].map(x => x.quocient(R_[r][c]));
    for (let i = 0; i < 3; i++) if (i !== r) { const k = R_[i][c]; R_[i] = R_[i].map((x, j) => x.resta(R_[r][j].producte(k))); }
    pc.push(c); r++;
  }
  const lliure = [0, 1, 2].find(j => !pc.includes(j));
  const model = t => { const sol = []; sol[lliure] = t; pc.forEach((c, r) => { sol[c] = R_[r][3].resta(R_[r][lliure].producte(t)); }); return sol; };
  const satisfa = sol => S.every(f => f[0].producte(sol[0]).suma(f[1].producte(sol[1])).suma(f[2].producte(sol[2])).igual(f[3]));
  comprova(PUNTS_LAMBDA.every(t => satisfa(model(t))), () => `${nom}: el model no és una solució`);
  const valsDe = t => { const s_ = model(t); return {x: s_[0], y: s_[1], z: s_[2], t}; };
  const eqCerta = pla => { const [e, d] = pla.split('='); return PUNTS_LAMBDA.every(t => valorXYZ(`(${e})-(${d})`, valsDe(t)).esZero()); };
  const liniesDe = tex => (tex.startsWith('\\begin{array}{l}') ? liniesDArray(tex) : [textPla(tex)]);
  const afi = text => { const [e, d] = text.split('='); const f0 = vals => valorXYZ(`(${e})-(${d})`, Object.assign({t: fr(0)}, vals));
    const c0 = f0({x: fr(0), y: fr(0), z: fr(0)});
    return [f0({x: fr(1), y: fr(0), z: fr(0)}).resta(c0), f0({x: fr(0), y: fr(1), z: fr(0)}).resta(c0), f0({x: fr(0), y: fr(0), z: fr(1)}).resta(c0), c0.oposada()]; };
  const proporcional = (u, w) => { const k = u.findIndex(x => !x.esZero()); if (k < 0) return w.every(x => x.esZero()); const r = w[k].quocient(u[k]); return u.every((x, q) => x.producte(r).igual(w[q])) && !r.esZero(); };
  let linies = 0, Bfinal = null, vistZero = false;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      if (fila === FILA.sistema) {
        const eqs = /\\left\\\{\\begin\{array\}\{l\}(.*)\\end\{array\}\\right\./.exec(tex)[1].split('\\\\').map(e => textPla(e.trim()));
        comprova(eqs.length === 3 && eqs.every((e, q) => proporcional(S[q], afi(e)) && afi(e).every((x, k) => x.igual(S[q][k]))), () => `${on}: el sistema no és el de les dades`);
      } else if (fila === FILA.gauss) {
        const {B, esglaonada} = comprovaCadenaGauss(tex, S, on);
        Bfinal = B;
        if (pas.files[FILA.esglaonat]) comprova(esglaonada && B[2].every(x => x.esZero()), () => `${on}: la matriu final no és esglaonada amb l'última fila de zeros`);
      } else if (fila === FILA.esglaonat) {
        const eqs = /\\left\\\{\\begin\{array\}\{l\}(.*)\\end\{array\}\\right\./.exec(tex)[1].split('\\\\').map(e => e.trim());
        eqs.forEach((e, q) => {
          const pla = textPla(e);
          if (pla === '0=0') { vistZero = true; comprova(q === 2 && /marca=tria/.test(e), () => `${on}: «0 = 0» ha de ser l'última, marcada`); return; }
          comprova(Bfinal && afi(pla).every((x, k) => x.igual(Bfinal[q][k])), () => `${on}: l'equació «${pla}» no és la fila ${q + 1} de la matriu esglaonada`);
        });
      } else if (fila === FILA.calcul) {
        for (const l of liniesDe(tex)) comprova(eqCerta(l), () => `${on}: «${l}» no és certa per a les solucions`);
      } else if (fila === FILA.valors) {
        comprova((tex.match(/\\boxed\{/g) || []).length === liniesDe(tex).length, () => `${on}: els valors trobats han d'anar requadrats`);
        for (const l of liniesDe(tex)) {
          const m = /^([xyz])=(.+)$/.exec(l);
          const j = m ? 'xyz'.indexOf(m[1]) : -1;
          comprova(m && PUNTS_LAMBDA.every(t => valorXYZ(m[2], valsDe(t)).igual(model(t)[j])) && (j !== lliure || m[2] === 'λ'), () => `${on}: «${l}» no és el valor del model`);
        }
      } else if (fila === FILA.solucio) {
        const m = /^\(x,y,z\)=\((.*)\),λ∈ℝ$/.exec(textPla(tex));
        const comps = m ? partsPerComes(m[1]) : [];
        comprova(comps.length === 3 && PUNTS_LAMBDA.every(t => comps.every((c, j) => valorXYZ(c, valsDe(t)).igual(model(t)[j]))), () => `${on}: «${textPla(tex)}» no és el conjunt de solucions`);
      } else if (fila === FILA.recta) {
        const m = /^\(x,y,z\)=\((.*)\)\+λ\((.*)\)$/.exec(textPla(tex));
        const [pp, vv] = m ? [partsPerComes(m[1]), partsPerComes(m[2])] : [[], []];
        comprova(pp.length === 3 && vv.length === 3 && PUNTS_LAMBDA.every(t => [0, 1, 2].every(j => valorXYZ(pp[j], valsDe(t)).suma(valorXYZ(vv[j], valsDe(t)).producte(t)).igual(model(t)[j]))),
          () => `${on}: «${textPla(tex)}» no és la recta de les solucions`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  comprova(vistZero && final.classes[FILA.solucio] === 'final' && final.classes[FILA.recta] === 'final' && Boolean(final.files[FILA.recta]), () => `${nom}: falten el 0 = 0, les solucions o la recta`);
  comprova(!passos.some(pas => pas.files.some(t => /vmatrix|Cramer|rang/.test(t || ''))), () => `${nom}: «Resol» no fa servir determinants, Cramer ni rangs`);
  return linies;
}

seccio('sistema compatible indeterminat', () => {
  const L = p => SistemaSCI.llegeixAdreca(p);
  comprova(L({}).valors.S === '1,1,1,2;1,-1,2,1;2,0,3,3' && L({S: ' 1,1,0,1 ; 0,1,1,2 ; 1,2,1,3'}).valors.S === '1,1,0,1;0,1,1,2;1,2,1,3', 'SistemaSCI.llegeixAdreca');
  for (const [p, patro] of [
    [{S: '1,0,0,1;0,1,0,2;0,0,1,3'}, /compatible determinat/], [{S: '1,1,1,1;1,1,1,2;0,1,0,1'}, /incompatible/], [{S: '1,1,1,1;2,2,2,2;3,3,3,3'}, /dos paràmetres/],
    [{S: '1,1,1;1,1,1;1,1,1'}, /ha de tenir 4/], [{S: '1,1,1,m;1,1,1,1;1,1,1,1'}, /paràmetre/], [{S: '1,1,1,1;2,2,2,2'}, /3 files/], [{S: '1,1,1,(1;1,1,1,1;1,1,1,1'}, /^No entenc/],
  ]) comprova(patro.test(L(p).error || ''), () => `SistemaSCI.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  for (const v of SistemaSCI.exemples) comprova(SistemaSCI.valida(v) === null, () => `l'exemple ${v.S} no és vàlid: ${SistemaSCI.valida(v)}`);

  const casos = SistemaSCI.exemples.map(v => v.S);
  const atzar = aleatori(2035);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  for (let i = 0; i < 1600; i++) {
    // Dues equacions a l'atzar i una combinació seva (en un ordre a l'atzar).
    const e1 = Array.from({length: 4}, () => enter(-3, 3)), e2 = Array.from({length: 4}, () => enter(-3, 3));
    const [a, b] = [enter(-2, 2), enter(-2, 2)];
    const e3 = e1.map((x, j) => a * x + b * e2[j]);
    const files = [e1, e2, e3];
    const p = enter(0, 2);
    [files[p], files[2]] = [files[2], files[p]];
    if (files.some(f => f.some(x => Math.abs(x) > 9))) continue;
    casos.push(files.map(f => f.join(',')).join(';'));
  }
  let valids = 0, linies = 0, passos = 0;
  const lliures = {};
  for (const text of casos) {
    const r = L({S: text});
    if (r.error) continue;
    const v = r.valors;
    valids++;
    const nom = `S = ${v.S}`;
    comprova(L(SistemaSCI.escriuAdreca(v)).valors.S === v.S, () => `${nom}: anada i tornada de l'adreça`);
    let llista;
    try {
      llista = SistemaSCI.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, SistemaSCI.files, nom);
    linies += comprovaSCI(llista, v, nom);
    passos += llista.length;
    const sol = textPla(llista[llista.length - 1].files[SistemaSCI.FILA.solucio]);
    const k = sol.includes('(λ,') ? 'x' : sol.includes(',λ)') ? 'z' : 'y';
    lliures[k] = (lliures[k] || 0) + 1;
  }
  comprova(['x', 'y', 'z'].every(k => lliures[k] > 0), () => `falten casos amb cada incògnita lliure: ${JSON.stringify(lliures)}`);
  return `${valids} sistemes vàlids, ${passos} passos, ${linies} línies comprovades (λ = ${Object.entries(lliures).map(([k, n]) => `${k}: ${n}`).join(', ')})`;
});


/* ── 17. DISCUSSIÓ D'UN SISTEMA AMB UN PARÀMETRE ───────────────────── */

/**
 * Veritat d'un guió de discussió. El determinant i |A| = 0 es comproven com a la pàgina del
 * determinant (comprovaDeterminant, amb les files i el prefix d'aquí). Model: S llegit de les
 * dades; per a cada valor, els rangs de A i A* per Gauss. Files: el sistema (cada equació, a
 * diversos valors del paràmetre); A*; el cas |A| ≠ 0 (exactament fora de les arrels de |A|);
 * cada cas |A| = 0 (A* amb el valor; els menors, trossos de A* amb el valor que diuen; els
 * rangs, certs; les marques); la taula (els rangs i el tipus de cada fila, certs, i hi són tots
 * els casos).
 */
function comprovaDiscussio(passos, v, nom) {
  const FILA = Discussio.FILA;
  const X = (v.S.match(/[a-z]/) || [])[0];
  const S = v.S.split(';').map(f => f.split(',').map(e => M.llegeix(e, {variables: [X]})));
  const numeric = t => S.map(f => f.map(e => exacte(e, {variables: {[X]: t}, funcions: {}})));
  const tipus = (rA, rS) => (rA < rS ? 'Sistemaincompatible' : rA === 3 ? 'Sistemacompatibledeterminat' : 'Sistemacompatibleindeterminat');   // el nom sencer, sense sigles
  // Les files lliures resolen |A| = 0 fins al resum (la fila de l'equació amb la clau Zf); després, hi ha els casos i la taula.
  const iResum = passos.findIndex(q => (q.files[FILA.equacio] || '').includes('{k=Zf}'));
  comprova(iResum > 0, () => `${nom}: falta el resum de |A| = 0`);
  const {linies: ld, solucionsDet} = comprovaDeterminant(passos, v, nom, {
    FILA: {matriu: FILA.det, sarrus: FILA.sarrus, calcul: FILA.calcul, equacio: FILA.equacio, lliures: FILA.lliures},
    P: 'd', X, A: v.S.split(';').map(f => f.split(',').slice(0, 3).join(',')).join(';'), rapid: true, nomesDet: true, fase: i => i < iResum,
  });
  const arrels = solucionsDet ? solucionsDet.split(',').map(x => M.llegeixNombre(x)) : [];
  let linies = ld;
  const casosVistos = new Set();
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const resumit = i >= iResum;
    if (resumit && fila === FILA.equacio) {
      // El resum: |A| = 0 ⟺ m = … o m = … (o |A| ≠ 0 per a tot m); i les files lliures, buides en aquest pas.
      const pla = textPla(tex);
      const m = /^\|A\|=0⇔(.*)$/.exec(pla);
      comprova(m ? solucionsX(m[1], X) === solucionsDet : pla === `|A|≠0«peratot»${X}` && solucionsDet === '', () => `${nom}, pas ${i + 1}: resum «${pla}» (|A| = 0 per a ${solucionsDet})`);
      if (i === iResum) comprova(FILA.lliures.every(f => !pas.files[f]), () => `${nom}, pas ${i + 1}: al resum, els càlculs s'esborren`);
      return;
    }
    if (![FILA.sistema, FILA.matriu].includes(fila) && !(resumit && [FILA.scd, FILA.cas, FILA.taula].includes(fila))) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const grups = grupsAmbClau(tex);
      if (fila === FILA.sistema) {
        [1, 2, 3].forEach(k => {
          const [e, d] = textPla(grups[`Y${k}`].tex).split('=');
          comprova(PUNTS_DET.slice(1, 6).every(t => {
            const f = numeric(t)[k - 1];
            return [[1, 2, 3], [0, -1, 5], [2, 0, -3], [-1, 1, 1]].map(p => p.map(x => fr(x))).every(([x, y, z]) =>
              exacte(M.llegeix(`(${e})-(${d})`.replace(new RegExp(X, 'g'), `(${t.num}/${t.den})`), {variables: ['x', 'y', 'z']}), {variables: {x, y, z}, funcions: {}})
                .igual(f[0].producte(x).suma(f[1].producte(y)).suma(f[2].producte(z)).resta(f[3])));
          }), () => `${on}: l'equació ${k} no és la del sistema`);
        });
      } else if (fila === FILA.matriu) {
        const m = /\\begin\{array\}\{rrr\|r\}(.*)\\end\{array\}/.exec(tex);
        const cel = m[1].split('\\\\').map(f => f.split('&').map(c => textPla(c.trim())));
        comprova(cel.length === 3 && cel.every((f, a) => f.length === 4 && f.every((c, b) => PUNTS_DET.every(t => valorX(c, X, t).igual(numeric(t)[a][b])))),
          () => `${on}: la matriu no és A*`);
      } else if (fila === FILA.scd) {
        const pla = textPla(tex);
        const m = new RegExp(`^${X}≠(.*):\\|A\\|≠0⇒«rang»\\(A\\)=«rang»\\(A\\^\\(\\*\\)\\)=3$`).exec(pla);
        const tot = pla === `«tot»${X}:|A|≠0⇒«rang»(A)=«rang»(A^(*))=3`;
        comprova(m ? conjunt(m[1].split(',').map(x => M.llegeixNombre(x))) === solucionsDet : tot && solucionsDet === '', () => `${on}: «${pla}» (|A| = 0 per a ${solucionsDet})`);
      } else if (fila === FILA.cas) {
        const c = Object.keys(grups).map(k => /^K(\d+)n$/.exec(k)).filter(Boolean).map(x => x[1])[0];
        const P = `K${c}`;
        const r = M.llegeixNombre(textPla(grups[`${P}n`].tex).split('=')[1]);
        comprova(arrels.some(a => a.igual(r)), () => `${on}: ${X} = ${r.num} no anul·la |A|`);
        casosVistos.add(r.num);
        const N = numeric(r), A = N.map(f => f.slice(0, 3));
        const [rA, rS] = [rangGauss(A), rangGauss(N)];
        const matriu = /\\begin\{array\}\{rrr\|r\}(.*?)\\end\{array\}/.exec(tex)[1].split('\\\\').map(f => f.split('&').map(x => textPla(x.trim())));
        comprova(matriu.every((f, a) => f.every((x, b) => M.llegeixNombre(x).igual(N[a][b]))), () => `${on}: A* amb ${X} = ${r.num} no és aquesta`);
        // Els menors i els rangs.
        if (grups[`${P}m`]) {
          const t = textPla(grups[`${P}m`].tex);
          if (t.startsWith('«')) comprova(rA === 1, () => `${on}: les files de A no són proporcionals`);
          else {
            const B = nombresDeMatriu(grups[`${P}m`].tex);
            comprova(llocsDeMenor(A, B).length && !detMenor(B).esZero() && textPla(grups[`${P}p`].tex) === `${M.texEntreParentesis(B[0][0])}*${M.texEntreParentesis(B[1][1])}-${M.texEntreParentesis(B[0][1])}*${M.texEntreParentesis(B[1][0])}`.replace(/\s/g, '')
              && textPla(grups[`${P}v`].tex) === `${detMenor(B).num}≠0`, () => `${on}: el menor d'ordre 2 de A no és correcte`);
          }
          comprova(textPla(grups[`${P}r`].tex) === `«rang»(A)=${rA}`, () => `${on}: rang(A) = ${rA}`);
        }
        if (grups[`${P}M`]) {
          const t = textPla(grups[`${P}M`].tex);
          if (t.startsWith('«')) comprova(rS === 1, () => `${on}: les files de A* no són proporcionals`);
          else {
            const B = nombresDeMatriu(grups[`${P}M`].tex);
            const llocs = llocsDeMenor(N, B);
            const d = detMenor(B);
            comprova(llocs.some(l => l.cs.includes(3)) && textPla(grups[`${P}V`].tex) === `${d.num}${d.esZero() ? '' : '≠0'}`, () => `${on}: el menor de A* (amb els termes independents) no és correcte`);
            if (B.length === 3) {
              const ps = SARRUS_POS.map(s_ => s_.reduce((p, [a, b]) => p.producte(B[a][b]), fr(1)));
              const pla = textPla(grups[`${P}P`].tex);
              const tr = productesSarrus(pla);
              comprova(tr && tr.every((x, k) => x.igual(ps[k])), () => `${on}: «${pla}» no són els productes de Sarrus`);
              comprova(rA !== 2 || d.esZero() === (rS === 2), () => `${on}: aquest menor no decideix el rang de A*`);
            }
          }
          comprova(textPla(grups[`${P}R`].tex) === `«rang»(A^(*))=${rS}`, () => `${on}: rang(A*) = ${rS}`);
        }
        // Marques: verd, un menor no nul de A; groc, l'orla.
        const marcats = Object.entries(grups).filter(([k, g]) => g.marca && k.startsWith(`${P}a`)).map(([k, g]) => ({i: Number(k.slice(-2, -1)) - 1, j: Number(k.slice(-1)) - 1, marca: g.marca}));
        const verds = marcats.filter(x => x.marca === 'mes');
        if (verds.length) {
          const fv = [...new Set(verds.map(x => x.i))].sort(), cv = [...new Set(verds.map(x => x.j))].sort();
          comprova(verds.length === fv.length * cv.length && fv.length === cv.length && cv.every(j => j < 3) && !detMenor(fv.map(a => cv.map(b => N[a][b]))).esZero(),
            () => `${on}: les marques verdes no són un menor no nul de A`);
        }
      } else if (fila === FILA.taula) {
        const cos = /\\begin\{array\}\{c\|c\|c\|c\}(.*)\\end\{array\}/.exec(tex)[1].split('\\\\').map(f => f.replace('\\hline', '').split('&').map(x => textPla(x.trim())));
        comprova(cos[0].join('|') === `${X}|«rang»(A)|«rang»(A^(*))|«Tipusdesistema»`, () => `${on}: la capçalera de la taula: ${cos[0].join('|')}`);
        cos.slice(1).forEach(([valor, a, b, t], n) => {
          if (n === 0) {
            comprova(a === '3' && b === '3' && t === '«Sistemacompatibledeterminat»' && (valor === `«tot»${X}` ? solucionsDet === '' : conjunt(valor.replace(`${X}≠`, '').split(',').map(x => M.llegeixNombre(x))) === solucionsDet),
              () => `${on}: la fila de |A| ≠ 0 de la taula`);
          } else {
            const r = M.llegeixNombre(valor.split('=')[1]);
            const N = numeric(r);
            const [rA, rS] = [rangGauss(N.map(f => f.slice(0, 3))), rangGauss(N)];
            comprova(arrels.some(x => x.igual(r)) && a === String(rA) && b === String(rS) && t === `«${tipus(rA, rS)}»`, () => `${on}: la fila de ${valor}: és ${rA}, ${rS}, ${tipus(rA, rS)}`);
          }
        });
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  comprova(final.classes[FILA.taula].split(' ').includes('final'), () => `${nom}: la taula no està destacada`);
  const filesTaula = (final.files[FILA.taula].match(/\\hline/g) || []).length;
  comprova(filesTaula === 1 + arrels.length && casosVistos.size === arrels.length, () => `${nom}: la taula no té tots els casos (${arrels.length} valors)`);
  return linies;
}

seccio('discussió de sistemes', () => {
  const L = p => Discussio.llegeixAdreca(p);
  comprova(L({}).valors.S === '1,m,m,-1;-1,1,1,1;2,1,m,2' && L({S: 'k,1,1,1;1,k,1,1;1,1,k,1'}).valors.S === 'k,1,1,1;1,k,1,1;1,1,k,1', 'Discussio.llegeixAdreca');
  for (const [p, patro] of [
    [{S: '1,1,1,1;1,2,1,1;1,1,3,1'}, /paràmetre/], [{S: '1,1,m,1;1,1,1,1;2,2,1,0'}, /no depèn/],
    [{S: 'm,1,0,1;1,m,1,1;0,1,m,1'}, /enters/], [{S: '2m,1,0,1;1,1,0,1;0,0,1,1'}, /enters/], [{S: 'm,1,1;1,m,1;1,1,m'}, /ha de tenir 4/], [{S: 'm,1,1,(1;1,m,1,1;1,1,m,1'}, /^No entenc/],
  ]) comprova(patro.test(L(p).error || ''), () => `Discussio.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  for (const v of Discussio.exemples) comprova(Discussio.valida(v) === null, () => `l'exemple ${v.S} no és vàlid: ${Discussio.valida(v)}`);

  const casos = Discussio.exemples.map(v => v.S);
  const atzar = aleatori(2036);
  const E = ['m', 'm+1', 'm-1', '1', '1', '2', '-1', '0', '1', '3', '-2', '2m', '-m'], B = ['1', '2', '0', 'm', 'm+1', '3', '-1', '1', 'm-1'];
  const tria = a => a[Math.floor(atzar() * a.length)];
  for (let i = 0; i < 6000 && casos.length < 600; i++) {
    const t = Array.from({length: 3}, () => [tria(E), tria(E), tria(E), tria(B)].join(',')).join(';');
    if (!/m/.test(t)) continue;
    if (!L({S: t}).error) casos.push(t);
  }
  let valids = 0, linies = 0, passos = 0;
  const tipusVistos = {};
  for (const text of casos) {
    const r = L({S: text});
    if (r.error) continue;
    const v = r.valors;
    valids++;
    const nom = `S = ${v.S}`;
    comprova(L(Discussio.escriuAdreca(v)).valors.S === v.S, () => `${nom}: anada i tornada de l'adreça`);
    let llista;
    try {
      llista = Discussio.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, Discussio.files, nom);
    linies += comprovaDiscussio(llista, v, nom);
    passos += llista.length;
    const sigla = {'Sistema compatible determinat': 'SCD', 'Sistema compatible indeterminat': 'SCI', 'Sistema incompatible': 'SI'};
    for (const m of llista[llista.length - 1].files[Discussio.FILA.taula].matchAll(/\\text\{(Sistema [a-z ]+)\}/g)) if (sigla[m[1]]) tipusVistos[sigla[m[1]]] = true;
    const t = llista[llista.length - 1].files[Discussio.FILA.taula];
    if (/\{1\}.*\{1\}.*Sistema compatible indeterminat/.test(t)) tipusVistos['SCI rang 1'] = true;
  }
  comprova(['SCD', 'SCI', 'SI'].every(k => tipusVistos[k]), () => `falten tipus: ${JSON.stringify(tipusVistos)}`);
  return `${valids} sistemes vàlids, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 18. MATRIU INVERSA 3×3 (ADJUNTS) ──────────────────────────────── */

/** Inversa per Gauss-Jordan (el model). */
function inversaGauss(N) {
  const B = N.map((f, i) => f.concat([0, 1, 2].map(j => fr(i === j ? 1 : 0))));
  for (let c = 0; c < 3; c++) {
    const p = B.findIndex((x, i) => i >= c && !x[c].esZero());
    [B[c], B[p]] = [B[p], B[c]];
    B[c] = B[c].map(x => x.quocient(B[c][c]));
    for (let i = 0; i < 3; i++) if (i !== c) { const k = B[i][c]; B[i] = B[i].map((x, j) => x.resta(B[c][j].producte(k))); }
  }
  return B.map(f => f.slice(3));
}
/** Les cel·les (TeX) de cada pmatrix d'un TeX, en ordre. */
const cossosPmatrix = tex => [...tex.matchAll(/\\begin\{pmatrix\}(.*?)\\end\{pmatrix\}/g)].map(m => m[1].split('\\\\').map(f => f.replace(/^\s*\[[^\]]*\]/, '').split('&').map(c => c.trim())));

/**
 * Veritat d'un guió de la inversa. Model: A llegida de les dades, |A| per la primera fila i la
 * inversa per Gauss-Jordan. Files: A i les marques (la fila i la columna de l'adjunt que es
 * calcula, en vermell; el menor, en verd); |A| (productes de Sarrus i valor); cada adjunt (el
 * menor que toca, el signe del tauler, el càlcul i el valor); la matriu adjunta (cada element
 * al seu lloc, i després transposada); la inversa (1/|A|, la transposada i la inversa del
 * model); la comprovació.
 */
function comprovaInversa(passos, v, nom) {
  const FILA = Inversa.FILA;
  const N = v.A.split(';').map(f => f.split(',').map(e => M.llegeixNombre(e)));
  const d = detLaplace(N);
  const inv = inversaGauss(N);
  const cof = (i, j) => { const B = [0, 1, 2].filter(a => a !== i).map(a => [0, 1, 2].filter(b => b !== j).map(b => N[a][b])); const m = detMenor(B); return {B, valor: (i + j) % 2 ? m.oposada() : m}; };
  let linies = 0, adjuntsVistos = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const grups = grupsAmbClau(tex);
      if (fila === FILA.matriu) {
        const files = nombresDeMatriu(tex);
        comprova(files.every((f, a) => f.every((c, b) => c.igual(N[a][b]))), () => `${on}: la matriu no és A`);
        const marcats = Object.entries(grups).filter(([, g]) => g.marca).map(([k, g]) => ({i: Number(k[1]) - 1, j: Number(k[2]) - 1, marca: g.marca}));
        if (marcats.length) {
          const adj = /^A_(\d)(\d)$/.exec(textPla((grupsAmbClau(pas.files[FILA.adjunt] || '').Jl || {tex: ''}).tex));
          const [ai, aj] = adj ? [adj[1] - 1, adj[2] - 1] : [-1, -1];
          comprova(marcats.length === 9 && marcats.every(x => x.marca === (x.i === ai || x.j === aj ? 'menys' : 'mes')), () => `${on}: les marques no són les de l'adjunt A_${ai + 1}${aj + 1}`);
        }
      } else if (fila === FILA.det) {
        const pla = tex.startsWith('\\begin{array}') ? liniesDArray(tex).join('') : textPla(tex);
        const m = /^\|A\|=(.*)=(-?\d+)≠0$/.exec(pla);
        const ps = SARRUS_POS.map(s => s.reduce((p, [a, b]) => p.producte(N[a][b]), fr(1)));
        const tr = productesSarrus(m ? m[1] : "");
        comprova(tr && tr.every((x, k) => x.igual(ps[k])) && fr(Number(m[2])).igual(d) && !d.esZero(), () => `${on}: «${pla}», i |A| = ${d.num}`);
      } else if (fila === FILA.adjunt) {
        const [a, b] = /^A_(\d)(\d)$/.exec(textPla(grups.Jl.tex)).slice(1).map(x => Number(x) - 1);
        const {B, valor} = cof(a, b);
        const signe = (a + b) % 2 ? '-' : '+';
        const Bt = nombresDeMatriu(grups.Jm.tex);
        comprova(textPla(grups.Js.tex) === signe && Bt.every((f, x) => f.every((c, y) => c.igual(B[x][y]))), () => `${on}: el menor o el signe de A_${a + 1}${b + 1} no són correctes`);
        const esperat = `${signe}(${M.texEntreParentesis(B[0][0])}*${M.texEntreParentesis(B[1][1])}-${M.texEntreParentesis(B[0][1])}*${M.texEntreParentesis(B[1][0])})`;
        comprova(textPla(grups.Jp.tex) === esperat.replace(/\s/g, '') && M.llegeixNombre(textPla(grups.Jv.tex)).igual(valor), () => `${on}: A_${a + 1}${b + 1} = ${valor.num}`);
        adjuntsVistos++;
      } else if (fila === FILA.adjunta) {
        const transposada = textPla(grups.Jn.tex).endsWith('^(t)');
        const cel = cossosPmatrix(tex)[0];
        cel.forEach((f, x) => f.forEach((c, y) => {
          const k = /\\htmlData\{k=C(\d)(\d)\}/.exec(c);
          if (!k) { comprova(!transposada && c.includes('phantom'), () => `${on}: hi falta l'element ${x + 1}, ${y + 1}`); return; }
          const [a, b] = [Number(k[1]), Number(k[2])];
          comprova((transposada ? a === y && b === x : a === x && b === y) && M.llegeixNombre(textPla(c)).igual(cof(a, b).valor),
            () => `${on}: l'element ${x + 1}, ${y + 1} de la ${transposada ? 'transposada' : 'adjunta'} no és correcte`);
        }));
      } else if (fila === FILA.inversa) {
        const mats = cossosPmatrix(tex).map(m => m.map(f => f.map(c => exacte(M.llegeix(textPla(c), {variables: []}), {variables: {}, funcions: {}}))));
        const ultima = mats[mats.length - 1];
        comprova(ultima.every((f, a) => f.every((c, b) => c.igual(inv[a][b]))), () => `${on}: la inversa no és correcta`);
        if (mats.length === 2) {
          comprova(mats[0].every((f, a) => f.every((c, b) => c.igual(cof(b, a).valor))) && exacte(M.llegeix(textPla(grups.Iu.tex), {variables: []}), {variables: {}, funcions: {}}).igual(fr(1).quocient(d)),
            () => `${on}: 1/|A| per la transposada de l'adjunta no és correcte`);
        } else comprova(d.igual(1), () => `${on}: sense 1/|A| només si |A| = 1`);
      } else if (fila === FILA.comprovacio) {
        comprova(false, () => `${on}: no s'ha d'escriure la comprovació A · A⁻¹ = I`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  comprova(adjuntsVistos === 9 && final.classes[FILA.inversa] === 'final', () => `${nom}: no es calculen els 9 adjunts, o la inversa no està destacada`);
  comprova(textPla(grupsAmbClau(final.files[FILA.adjunta]).Jn.tex).endsWith('^(t)'), () => `${nom}: l'adjunta no s'ha transposat`);
  return linies;
}

seccio('inversa per adjunts', () => {
  const L = p => Inversa.llegeixAdreca(p);
  comprova(L({}).valors.A === '1,0,1;0,1,1;1,1,1' && L({A: '2, 1, 0; 1, 1, 1; 0, 1, 3'}).valors.A === '2,1,0;1,1,1;0,1,3', 'Inversa.llegeixAdreca');
  for (const [p, patro] of [
    [{A: '1,2,3;4,5,6;7,8,9'}, /no té inversa/], [{A: 'm,1,1;1,m,1;1,1,m'}, /paràmetre/], [{A: '1,2;3,4'}, /3 files/], [{A: '1,2,3;4,5,6;7,8,(9'}, /^No entenc/],
  ]) comprova(patro.test(L(p).error || ''), () => `Inversa.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  for (const v of Inversa.exemples) comprova(Inversa.valida(v) === null, () => `l'exemple ${v.A} no és vàlid`);
  comprova(inversaGauss([[fr(2), fr(0), fr(0)], [fr(0), fr(1), fr(0)], [fr(0), fr(0), fr(4)]]).every((f, i) => f.every((c, j) => c.igual(i !== j ? fr(0) : [fr(1, 2), fr(1), fr(1, 4)][i]))), 'inversaGauss');

  const casos = Inversa.exemples.map(v => v.A);
  const atzar = aleatori(2037);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  for (let i = 0; i < 800; i++) casos.push(Array.from({length: 3}, () => Array.from({length: 3}, () => enter(-3, 4)).join(',')).join(';'));
  let valids = 0, linies = 0, passos = 0, unitat = 0, fraccions = 0;
  for (const text of casos) {
    const r = L({A: text});
    if (r.error) continue;
    const v = r.valors;
    valids++;
    const nom = `A = ${v.A}`;
    comprova(L(Inversa.escriuAdreca(v)).valors.A === v.A, () => `${nom}: anada i tornada de l'adreça`);
    const llista = Inversa.passos(v);
    comprovaGuio(llista, Inversa.files, nom);
    linies += comprovaInversa(llista, v, nom);
    passos += llista.length;
    const fin = llista[llista.length - 1].files[Inversa.FILA.inversa];
    if (!fin.includes('dfrac')) unitat++;
    if (/\\frac/.test(fin)) fraccions++;
  }
  comprova(unitat > 0 && fraccions > 0, 'falten casos amb |A| = 1 o amb fraccions');
  return `${valids} matrius invertibles, ${passos} passos, ${linies} línies comprovades (${unitat} amb |A| = 1, ${fraccions} amb fraccions)`;
});


/* ── 19. EQUACIÓ MATRICIAL ─────────────────────────────────────────── */

/*
 * Un petit avaluador d'expressions de matrius 2×2 (el model): lletres (A, B, C, X, I), matrius
 * escrites (pmatrix, que abans es canvien per ⟦n⟧), nombres, + −, / (entre nombres), producte
 * per juxtaposició i ^(-1). Un valor és {s: Fraccio} (un nombre) o {m: [[…]]} (una matriu).
 */
const I2M = [[fr(1), fr(0)], [fr(0), fr(1)]];
const opM = {
  suma: (a, b, k = 1) => (a.s && b.s ? {s: a.s.suma(b.s.producte(k))} : a.m && b.m ? {m: a.m.map((f, i) => f.map((x, j) => x.suma(b.m[i][j].producte(k))))} : null),
  per: (a, b) => (a.s && b.s ? {s: a.s.producte(b.s)} : a.s ? {m: b.m.map(f => f.map(x => x.producte(a.s)))} : b.s ? {m: a.m.map(f => f.map(x => x.producte(b.s)))}
    : {m: a.m.map(f => b.m[0].map((_, j) => f.reduce((s, x, k) => s.suma(x.producte(b.m[k][j])), fr(0))))}),
  inv: a => {
    if (a.s) return {s: fr(1).quocient(a.s)};
    const d = a.m[0][0].producte(a.m[1][1]).resta(a.m[0][1].producte(a.m[1][0]));
    return {m: [[a.m[1][1].quocient(d), a.m[0][1].oposada().quocient(d)], [a.m[1][0].oposada().quocient(d), a.m[0][0].quocient(d)]]};
  },
};
const igualsM = (a, b) => (a.s && b.s ? a.s.igual(b.s) : a.m && b.m ? a.m.every((f, i) => f.every((x, j) => x.igual(b.m[i][j]))) : false);
/** TeX → {pla, mats}: les pmatrix canviades per ⟦n⟧ (amb els seus valors exactes). */
function plaAmbMatrius(tex) {
  const mats = [];
  const t = tex.replace(/\\begin\{pmatrix\}(.*?)\\end\{pmatrix\}/g, (_, cos) => {
    mats.push(cos.split('\\\\').map(f => f.replace(/^\s*\[[^\]]*\]/, '').split('&').map(c => exacte(M.llegeix(textPla(c.trim()), {variables: []}), {variables: {}, funcions: {}}))));
    return `\\text{M${mats.length - 1}}`;
  });
  return {pla: textPla(t).replace(/«M(\d+)»/g, '⟦$1⟧'), mats};
}
function avaluaM(pla, entorn, mats) {
  let i = 0;
  const mira = () => pla[i];
  function expr() {
    let v = terme();
    while (mira() === '+' || mira() === '-') { const s = pla[i++]; v = opM.suma(v, terme(), s === '+' ? 1 : -1); }
    return v;
  }
  function terme() {
    let negatiu = false;
    if (mira() === '-') { negatiu = true; i++; }
    let v = factor();
    while (i < pla.length && !'+-)='.includes(mira())) {
      if (mira() === '/') { i++; v = opM.per(v, opM.inv(factor())); } else if (mira() === '*') { i++; v = opM.per(v, factor()); } else v = opM.per(v, factor());
    }
    return negatiu ? opM.per({s: fr(-1)}, v) : v;
  }
  function factor() {
    let v = atom();
    while (pla.startsWith('^(-1)', i)) { i += 5; v = opM.inv(v); }
    return v;
  }
  function atom() {
    const c = mira();
    if (c === '(') { i++; const v = expr(); if (pla[i++] !== ')') throw new Error(`falta «)» a «${pla}»`); return v; }
    if (c === '⟦') { const f = pla.indexOf('⟧', i); const v = {m: mats[Number(pla.slice(i + 1, f))]}; i = f + 1; return v; }
    if (/\d/.test(c)) { let j = i; while (/\d/.test(pla[j])) j++; const v = {s: fr(Number(pla.slice(i, j)))}; i = j; return v; }
    if (c === 'I') { i++; return {m: I2M}; }
    if (/[ABCX]/.test(c)) { i++; if (!entorn[c]) throw new Error(`no hi ha ${c}`); return {m: entorn[c]}; }
    throw new Error(`no entenc «${pla.slice(i)}»`);
  }
  const v = expr();
  if (i !== pla.length) throw new Error(`sobra «${pla.slice(i)}»`);
  return v;
}

/**
 * Veritat d'un guió d'equació matricial. Model: X resolta a partir de l'equació de l'enunciat
 * com a sistema lineal de 4 incògnites (els elements de X), per Gauss: sense inverses. Cada fila
 * de l'equació ha de ser certa amb aquesta X, i també amb tres jocs de matrius a l'atzar (així una
 * manipulació equivocada, p. ex. la inversa pel costat dolent, no passa). Les files dels càlculs:
 * cada part de cada cadena d'igualtats val el mateix (les matrius de les dades, la dreta, M, |M|,
 * M⁻¹ i X).
 */
function comprovaEquacioMatricial(passos, v, nom) {
  const FILA = EquacioMatricial.FILA;
  const p = EquacioMatricial.problemes.find(q => q.id === v.p);
  const llegeixM = t => t.split(';').map(f => f.split(',').map(e => M.llegeixNombre(e)));
  const dadesReals = {A: llegeixM(p.A), B: llegeixM(p.B), C: p.C ? llegeixM(p.C) : null};
  const original = plaAmbMatrius(passos[0].files[FILA.equacio]).pla;
  /** La X que compleix l'equació original amb aquestes A, B, C (sistema 4×4 per Gauss), o null. */
  const resol = d => {
    const [L, Rr] = original.split('=');
    const f = Xm => { const e = Object.assign({}, d, {X: Xm}); const val = opM.suma(avaluaM(L, e, []), avaluaM(Rr, e, []), -1); return val.m.flat(); };
    const zero = f([[fr(0), fr(0)], [fr(0), fr(0)]]);
    const cols = [0, 1, 2, 3].map(k => { const Xm = [[fr(0), fr(0)], [fr(0), fr(0)]]; Xm[k >> 1][k & 1] = fr(1); return f(Xm).map((x, r) => x.resta(zero[r])); });
    const Bm = [0, 1, 2, 3].map(r => [0, 1, 2, 3].map(k => cols[k][r]).concat([zero[r].oposada()]));
    for (let c = 0; c < 4; c++) {
      const q = Bm.findIndex((x, r) => r >= c && !x[c].esZero());
      if (q < 0) return null;
      [Bm[c], Bm[q]] = [Bm[q], Bm[c]];
      Bm[c] = Bm[c].map(x => x.quocient(Bm[c][c]));
      for (let r = 0; r < 4; r++) if (r !== c) { const k = Bm[r][c]; Bm[r] = Bm[r].map((x, j) => x.resta(Bm[c][j].producte(k))); }
    }
    return [[Bm[0][4], Bm[1][4]], [Bm[2][4], Bm[3][4]]];
  };
  const Xreal = resol(dadesReals);
  const atzar = aleatori(nom.length * 7 + 1);
  const jocs = [];
  while (jocs.length < 3) {
    const m = () => [[0, 0], [0, 0]].map(f => f.map(() => fr(Math.floor(atzar() * 9) - 4)));
    const d = {A: m(), B: m(), C: m()};
    const X = resol(d);
    if (X) jocs.push(Object.assign(d, {X}));
  }
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const {pla, mats} = plaAmbMatrius(tex.startsWith('\\begin{array}') ? tex.replace(/\\begin\{array\}\{l\}|\\end\{array\}|\\\\\[4pt\]|\\qquad|\\quad/g, ' ') : tex);
      const real = Object.assign({}, dadesReals, {X: Xreal});
      if (fila === FILA.equacio) {
        const [L, Rr] = pla.split('=');
        comprova([real].concat(jocs).every(d => igualsM(avaluaM(L, d, mats), avaluaM(Rr, d, mats))), () => `${on}: «${pla}» no és equivalent a l'equació`);
      } else if (fila === FILA.dades) {
        for (const tros of pla.split(',')) {
          const [n, e] = tros.split('=');
          comprova(dadesReals[n] && igualsM(avaluaM(e, real, mats), {m: dadesReals[n]}), () => `${on}: «${tros}»`);
        }
      } else if (fila === FILA.det) {
        const m = /^\|(.*)\|=(.*)=(-?\d+)≠0$/.exec(pla);
        const Mm = avaluaM(m[1], real, mats).m;
        const d = Mm[0][0].producte(Mm[1][1]).resta(Mm[0][1].producte(Mm[1][0]));
        comprova(valorX(m[2], 'x', fr(0)).igual(d) && fr(Number(m[3])).igual(d) && !d.esZero(), () => `${on}: «${pla}»`);
      } else {
        const parts = pla.split('=');
        const valors = parts.map(t => avaluaM(t, real, mats));
        comprova(valors.every(x => igualsM(x, valors[0])), () => `${on}: «${pla}»: no totes les parts valen el mateix`);
        if (fila === FILA.producte || fila === FILA.resposta) comprova(parts[0] === 'X' && igualsM(valors[valors.length - 1], {m: Xreal}), () => `${on}: X no és la solució`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  comprova(final.classes[FILA.resposta] === 'final', () => `${nom}: la resposta no està destacada`);
  comprova(plaAmbMatrius(final.files[FILA.equacio]).pla.startsWith('X='), () => `${nom}: la X no queda aïllada`);
  return linies;
}

seccio('equació matricial', () => {
  let linies = 0, passos = 0;
  comprova(igualsM(avaluaM('(A+I)^(-1)(2C-B)', {A: [[fr(1), fr(0)], [fr(0), fr(1)]], B: I2M, C: I2M}, []), {m: [[fr(1, 2), fr(0)], [fr(0), fr(1, 2)]]}), 'avaluaM');
  for (const problema of EquacioMatricial.problemes) {
    const v = {p: problema.id};
    const llista = EquacioMatricial.passos(v);
    comprovaGuio(llista, EquacioMatricial.files, problema.id);
    linies += comprovaEquacioMatricial(llista, v, problema.id);
    passos += llista.length;
    // «I · X» i «X · I», sempre amb el punt (IX semblaria un nombre romà).
    llista.forEach((pas, i) => comprova(!/IX|XI/.test(textPla(pas.files[EquacioMatricial.FILA.equacio] || '')), () => `${problema.id}, pas ${i + 1}: «IX» o «XI» sense el punt`));
    // Si el membre de la dreta té més d'un terme, el pas de la inversa en destaca els parèntesis.
    if (problema.beta) comprova(llista.some(pas => (pas.files[EquacioMatricial.FILA.equacio] || '').includes('\\htmlData{marca=tria}{(}')), () => `${problema.id}: no es destaquen els parèntesis del membre de la dreta`);
  }
  return `${EquacioMatricial.problemes.length} problemes, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 20. ESGLAONAR UNA MATRIU (GAUSS) ──────────────────────────────── */

seccio('esglaonar per Gauss', () => {
  const L = p => Esglaonar.llegeixAdreca(p);
  comprova(L({}).valors.A === '1,1,1,6;2,-1,1,3;1,2,-1,2' && L({A: ' 1,2,3,4 ; 2,4,6,8 ; 3,6,9,1'}).valors.A === '1,2,3,4;2,4,6,8;3,6,9,1', 'Esglaonar.llegeixAdreca');
  for (const [p, patro] of [
    [{A: '1,1,1;1,1,1;1,1,1'}, /4/], [{A: '1,1,1,m;1,1,1,1;1,1,1,1'}, /paràmetre/], [{A: '0,0,0,1;0,0,0,2;0,0,0,3'}, /coeficient 0/], [{A: '1,1,(1,1;1,1,1,1;1,1,1,1'}, /^No entenc/],
  ]) comprova(patro.test(L(p).error || ''), () => `Esglaonar.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  for (const v of Esglaonar.exemples) comprova(Esglaonar.valida(v) === null, () => `l'exemple ${v.A} no és vàlid`);
  // Els exemples: de rang(A) 3, 2 i 1, i amb rang(A*) igual o un més; amb un canvi de files.
  const tipusEx = new Set(Esglaonar.exemples.map(v => { const S = v.A.split(';').map(f => f.split(',').map(e => fr(Number(e)))); return `${rangGauss(S.map(f => f.slice(0, 3)))}/${rangGauss(S)}`; }));
  comprova(['3/3', '2/2', '2/3', '1/2'].every(t => tipusEx.has(t)), () => `als exemples hi falten tipus de rangs: ${[...tipusEx]}`);

  const casos = Esglaonar.exemples.map(v => v.A);
  const atzar = aleatori(2041);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  for (let i = 0; i < 2500; i++) {
    const files = Array.from({length: 3}, () => Array.from({length: 4}, () => enter(-6, 6)));
    const t = i % 5;
    if (t === 1) files[2] = files[0].map((x, j) => x + files[1][j]);                      // rang 2 i 2
    if (t === 2) { files[2] = files[0].map((x, j) => x - files[1][j]); files[2][3] += enter(1, 3); }   // rang 2 i 3
    if (t === 3) { files[1] = files[0].map(x => 2 * x); files[1][3] += enter(-2, 2); files[2][0] = 0; }   // zeros i canvis de files
    if (t === 4) files[0][0] = 0;
    if (i % 7 === 6) { const k = enter(-2, 2) || 1; files[1] = files[0].map(x => k * x); files[2] = files[0].map(x => -x); if (i % 2) files[2][3] += 1; }   // rang(A) = 1
    if (files.some(f => f.some(x => Math.abs(x) > 9))) continue;
    casos.push(files.map(f => f.join(',')).join(';'));
  }
  let valids = 0, linies = 0, passosT = 0, canvis = 0;
  const tipus = {};
  for (const text of casos) {
    const r = L({A: text});
    if (r.error) continue;
    const v = r.valors;
    valids++;
    const nom = `A* = ${v.A}`;
    comprova(L(Esglaonar.escriuAdreca(v)).valors.A === v.A, () => `${nom}: anada i tornada de l'adreça`);
    const S = v.A.split(';').map(f => f.split(',').map(e => M.llegeixNombre(e)));
    let llista;
    try { llista = Esglaonar.passos(v); } catch (e) { comprova(false, () => `${nom}: passos() llança ${e.stack}`); continue; }
    comprovaGuio(llista, Esglaonar.files, nom);
    passosT += llista.length;
    let B = null, esglaonada = false;
    llista.forEach((pas, i) => {
      const on = `${nom}, pas ${i + 1}`;
      try {
        ({B, esglaonada} = comprovaCadenaGauss(pas.files[Esglaonar.FILA.gauss], S, on));
        linies++;
        if (/leftrightarrow/.test(pas.files[Esglaonar.FILA.gauss])) canvis++;
      } catch (e) { comprova(false, () => `${on}: no es pot llegir: ${e.message}`); }
    });
    const final = llista[llista.length - 1];
    const [rA, rS] = [rangGauss(S.map(f => f.slice(0, 3))), rangGauss(S)];
    tipus[`${rA}/${rS}`] = (tipus[`${rA}/${rS}`] || 0) + 1;
    comprova(esglaonada, () => `${nom}: la matriu final no és esglaonada`);
    comprova(textPla(final.files[Esglaonar.FILA.resultat]) === `«rang»(A)=${rA},«rang»(A^(*))=${rS}` && final.classes[Esglaonar.FILA.resultat] === 'final',
      () => `${nom}: «${textPla(final.files[Esglaonar.FILA.resultat])}», i els rangs són ${rA} i ${rS}`);
    // Els pivots, en verd: el primer element no nul de cada fila no nul·la (a les tres primeres columnes).
    const marcats = [...final.files[Esglaonar.FILA.gauss].matchAll(/k=G\d+a(\d)(\d),marca=mes/g)].map(m => `${Number(m[1]) - 1}${Number(m[2]) - 1}`).sort().join();
    const pivots = B ? B.map((f, i) => [i, f.findIndex(x => !x.esZero())]).filter(([, j]) => j >= 0).map(([i, j]) => `${i}${j}`).join() : '';
    comprova(marcats === pivots, () => `${nom}: els pivots marcats (${marcats}) no són ${pivots}`);
  }
  comprova(['3/3', '2/2', '2/3', '1/1', '1/2'].every(t => tipus[t] > 0) && canvis > 0, () => `falten casos: ${JSON.stringify(tipus)}, canvis de files ${canvis}`);
  return `${valids} matrius, ${passosT} passos, ${linies} cadenes comprovades (rangs ${Object.entries(tipus).map(([k, n]) => `${k}: ${n}`).join(', ')}; amb canvis de files: ${canvis})`;
});


/* ── 21. GEOMETRIA: L'EQUACIÓ D'UN PLA ─────────────────────────────── */

/** Un vector de text pla «(1,0,-2)» → [Fraccio]. */
const vectorPla = t => { const m = /^\((.*)\)$/.exec(t); if (!m) throw new Error(`«${t}» no és un vector`); return partsPerComes(m[1]).map(x => exacte(M.llegeix(x, {variables: []}), {variables: {}, funcions: {}})); };
/**
 * Un punt amb nom en text pla, sense signe igual (David): «A(1,0,1)», «P_λ(3+λ,-λ,0)∈r», «D_1(3,3,1)».
 * Torna {nom, cos: «(…)», resta: el que va darrere (p. ex. «∈r»)} o null si no ho és.
 */
function puntAmbNom(t) {
  const m = /^([A-Z]'?(?:_[0-9λμa-z]+)?)(\((?:[^()]|\((?:[^()]|\([^()]*\))*\))*\))(.*)$/.exec(t);
  return m ? {nom: m[1], cos: m[2], resta: m[3]} : null;
}
const igualsV = (u, v) => u.length === v.length && u.every((x, i) => x.igual(v[i]));
/** Valor d'una expressió en x, y, z (i potser D, λ = t, μ = s) en un punt. */
const valorXYZD = (text, vals) => exacte(M.llegeix(text.replace(/λ/g, 't').replace(/μ/g, 's'), {variables: ['x', 'y', 'z', 'D', 't', 's']}),
  {variables: Object.assign({x: fr(0), y: fr(0), z: fr(0), D: fr(0), t: fr(0), s: fr(0)}, vals), funcions: {}});
/** Els coeficients [A, B, C, D] d'una expressió afí en x, y, z (text pla). */
function coeficientsAfins(text) {
  const v = (x, y, z) => valorXYZD(text, {x: fr(x), y: fr(y), z: fr(z)});
  const D = v(0, 0, 0);
  const coefs = [v(1, 0, 0).resta(D), v(0, 1, 0).resta(D), v(0, 0, 1).resta(D), D];
  if (!v(2, -3, 5).igual(coefs[0].producte(2).resta(coefs[1].producte(3)).suma(coefs[2].producte(5)).suma(D))) throw new Error(`«${text}» no és afí`);
  return coefs;
}
const proporcionals4 = (a, b) => { const k = a.findIndex(x => !x.esZero()); if (k < 0 || b[k].esZero()) return false; const r = a[k].quocient(b[k]); return a.every((x, i) => x.igual(b[i].producte(r))); };
/** Les vmatrix 2×2 d'un TeX canviades pel seu valor (per llegir el desenvolupament d'un determinant). */
const ambMenorsCalculats = tex => tex.replace(/\\begin\{vmatrix\}((?:(?!\\end\{vmatrix\}).)*?)\\end\{vmatrix\}/g, (tot, cos) => {
  const files = cos.split('\\\\');
  if (files.length !== 2) return tot;
  const B = files.map(f => f.split('&').map(c => M.llegeixNombre(textPla(c.trim()))));
  return `(${M.texNombre(detMenor(B))})`;
});

/**
 * Veritat d'un guió del pla. Model: les condicions que defineixen el pla, segons el problema
 * (conté uns punts; és perpendicular a una recta o a un pla; és paral·lel a un pla; és el
 * mediador). El pla final les ha de complir (així queda determinat). Files: els elements (cada
 * igualtat de vectors, certa, i els vectors amb nom, els que toquen); el determinant i el
 * desenvolupament (defineixen el mateix pla); la forma general; la comprovació (l'aritmètica
 * val 0 i és el pla al punt que diu).
 */
function comprovaPla(passos, p, nom) {
  const FILA = Pla.FILA;
  const sumaV = (a, b) => a.map((x, i) => x.suma(b[i]));
  const menysV = (a, b) => a.map((x, i) => x.resta(b[i]));
  const final = passos[passos.length - 1];
  const finalPla = coeficientsAfins(textPla(final.files[FILA.pla]).split('=')[0]);
  const n = finalPla.slice(0, 3);
  const valorPla = Q => n.reduce((s, c, i) => s.suma(c.producte(Q[i])), finalPla[3]);
  const conte = Q => valorPla(Q).esZero();
  const paralV = (a, b) => [0, 1, 2].every(i => a[(i + 1) % 3].producte(b[(i + 2) % 3]).igual(a[(i + 2) % 3].producte(b[(i + 1) % 3])));
  const perp = (a, b) => a.reduce((s, x, i) => s.suma(x.producte(b[i])), fr(0)).esZero();
  const mig = p.A && p.B ? p.A.map((x, i) => x.suma(p.B[i]).quocient(2)) : null;
  const conds = {
    'tres': () => [p.A, p.B, p.C].every(conte),
    'punt-recta': () => [p.P, p.r.P, sumaV(p.r.P, p.r.u)].every(conte),
    'rectes': () => [p.r.P, sumaV(p.r.P, p.r.u), p.s.P, sumaV(p.s.P, p.s.u)].every(conte),
    'conte-perp': () => [p.r.P, sumaV(p.r.P, p.r.u)].every(conte) && perp(n, p.pi.n),
    'perp-recta': () => conte(p.P) && paralV(n, p.r.u),
    'paralel': () => conte(p.P) && paralV(n, p.pi.n),
    'mediador': () => paralV(n, menysV(p.B, p.A)) && conte(mig),
  }[p.id];
  comprova(!n.every(x => x.esZero()) && conds(), () => `${nom}: el pla final no compleix les condicions del problema`);
  // Els punts i vectors amb nom, per llegir les files.
  const punts = {A: p.A, B: p.B, C: p.C, P: p.P || null, M: mig, Q: p.r && p.id === 'punt-recta' ? p.r.P : null};
  const vectors = {
    'AB': p.A && p.B ? menysV(p.B, p.A) : null, 'AC': p.A && p.C ? menysV(p.C, p.A) : null, 'QP': p.P && p.r ? menysV(p.P, p.r.P) : null,
    'u': p.r ? p.r.u : null, 'v': p.s ? p.s.u : null, 'n_π': p.pi ? p.pi.n : null,
    'n': {'perp-recta': p.r && p.r.u, 'paralel': p.pi && p.pi.n, 'mediador': p.A && p.B && menysV(p.B, p.A)}[p.id],
  };
  const valorNom = t => {
    if (/^\(.*\)$/.test(t)) return vectorPla(t);
    const resta = /^([A-Z])-([A-Z])$/.exec(t);
    if (resta) return punts[resta[1]] && punts[resta[2]] ? menysV(punts[resta[1]], punts[resta[2]]) : null;
    const v = /^«(.*)»(_\(pi\))?$/.exec(t);
    if (v) return vectors[v[1] + (v[2] ? '_π' : '')];
    if (/^[A-Z]$/.test(t)) return p.id === 'rectes' || p.id === 'conte-perp' ? (t === 'P' ? p.r.P : null) : punts[t];
    return undefined;
  };
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      if (fila === FILA.esquema) { comprova(tex.startsWith('<svg') && tex.endsWith('</svg>'), () => `${on}: no és un esquema`); return; }
      if (fila === FILA.dades) return;                                     // les dades, tal com les dona l'enunciat
      if (fila === FILA.elements) {
        for (const l of tex.startsWith('\\begin{array}') ? liniesDArray(tex) : [textPla(tex)]) {
          // Un punt s'escriu «A(1,0,1)», sense «=» (David).
          const pn = puntAmbNom(l);
          if (pn) {
            const esperat = (p.id === 'rectes' || p.id === 'conte-perp') && pn.nom === 'P' ? p.r.P : punts[pn.nom];
            comprova(esperat && igualsV(vectorPla(pn.cos), esperat) && (pn.resta === '' || (pn.resta === '∈r' && ['punt-recta', 'rectes', 'conte-perp'].includes(p.id))), () => `${on}: «${l}» no és el punt ${pn.nom}`);
            continue;
          }
          comprova(!/^[A-Z]=/.test(l), () => `${on}: «${l}»: un punt no porta signe igual`);
          comprova(!/=[A-Z]-[A-Z]=/.test(l), () => `${on}: «${l}»: no es resten punts (el vector, directament)`);
          const parts = l.replace(/∈r$/, '').split('=');
          const valors = parts.map(valorNom);
          comprova(valors.every(x => x !== undefined) && valors.every(x => x !== null) && valors.every(x => igualsV(x, valors[0])), () => `${on}: «${l}» no és certa`);
          if (p.id === 'conte-perp' || p.id === 'rectes') comprova(!l.startsWith('P=') || igualsV(valors[1], p.r.P), () => `${on}: P no és de r`);
          if (p.id === 'punt-recta') comprova(!l.startsWith('Q=') || igualsV(valors[1], p.r.P), () => `${on}: Q no és de r`);
        }
        return;
      }
      if (fila === FILA.det) {
        const cos = /\\begin\{vmatrix\}(.*)\\end\{vmatrix\}/.exec(tex)[1].split('\\\\').map(f => f.split('&').map(c => textPla(c.trim())));
        const fx = (x, y, z) => detLaplace(cos.map(f => f.map(c => valorXYZD(c, {x: fr(x), y: fr(y), z: fr(z)}))));
        const D = fx(0, 0, 0);
        comprova(proporcionals4([fx(1, 0, 0).resta(D), fx(0, 1, 0).resta(D), fx(0, 0, 1).resta(D), D], finalPla), () => `${on}: el determinant no defineix el mateix pla`);
        return;
      }
      const pla = tex.startsWith('\\begin{array}') ? liniesDArray(ambMenorsCalculats(tex)).join('') : textPla(ambMenorsCalculats(tex));
      if (fila === FILA.desenvolupa || fila === FILA.pla) {
        const [esq, dre] = pla.split('⇒');
        const [L, Rr] = esq.split('=');
        comprova(Rr === '0', () => `${on}: «${esq}» no és «… = 0»`);
        if (/D/.test(L)) {
          // El pla paral·lel amb la D per trobar: Ax + By + Cz + D, i després amb el punt P.
          const ambD = d => valorXYZD(L, {D: d});
          if (/[xyz]/.test(L)) {
            comprova(ambD(fr(1)).resta(ambD(fr(0))).igual(fr(1)) && igualsV(coeficientsAfins(L).slice(0, 3), n), () => `${on}: «${L}» no és el pla amb la D per trobar`);
          } else {
            comprova(ambD(fr(0)).igual(valorPla(p.P).resta(finalPla[3])) && ambD(fr(1)).resta(ambD(fr(0))).igual(fr(1)), () => `${on}: «${L}» no és el pla amb P`);
            comprova(dre && M.llegeixNombre(dre.split('=')[1]).igual(finalPla[3]), () => `${on}: D no és ${finalPla[3].num}`);
          }
        } else {
          comprova(proporcionals4(coeficientsAfins(L), finalPla), () => `${on}: «${L} = 0» no és el mateix pla`);
        }
        return;
      }
      if (fila === FILA.comprovacio) {
        for (const l of tex.startsWith('\\begin{array}') ? liniesDArray(tex) : [textPla(tex)]) {
          const [nomQ, resta] = l.split(':');
          const [e, z] = resta.split('=');
          const val = valorXYZD(e, {});
          comprova(z === '0' && val.esZero(), () => `${on}: «${l}» no val 0`);
          const Q = nomQ.endsWith('+«u»') ? sumaV(p.r.P, p.r.u) : nomQ === 'Q' ? p.r.P : nomQ === 'P' && (p.id === 'rectes' || p.id === 'conte-perp') ? p.r.P : punts[nomQ];
          const Qreal = p.id === 'rectes' && nomQ === 'Q' ? p.s.P : Q;
          // Els nombres substituïts són les coordenades del punt (en ordre, les dels coeficients no nuls).
          const xs = [...e.matchAll(/\*\(?(-?\d+(?:\/\d+)?)\)?/g)].map(m => M.llegeixNombre(m[1]));
          const esperats = Qreal ? Qreal.filter((_, k) => !n[k].esZero()) : [];
          comprova(Qreal && val.igual(valorPla(Qreal)) && igualsV(xs, esperats), () => `${on}: «${l}» no és el pla al punt ${nomQ}`);
        }
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  comprova(final.classes[FILA.pla] === 'final', () => `${nom}: la resposta no està destacada`);
  return linies;
}

seccio('pla', () => {
  let linies = 0, passos = 0;
  for (const problema of Pla.problemes) {
    const llista = Pla.passos({p: problema.id});
    comprovaGuio(llista, Pla.files, problema.id);
    linies += comprovaPla(llista, problema, problema.id);
    passos += llista.length;
  }
  return `${Pla.problemes.length} problemes, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 22. GEOMETRIA: LA RECTA DONADA PER DOS PLANS ───────────────────── */

/** Un vector escrit amb «i», «j», «k» (text pla) → [Fraccio]: les components, sense terme independent. */
function vectorIJK(t) {
  const c = coeficientsAfins(t.replace(/«i»/g, '(x)').replace(/«j»/g, '(y)').replace(/«k»/g, '(z)'));
  if (!c[3].esZero()) throw new Error(`«${t}» té un terme sense i, j, k`);
  return c.slice(0, 3);
}
/** Determinant 3×3 amb una primera fila de vectors unitaris: la component m de |e; u; v|, per Laplace. */
const componentDet = (u, v, m) => detLaplace([[0, 1, 2].map(j => fr(j === m ? 1 : 0)), u, v]);
/** Els operands que van després de cada «*» d'un text pla (un nombre o un grup entre parèntesis): {inici, fi, text}. */
/**
 * «2-2*3+(-1)+1» (Geometria.texSubstitucio en text pla): els coeficients no nuls de «coefs», en
 * ordre, per als valors corresponents (sense «1 ·»: si el coeficient és ±1, només el valor, amb el
 * signe), i D al final si no és 0. Torna si és exactament així.
 */
function substitucioCorrecta(e, coefs, valors, D) {
  const termes = [];
  let nivell = 0, inici = 0;
  for (let i = 0; i < e.length; i++) {
    const ch = e[i];
    if (ch === '(') nivell++;
    else if (ch === ')') nivell--;
    else if ((ch === '+' || ch === '-') && nivell === 0 && i > 0 && !'*('.includes(e[i - 1])) { termes.push(e.slice(inici, i)); inici = i; }
  }
  termes.push(e.slice(inici));
  const parells = coefs.map((c, j) => [c, valors[j]]).filter(([c]) => !c.esZero());
  const ambD = D && !D.esZero();
  if (termes.length !== parells.length + (ambD ? 1 : 0)) return false;
  const net = t => t.replace(/^\+/, '');
  if (ambD && !valorXYZD(net(termes[termes.length - 1]), {}).igual(D)) return false;
  return parells.every(([c, x], j) => {
    const t = termes[j];
    const cos = t.replace(/^[+-]/, '');
    const k = cos.indexOf('*');
    if (k < 0) return c.abs().igual(1) && valorXYZD(net(t), {}).igual(c.producte(x));
    return !c.abs().igual(1) && (t[0] === '-' ? -1 : 1) === c.signe() && M.llegeixNombre(cos.slice(0, k)).igual(c.abs()) && valorXYZD(cos.slice(k + 1), {}).igual(x);
  });
}

function operandsDeProductes(e) {
  const r = [];
  for (let i = 0; i < e.length; i++) {
    if (e[i] !== '*') continue;
    let j = i + 1;
    if (e[j] === '(') {
      let nivell = 0;
      do { if (e[j] === '(') nivell++; else if (e[j] === ')') nivell--; j++; } while (nivell && j < e.length);
    } else {
      while (j < e.length && (/[\d\/]/.test(e[j]) || (j === i + 1 && e[j] === '-'))) j++;
    }
    r.push({inici: i + 1, fi: j, text: e.slice(i + 1, j)});
  }
  return r;
}

/** Un tros de TeX amb \vec{i}, \vec{j}, \vec{k} com a vector [a, b, c] (i, j, k es llegeixen com x, y, z). */
function formaIJK(tex) {
  const pla = textPla(tex.replace(/\\vec\{([ijk])\}/g, (_, u) => ({i: 'x', j: 'y', k: 'z'})[u]));
  const val = (x, y, z) => valorXYZ(pla, {x: fr(x), y: fr(y), z: fr(z), t: fr(0)});
  const c0 = val(0, 0, 0);
  comprova(c0.esZero(), () => `«${pla}» té un terme sense i, j ni k`);
  return [val(1, 0, 0), val(0, 1, 0), val(0, 0, 1)].map(x => x.resta(c0));
}
/** El que hi ha després del «=» de nivell superior d'una línia (fora de claus). */
const despresIgual = tex => { const i = tex.indexOf('\\mathrel{\\htmlData{k='); const j = tex.indexOf('}}', i); return i < 0 ? tex : tex.slice(j + 2); };

/**
 * La fila del producte vectorial a × b (Geometria.passosProducteVectorial, claus V…): el nom; el
 * determinant |i j k; a; b|; i, si hi és, la regla de Sarrus amb claudàtors: cada producte VS<n>
 * és el de la seva posició (el símbol de la primera fila per dos nombres), i la línia sencera val
 * a × b (calculat aquí per Laplace).
 */
function comprovaFilaProducte(tex, grups, a, b, nom, on) {
  comprova(grups.Vl.tex === nom, () => `${on}: no és ${nom}`);
  const files = /\\begin\{vmatrix\}(.*)\\end\{vmatrix\}/.exec(grups.Vd.tex)[1].split('\\\\').map(f => f.split('&').map(c => c.trim()));
  comprova(files.length === 3 && iguals(files[0], ['\\vec{i}', '\\vec{j}', '\\vec{k}'])
    && [a, b].every((v, k) => igualsV(files[k + 1].map(c => M.llegeixNombre(textPla(c))), v)), () => `${on}: el determinant no és |i j k; ${nom}|`);
  const n = [0, 1, 2, 3, 4, 5].filter(k => grups[`VS${k}`]).length;
  if (!n) return;
  comprova(n === 6, () => `${on}: la regla de Sarrus no té els sis productes`);
  const POS = [[0, 1, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0], [0, 2, 1], [1, 0, 2]];
  POS.forEach(([j, p, q], k) => {
    const esperat = [0, 1, 2].map(c => (c === j ? a[p].producte(b[q]) : fr(0)));
    comprova(grups[`VS${k}`] && igualsV(formaIJK(grups[`VS${k}`].tex), esperat), () => `${on}: el producte ${k + 1} de Sarrus no és el que toca`);
  });
  const linia = (tex.split('\\\\[8pt]')[1] || '');
  comprova(linia && igualsV(formaIJK(linia.replace(/\\begin\{array\}\{l\}|\\end\{array\}|\\\\\[4pt\]|\\qquad/g, '').replace(/^\s*=\s*/, '')), [0, 1, 2].map(c => componentDet(a, b, c))),
    () => `${on}: la regla de Sarrus no val ${nom}`);
}
/** La fila del resultat d'un producte vectorial (claus V…): cada versió val a × b (Laplace); al final, «= … i + … = (…)». */
function comprovaFilaValorProducte(grups, a, b, nom, on, tex) {
  const w = [0, 1, 2].map(c => componentDet(a, b, c));
  comprova(grups.VL.tex === nom, () => `${on}: no és ${nom}`);
  if (grups.Vv) comprova(igualsV(vectorIJK(textPla(grups.Vc.tex)), w) && igualsV(vectorPla(textPla(grups.Vv.tex)), w), () => `${on}: ${nom} no és ${w.map(x => x.num)}`);
  else if (tex) comprova(igualsV(formaIJK(despresIgual(tex).replace(/\\begin\{array\}\{l\}|\\end\{array\}|\\\\\[4pt\]|\\qquad/g, '')), w), () => `${on}: «${textPla(tex)}» no val ${nom}`);
}

/**
 * Un sistema 2×2 resolt pel mètode de reducció (Geometria.passosReduccio2, claus X<n>): cada línia és una
 * equació certa per a la solució (calculada aquí); no hi ha determinants ni quocients de Cramer. «vars»: els
 * noms en text pla (x, y, z, λ, μ). Torna la solució.
 */
function comprovaReduccio(grups, S2, vars, on, tex) {
  const D = S2[0][0].producte(S2[1][1]).resta(S2[0][1].producte(S2[1][0]));
  const sol = [S2[0][2].producte(S2[1][1]).resta(S2[0][1].producte(S2[1][2])).quocient(D), S2[0][0].producte(S2[1][2]).resta(S2[0][2].producte(S2[1][0])).quocient(D)];
  const nom = v => ({λ: 'l', μ: 'n'})[v] || v;
  comprova(!/vmatrix|Cramer/.test(tex), () => `${on}: hi ha determinants (Cramer)`);
  // Les equacions es diuen «(EQ.n)», d'un altre color, i els dos valors trobats van requadrats (David).
  comprova(/\\textcolor\{#b45309\}\{\\text\{\(EQ\.\d\)\}\}/.test(tex) && !/\\small \(/.test(tex), () => `${on}: falten les etiquetes (EQ.n)`);
  const caixes = [...tex.matchAll(/\\boxed\{([^{}]*)\}/g)].map(m => textPla(m[1]).replace(/λ/g, 'l').replace(/μ/g, 'n'));
  if (caixes.length) {
    const esperades = vars.map((v, q) => `${nom(v)}=${textPla(M.texNombre(sol[q]))}`);
    comprova(caixes.every(c => esperades.includes(c)) && new Set(caixes).size === caixes.length, () => `${on}: requadres ${caixes.join(', ')} (havien de ser ${esperades.join(', ')})`);
  }
  for (const k of Object.keys(grups).filter(c => /^X\d+$/.test(c))) {
    const pla = textPla(grups[k].tex).replace(/λ/g, 'l').replace(/μ/g, 'n');
    const [e, d] = pla.split('=');
    const valor = exacte(M.llegeix(`(${e})-(${d})`, {variables: vars.map(nom)}), {variables: Object.fromEntries(vars.map((v, q) => [nom(v), sol[q]])), funcions: {}});
    comprova(valor.esZero(), () => `${on}: «${textPla(grups[k].tex)}» no és certa per a la solució`);
    // Una línia «λ = valor» (el valor trobat) ha d'anar requadrada.
    if (vars.some((v, q) => pla === `${nom(v)}=${textPla(M.texNombre(sol[q]))}`)) comprova(grups[k].tex.startsWith('\\boxed{'), () => `${on}: «${textPla(grups[k].tex)}» no està requadrat`);
  }
  return sol;
}

/**
 * Veritat d'un guió de la recta donada per dos plans. Model: les dues equacions de les dades;
 * un vector és director si és perpendicular als dos vectors normals i no és nul, i un punt és de
 * la recta si compleix les dues equacions. El producte vectorial es compara amb el determinant
 * calculat aquí per Laplace. Files: les equacions; els normals; el determinant (primera fila i, j, k;
 * els menors i els signes del desenvolupament); el resultat (en i, j, k i en components) i el
 * vector director; el sistema reduït (les equacions amb la incògnita fixada; determinant no nul,
 * com diu el text); Cramer (l'estructura i el valor: la solució del sistema reduït); el punt i la
 * comprovació (la substitució és la de l'equació, als punts de P); i les equacions de la recta.
 */
function comprovaRectaPlans(passos, v, nom) {
  const FILA = RectaPlans.FILA;
  const S = Matrius.nombres(Matrius.llegeixMatriu(v.S, 2, 4).A);
  const n = S.map(e => e.slice(0, 3));
  const w = [0, 1, 2].map(m => componentDet(n[0], n[1], m));
  const director = u => u.some(x => !x.esZero()) && n.every(ni => escalarV(ni, u).esZero());
  const deLaRecta = P => S.every(e => escalarV(e.slice(0, 3), P).igual(e[3]));
  comprova(director(w), () => `${nom}: el model no té una recta`);
  const punts2 = [[1, 2], [0, -1], [3, -2], [-1, 1]].map(p => p.map(x => fr(x)));
  let fixa = null, sistema2 = null, uVector = null, Pcramer = {}, Ppunt = null;
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const grups = grupsAmbClau(tex);
      const pla = k => textPla(grups[k].tex);
      if (fila === FILA.dades) {
        comprova(pla('Rn') === 'r:', () => `${on}: falta «r:»`);
        [1, 2].forEach(k => {
          const [e, d] = pla(`Q${k}`).split('=');
          const f = S[k - 1];
          const c = coeficientsAfins(`(${e})-(${d})`);
          comprova(igualsV(c, f.slice(0, 3).concat([f[3].oposada()])), () => `${on}: l'equació ${k} («${pla(`Q${k}`)}») no és la de les dades`);
        });
      } else if (fila === FILA.esquema) {
        comprova(tex.startsWith('<svg') && tex.endsWith('</svg>'), () => `${on}: no és un esquema`);
      } else if (fila === FILA.normals) {
        [1, 2].forEach(k => {
          const [e, d] = pla(`P${k}`).replace(`(pi)_${k}:`, '').split('=');
          comprova(pla(`P${k}`).startsWith(`(pi)_${k}:`) && igualsV(coeficientsAfins(`(${e})-(${d})`), S[k - 1].slice(0, 3).concat([S[k - 1][3].oposada()])), () => `${on}: «${pla(`P${k}`)}» no és el pla ${k}`);
          if (!grups[`N${k}`]) return;
          const [esq, dre] = pla(`N${k}`).split('=');
          comprova(esq === `«n»_${k}` && igualsV(vectorPla(dre), n[k - 1]), () => `${on}: «${pla(`N${k}`)}» no és el vector normal del pla ${k}`);
        });
      } else if (fila === FILA.producte) {
        comprovaFilaProducte(tex, grups, n[0], n[1], '\\vec{n}_1 \\times \\vec{n}_2', on);
      } else if (fila === FILA.valor) {
        comprovaFilaValorProducte(grups, n[0], n[1], '\\vec{n}_1 \\times \\vec{n}_2', on, tex);
        if (grups.Uv) {
          const u = vectorPla(pla('Uv'));
          comprova(pla('Ul') === '«u»' && director(u), () => `${on}: «${pla('Uv')}» no és un vector director de la recta`);
          uVector = u;
        }
      } else if (fila === FILA.punt) {
        const [x, val] = pla('Fz').split('=');
        fixa = {j: ['x', 'y', 'z'].indexOf(x), val: M.llegeixNombre(val)};
        const altres = [0, 1, 2].filter(j => j !== fixa.j);
        sistema2 = [1, 2].map(k => {
          const [e, d] = pla(`S${k}`).split('=');
          const f = S[k - 1];
          // L'equació k amb la incògnita fixada, a uns quants punts de les altres dues.
          comprova(punts2.every(([a, b]) => {
            const X = [fr(0), fr(0), fr(0)];
            X[altres[0]] = a; X[altres[1]] = b; X[fixa.j] = fixa.val;
            const vals = {x: X[0], y: X[1], z: X[2]};
            return valorXYZD(`(${e})-(${d})`, vals).igual(escalarV(f.slice(0, 3), X).resta(f[3]));
          }), () => `${on}: «${pla(`S${k}`)}» no és l'equació ${k} amb ${x} = ${fixa.val.num}`);
          return altres.map(j => f[j]).concat([f[3].resta(f[fixa.j].producte(fixa.val))]);
        });
        const D2 = detMenor(sistema2.map(f => f.slice(0, 2)));
        comprova(!D2.esZero(), () => `${on}: el sistema reduït no té solució única`);
      } else if (fila === FILA.reduccio) {
        const vars = [0, 1, 2].filter(j => j !== fixa.j).map(j => 'xyz'[j]);
        const sol = comprovaReduccio(grups, sistema2, vars, on, tex);
        vars.forEach((x, k) => { Pcramer[x] = sol[k]; });
      } else if (fila === FILA.comprovacio) {
        const pn = puntAmbNom(pla('Pp'));          // «P(2,-1,0)», sense «=» (David)
        const P = vectorPla(pn.cos);
        comprova(pn.nom === 'P' && pn.resta === '' && deLaRecta(P) && P[fixa.j].igual(fixa.val)
          && [0, 1, 2].every(j => j === fixa.j || P[j].igual(Pcramer['xyz'[j]])), () => `${on}: «${pla('Pp')}» no és el punt calculat`);
        Ppunt = P;
        comprova(!grups.Ce1 && !grups.Ce2, () => `${on}: no s'han d'escriure comprovacions`);
        [1, 2].filter(k => grups[`Ce${k}`]).forEach(k => {
          const [nomC, resta] = pla(`Ce${k}`).split(':');
          const [e, d] = resta.split('=');
          const ni = n[k - 1];
          // Els valors substituïts són les coordenades de P, i els coeficients, els del pla.
          const ops = operandsDeProductes(e);
          const xs = ops.map(o => valorXYZD(o.text, {}));
          const noNuls = [0, 1, 2].filter(j => !ni[j].esZero());
          const ambVars = ops.reduceRight((t, o, c) => t.slice(0, o.inici) + 'xyz'[noNuls[c]] + t.slice(o.fi), e);
          comprova(nomC === `(pi)_${k}` && igualsV(xs, noNuls.map(j => P[j])) && igualsV(coeficientsAfins(ambVars), ni.concat([fr(0)]))
            && valorXYZD(e, {}).igual(M.llegeixNombre(d)) && M.llegeixNombre(d).igual(S[k - 1][3]), () => `${on}: «${pla(`Ce${k}`)}» no és el pla ${k} al punt P`);
        });
      } else if (fila === FILA.recta) {
        const m = /^r:\(x,y,z\)=(\(.*?\))\+λ(\(.*\))$/.exec(pla('Rv'));
        const P = vectorPla(m[1]), u = vectorPla(m[2]);
        comprova(deLaRecta(P) && director(u) && igualsV(P, Ppunt) && igualsV(u, uVector), () => `${on}: «${pla('Rv')}» no és la recta (amb P i u)`);
        const cos = /\\begin\{array\}\{l\}(.*)\\end\{array\}/.exec(grups.Rp.tex)[1].split('\\\\').map(l => textPla(l.trim()));
        comprova(cos.length === 3 && cos.every((l, j) => {
          const [x, e] = l.split('=');
          return x === 'xyz'[j] && [-2, 0, 1, 3].every(t => valorXYZD(e, {t: fr(t)}).igual(P[j].suma(u[j].producte(t))));
        }), () => `${on}: les equacions paramètriques no són les de la recta`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  comprova(passos[passos.length - 1].classes[FILA.recta] === 'final', () => `${nom}: la resposta no està destacada`);
  return linies;
}
const escalarV = (a, b) => a.reduce((s, x, i) => s.suma(x.producte(b[i])), fr(0));

seccio('recta donada per dos plans', () => {
  const L = p => RectaPlans.llegeixAdreca(p);
  comprova(L({}).valors.S === '1,1,-1,1;2,-1,1,5' && L({S: ' 1,0,-1,1 ; 0,1,2,0'}).valors.S === '1,0,-1,1;0,1,2,0', 'RectaPlans.llegeixAdreca');
  for (const [p, patro] of [
    [{S: '1,1,1,1;2,2,2,5'}, /paral·lels/], [{S: '1,1,1,1;2,2,2,2'}, /mateix pla/], [{S: '0,0,0,1;1,1,1,1'}, /tots 0/],
    [{S: '1,1,1;1,1,1'}, /ha de tenir 4/], [{S: '1,1,m,1;1,0,1,1'}, /paràmetre/], [{S: '1,1,1,1;2,1,1,1;0,1,0,1'}, /2 files/], [{S: '1,1,(1,1;1,1,1,1'}, /^No entenc/],
  ]) comprova(patro.test(L(p).error || ''), () => `RectaPlans.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  for (const v of RectaPlans.exemples) comprova(RectaPlans.valida(v) === null, () => `l'exemple ${v.S} no és vàlid: ${RectaPlans.valida(v)}`);

  const casos = RectaPlans.exemples.map(v => v.S);
  const atzar = aleatori(2036);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  for (let i = 0; i < 1500; i++) casos.push([0, 1].map(() => [enter(-4, 4), enter(-4, 4), enter(-4, 4), enter(-6, 6)].join(',')).join(';'));
  let valids = 0, linies = 0, passos = 0;
  const fixades = {};
  for (const text of casos) {
    const r = L({S: text});
    if (r.error) continue;
    const v = r.valors;
    valids++;
    const nom = `S = ${v.S}`;
    comprova(L(RectaPlans.escriuAdreca(v)).valors.S === v.S, () => `${nom}: anada i tornada de l'adreça`);
    let llista;
    try {
      llista = RectaPlans.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, RectaPlans.files, nom);
    linies += comprovaRectaPlans(llista, v, nom);
    passos += llista.length;
    const fz = /\{([xyz]) = 0\}/.exec(llista[llista.length - 1].files[RectaPlans.FILA.punt].replace(/\\htmlData\{[^}]*\}/g, ''));
    if (fz) fixades[fz[1]] = (fixades[fz[1]] || 0) + 1;
  }
  comprova(valids > 1000 && fixades.x && fixades.y && fixades.z, () => `pocs casos o no hi ha de tots: ${valids}, ${JSON.stringify(fixades)}`);
  return `${valids} rectes (incògnita fixada: ${JSON.stringify(fixades)}), ${passos} passos, ${linies} línies comprovades`;
});


/* ── 23. GEOMETRIA: POSICIÓ RELATIVA D'UNA RECTA I UN PLA ──────────── */

/**
 * Veritat d'un guió de la posició relativa d'una recta i un pla. Model: f(λ) = n · (P + λu) + D,
 * és a dir, aλ − c amb a = n · u i c = −(n · P + D); el cas surt de a i c. Files: les dades; el
 * punt genèric (P + λu a uns quants λ); la substitució i el desenvolupament (la mateixa funció de λ,
 * el segon sense parèntesis); l'equació aλ = c (la mateixa equació); la conclusió (λ, Q i la
 * posició, les del cas); l'esquema del cas; la comprovació (u · n terme a terme, i el punt al pla).
 */
function comprovaRectaPla(passos, v, nom) {
  const FILA = RectaPla.FILA;
  const [P, u] = Matrius.nombres(Matrius.llegeixMatriu(v.r, 2, 3, 99).A);
  const [fp] = Matrius.nombres(Matrius.llegeixMatriu(v.pi, 1, 4, 99).A);
  const n = fp.slice(0, 3), D = fp[3];
  const a = escalarV(n, u), c = escalarV(n, P).suma(D).oposada();
  const f = t => a.producte(t).resta(c);                                   // n · P(λ) + D
  const Pl = t => P.map((x, i) => x.suma(u[i].producte(t)));
  const cas = !a.esZero() ? 'secant' : !c.esZero() ? 'paralela' : 'continguda';
  const l0 = cas === 'secant' ? c.quocient(a) : null;
  const ts = [-2, 0, 1, 3].map(t => fr(t));
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const grups = grupsAmbClau(tex);
      const pla = k => textPla(grups[k].tex);
      if (fila === FILA.dades) {
        const m = /^r:\(x,y,z\)=(\(.*?\))\+λ(\(.*\))$/.exec(pla('Dr'));
        comprova(m && igualsV(vectorPla(m[1]), P) && igualsV(vectorPla(m[2]), u), () => `${on}: «${pla('Dr')}» no és la recta de les dades`);
        const [nomP, eq] = pla('Dp').split(':');
        const [e, z] = eq.split('=');
        comprova(nomP === '(pi)' && z === '0' && igualsV(coeficientsAfins(e), fp), () => `${on}: «${pla('Dp')}» no és el pla de les dades`);
      } else if (fila === FILA.generic) {
        const cs = partsPerComes(/^\((.*)\)$/.exec(pla('Gc'))[1]);
        // «P ∈ r:  P_r = (…)» (com ho diu el David).
        comprova(tex.startsWith('P \\in r:\\quad ') && grups.Gp.tex === 'P_r' && !grups.Gq && cs.length === 3 && ts.every(t => cs.every((e, j) => valorXYZD(e, {t}).igual(Pl(t)[j]))),
          () => `${on}: «${pla('Gc')}» no és el punt genèric P + λu`);
      } else if (fila === FILA.substitucio || fila === FILA.desenvolupa) {
        const [esq, z] = fila === FILA.substitucio ? ['Gs', 'Gz'] : ['Gx', 'Gw'];
        if (fila === FILA.substitucio) comprova(tex.startsWith('P \\in \\pi:\\quad '), () => `${on}: falta «P ∈ π:» davant de la substitució`);
        comprova(pla(z) === '0' && ts.every(t => valorXYZD(pla(esq), {t}).igual(f(t))), () => `${on}: «${pla(esq)} = 0» no és el pla al punt genèric`);
        if (fila === FILA.desenvolupa) comprova(!/[()]/.test(pla(esq)), () => `${on}: encara hi ha parèntesis`);
      } else if (fila === FILA.equacio) {
        const d = M.llegeixNombre(pla('Gd'));
        comprova(valorXYZD(pla('Ge'), {t: fr(0)}).esZero() && ts.every(t => valorXYZD(pla('Ge'), {t}).resta(d).igual(f(t))),
          () => `${on}: «${pla('Ge')} = ${pla('Gd')}» no és l'equació aλ = c`);
      } else if (fila === FILA.conclusio) {
        const Lv = grups.Lv.tex, Lr = grups.Lr ? grups.Lr.tex : null;
        if (cas === 'secant') {
          comprova(valorXYZD(pla('Lv').split('=')[1], {}).igual(l0) && pla('Lv').startsWith('λ='), () => `${on}: «${pla('Lv')}»: λ no és ${l0.num}/${l0.den}`);
          if (grups.Lq) {
            const pn = puntAmbNom(pla('Lq'));          // «Q(3,-2,4)», sense «=» (David)
            const Q = vectorPla(pn.cos);
            comprova(pn.nom === 'Q' && pn.resta === '' && igualsV(Q, Pl(l0)) && escalarV(n, Q).suma(D).esZero(), () => `${on}: «${pla('Lq')}» no és el punt d'intersecció`);
          }
          comprova(!Lr || Lr === '\\text{La recta } r \\text{ talla el pla } \\pi \\text{ en el punt } Q', () => `${on}: la posició no és «es tallen»`);
        } else {
          comprova(Lv === (cas === 'paralela' ? '\\text{cap valor de } \\lambda' : '\\text{tots els valors de } \\lambda') && !grups.Lq, () => `${on}: «${Lv}» no és el cas`);
          comprova(Lr === (cas === 'paralela' ? '\\text{La recta } r \\text{ és paral}\\mathord{\\cdotp}\\text{lela al pla } \\pi' : '\\text{La recta } r \\text{ està continguda en el pla } \\pi'), () => `${on}: «${Lr}» no és la posició`);
        }
      } else if (fila === FILA.esquema) {
        comprova(tex === Geometria.esquema({secant: 'recta-secant', paralela: 'recta-paralela', continguda: 'recta-continguda'}[cas]), () => `${on}: no és l'esquema del cas`);
      } else if (fila === FILA.comprovacio) {
        comprova(false, () => `${on}: no s'han d'escriure comprovacions`);
        const [esq, expr, val] = pla('Cu').split('=');
        comprova(esq === '«u»*«n»' && expr === textPla(Geometria.texEscalar(u, n)) && valorXYZD(expr, {}).igual(a)
          && val === (a.esZero() ? '0' : `${textPla(M.texNombre(a))}≠0`), () => `${on}: «${pla('Cu')}» no és u · n`);
        const [nomQ, resta] = pla('Cp').split(':');
        const [e, valor] = resta.split('=');
        const Q = cas === 'secant' ? Pl(l0) : P;
        const ops = operandsDeProductes(e);
        const noNuls = [0, 1, 2].filter(j => !n[j].esZero());
        const ambVars = ops.reduceRight((t, o, k) => t.slice(0, o.inici) + 'xyz'[noNuls[k]] + t.slice(o.fi), e);
        const vQ = escalarV(n, Q).suma(D);
        comprova(nomQ === (cas === 'secant' ? 'Q' : 'P') && igualsV(ops.map(o => valorXYZD(o.text, {})), noNuls.map(j => Q[j]))
          && igualsV(coeficientsAfins(ambVars), fp) && valorXYZD(e, {}).igual(vQ) && valor === (vQ.esZero() ? '0' : `${textPla(M.texNombre(vQ))}≠0`)
          && vQ.esZero() === (cas !== 'paralela'), () => `${on}: «${pla('Cp')}» no és el pla al punt ${nomQ}`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  comprova(passos[passos.length - 1].classes[FILA.conclusio] === 'final', () => `${nom}: la resposta no està destacada`);
  return {linies, cas};
}

seccio('posició relativa recta i pla', () => {
  const L = p => RectaPla.llegeixAdreca(p);
  comprova(L({}).valors.r === '1,0,2;1,-1,1' && L({r: ' 1,2,0 ; 2,1,-1', pi: '1,-1,1,4'}).valors.r === '1,2,0;2,1,-1', 'RectaPla.llegeixAdreca');
  for (const [p, patro] of [
    [{r: '1,1,1;0,0,0', pi: '1,1,1,1'}, /\(0, 0, 0\)/], [{r: '1,1,1;1,0,0', pi: '0,0,0,1'}, /tots 0/], [{r: '1,1,1;1,0,0'}, /hi han de ser/],
    [{r: '1,1;1,0', pi: '1,1,1,1'}, /3 elements/], [{r: '1,1,m;1,0,1', pi: '1,1,1,1'}, /paràmetre/], [{r: '1,1,1;1,0,0', pi: '1,1,1,100'}, /−99 a 99/],
    [{r: '1,(1,1;1,0,0', pi: '1,1,1,1'}, /^No entenc/],
  ]) comprova(patro.test(L(p).error || ''), () => `RectaPla.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  for (const v of RectaPla.exemples) comprova(RectaPla.valida(v) === null, () => `l'exemple ${JSON.stringify(v)} no és vàlid: ${RectaPla.valida(v)}`);

  const casos = RectaPla.exemples.map(v => Object.assign({}, v));
  const atzar = aleatori(2037);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  const vec = () => [enter(-4, 4), enter(-4, 4), enter(-4, 4)];
  const creu = (p, q) => [p[1] * q[2] - p[2] * q[1], p[2] * q[0] - p[0] * q[2], p[0] * q[1] - p[1] * q[0]];
  for (let i = 0; i < 1500; i++) {
    const P = vec(), n = vec();
    let u = vec(), D = enter(-9, 9);
    if (i % 3) {
      u = creu(n, [enter(-1, 1), enter(-1, 1), enter(-1, 1)]);                      // u ⟂ n: paral·lela o continguda
      if (i % 3 === 1) D = -(n[0] * P[0] + n[1] * P[1] + n[2] * P[2]);
    }
    if ([...u, D].some(x => Math.abs(x) > 99)) continue;
    casos.push({r: `${P.join(',')};${u.join(',')}`, pi: `${n.join(',')},${D}`});
  }
  let valids = 0, linies = 0, passos = 0;
  const comptes = {};
  for (const p of casos) {
    const r = L(p);
    if (r.error) continue;
    const v = r.valors;
    valids++;
    const nom = `r = ${v.r}, pi = ${v.pi}`;
    const t = L(RectaPla.escriuAdreca(v)).valors;
    comprova(t.r === v.r && t.pi === v.pi, () => `${nom}: anada i tornada de l'adreça`);
    let llista;
    try {
      llista = RectaPla.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, RectaPla.files, nom);
    const res = comprovaRectaPla(llista, v, nom);
    linies += res.linies;
    comptes[res.cas] = (comptes[res.cas] || 0) + 1;
    passos += llista.length;
  }
  comprova(valids > 1000 && comptes.secant > 200 && comptes.paralela > 200 && comptes.continguda > 200, () => `pocs casos o no hi ha de tots: ${valids}, ${JSON.stringify(comptes)}`);
  return `${valids} casos (${JSON.stringify(comptes)}), ${passos} passos, ${linies} línies comprovades`;
});


/* ── 24. GEOMETRIA: POSICIÓ RELATIVA DE DUES RECTES ────────────────── */

const creuV = (a, b) => [0, 1, 2].map(m => componentDet(a, b, m));
const paralV = (a, b) => creuV(a, b).every(x => x.esZero());
/**
 * Una línia de proporcionalitat de Geometria.texProporcio (TeX), per als vectors a i b: si diu
 * «b = k a», b ha de ser k·a; si diu «\dfrac{a_p}{b_p} \neq \dfrac{a_q}{b_q}», hi ha d'haver dues
 * components p < q amb aquests valors i productes creuats diferents; si diu «a_x = …, b_x = 0», també.
 * Torna si diu que són proporcionals.
 */
function llegeixProporcio(tex, a, b, nomA, nomB, compA, compB) {
  const esc = t => t.replace(/[\\{}()[\]^$.|*+?]/g, '\\$&');
  let m = new RegExp(`^${esc(nomB)} = (.*?)${esc(nomA)}$`).exec(tex);
  if (m) {
    const k = m[1] === '' ? fr(1) : m[1] === '-' ? fr(-1) : valorXYZD(textPla(m[1].replace(/\\,$/, '')), {});
    if (!b.every((x, j) => x.igual(a[j].producte(k)))) throw new Error(`«${tex}» no és cert`);
    return true;
  }
  m = /^\\dfrac\{(-?\d+)\}\{(-?\d+)\} \\neq \\dfrac\{(-?\d+)\}\{(-?\d+)\}$/.exec(tex);
  if (m) {
    const [ap, bp, aq, bq] = m.slice(1).map(x => fr(Number(x)));
    const ok = [[0, 1], [0, 2], [1, 2]].some(([p, q]) => a[p].igual(ap) && b[p].igual(bp) && a[q].igual(aq) && b[q].igual(bq));
    if (!ok || bp.esZero() || bq.esZero() || ap.producte(bq).igual(aq.producte(bp))) throw new Error(`«${tex}» no és cert`);
    return false;
  }
  m = new RegExp(`^${esc(compA)}_\\{([xyz])\\} = (-?\\d+),\\\\ ${esc(compB)}_\\{\\1\\} = 0$`).exec(tex);
  if (m) {
    const j = 'xyz'.indexOf(m[1]);
    if (!a[j].igual(fr(Number(m[2]))) || a[j].esZero() || !b[j].esZero()) throw new Error(`«${tex}» no és cert`);
    return false;
  }
  throw new Error(`«${tex}» no és una proporció`);
}

/**
 * Veritat d'un guió de la posició relativa de dues rectes. Model independent: paral·leles si
 * u × v = 0 (coincidents si, a més, PQ × u = 0); si no, es tallen si |PQ u v| = 0 (determinant per
 * Laplace) i es creuen si no. Files: les dades; els vectors i la proporcionalitat; els punts
 * genèrics; cada equació (equivalent a la coordenada i de P + λu = Q + μv, o de P + λu = Q); les
 * marques (verd: dues equacions de determinant no nul; groc: la tercera; vermell: una «0 = c»);
 * Cramer (les matrius del parell verd i la solució); la tercera equació (la substitució, el valor
 * i si es compleix); la conclusió i l'esquema del cas; la comprovació (PQ i el determinant, o PQ
 * proporcional a u).
 */
function comprovaDuesRectes(passos, v, nom) {
  const FILA = DuesRectes.FILA;
  const llegeix = t => Matrius.nombres(Matrius.llegeixMatriu(t, 2, 3, 99).A);
  const [P, u] = llegeix(v.r), [Q, w] = llegeix(v.s);
  const PQ = Q.map((x, i) => x.resta(P[i]));
  const paral = paralV(u, w);
  const cas = paral ? (paralV(PQ, u) ? 'coincidents' : 'paraleles') : detLaplace([PQ, u, w]).esZero() ? 'tallen' : 'creuen';
  const ts = [[0, 0], [1, 0], [0, 1], [2, -3]].map(([a, b]) => [fr(a), fr(b)]);
  let parell = null, tercera = null, sol = {};
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const grups = grupsAmbClau(tex);
      const pla = k => textPla(grups[k].tex);
      if (fila === FILA.dades) {
        for (const [k, R0, d, l] of [['Dr', P, u, 'λ'], ['Ds', Q, w, 'μ']]) {
          const m = new RegExp(`^${k[1]}:\\(x,y,z\\)=(\\(.*?\\))\\+${l}(\\(.*\\))$`).exec(pla(k));
          comprova(m && igualsV(vectorPla(m[1]), R0) && igualsV(vectorPla(m[2]), d), () => `${on}: «${pla(k)}» no és la recta de les dades`);
        }
      } else if (fila === FILA.direccions) {
        comprova(pla('Ku') === `«u»=(${u.map(x => textPla(M.texNombre(x))).join(',')})` && pla('Kv') === `«v»=(${w.map(x => textPla(M.texNombre(x))).join(',')})`, () => `${on}: els vectors directors no són els de les dades`);
        // Els punts P i Q, amb nom i sense «=» (David), abans de fer-los servir.
        const pP = puntAmbNom(pla('KP')), pQ = puntAmbNom(pla('KQ'));
        comprova(pP && pP.nom === 'P' && pP.resta === '∈r' && igualsV(vectorPla(pP.cos), P) && pQ && pQ.nom === 'Q' && pQ.resta === '∈s' && igualsV(vectorPla(pQ.cos), Q),
          () => `${on}: els punts P i Q no són els de les dades`);
        if (!grups.Kp) return;
        const m = /^(.*)\\ \\Rightarrow\\ \\vec\{u\} \\(n?)parallel \\vec\{v\}$/.exec(grups.Kp.tex);
        const diu = llegeixProporcio(m[1], u, w, '\\vec{u}', '\\vec{v}', 'u', 'v');
        comprova(diu === (m[2] === '') && diu === paral, () => `${on}: la proporcionalitat de u i v no és certa`);
      } else if (fila === FILA.igualtat) {
        // Les equacions paramètriques de r i de s (sempre, abans d'igualar).
        for (const [k, R0, d, l, nomR] of [['Pr', P, u, 't', 'r'], ['Ps', Q, w, 's', 's']]) {
          const m = /^([rs]):\{l(.*?)\.?$/.exec(pla(k).replace(/«|»/g, ''));
          const eqs = m ? m[2].split(';') : [];
          comprova(m && m[1] === nomR && eqs.length === 3 && eqs.every((e, j) => { const [x, ex] = e.split('='); return x === 'xyz'[j] && ts.every(([a]) => valorXYZD(ex.replace(/μ/g, 's'), {[l]: a}).igual(R0[j].suma(d[j].producte(a)))); }),
            () => `${on}: «${pla(k)}» no són les equacions paramètriques de ${nomR}`);
        }
        if (!grups.Ia) return;
        const generic = (t, R0, d, l) => partsPerComes(/^\((.*)\)$/.exec(t)[1]).map(e => ts.map(([a]) => valorXYZD(e, {[l]: a})));
        const esPunt = (t, R0, d, l) => generic(t, R0, d, l).every((vs, j) => vs.every((x, c) => x.igual(R0[j].suma(d[j].producte(ts[c][0])))));
        comprova(esPunt(pla('Ia'), P, u, 't'), () => `${on}: «${pla('Ia')}» no és el punt genèric de r`);
        comprova(paral ? igualsV(vectorPla(pla('Ib')), Q) : esPunt(pla('Ib'), Q, w, 's'), () => `${on}: «${pla('Ib')}» no és ${paral ? 'Q' : 'el punt genèric de s'}`);
      } else if (fila === FILA.sistema) {
        const marques = [];
        [0, 1, 2].forEach(c => {
          const g = grups[`E${c + 1}`];
          const [e, d] = textPla(g.tex).split('=');
          const f = ([t, s]) => valorXYZD(`(${e})-(${d})`, {t, s});
          const obtingut = [f([fr(0), fr(0)]), f([fr(1), fr(0)]).resta(f([fr(0), fr(0)])), f([fr(0), fr(1)]).resta(f([fr(0), fr(0)]))];
          const esperat = [PQ[c].oposada(), u[c], paral ? fr(0) : w[c].oposada()];
          comprova(ts.every(p => f(p).igual(obtingut[0].suma(obtingut[1].producte(p[0])).suma(obtingut[2].producte(p[1]))))
            && (esperat.every(x => x.esZero()) ? obtingut.every(x => x.esZero()) : proporcionals4(obtingut.concat([fr(0)]), esperat.concat([fr(0)]))),
          () => `${on}: «${textPla(g.tex)}» no és l'equació de la coordenada ${'xyz'[c]}`);
          marques.push(g.marca);
        });
        const S = [0, 1, 2].map(c => [u[c], w[c].oposada(), PQ[c]]);
        if (marques.includes('mes')) {
          const verds = [0, 1, 2].filter(c => marques[c] === 'mes');
          comprova(verds.length === 2 && marques.filter(m => m === 'tria').length === 1 && !detMenor(verds.map(c => S[c].slice(0, 2))).esZero(),
            () => `${on}: les equacions marcades no són un sistema de determinant no nul (${marques})`);
          parell = verds.map(c => S[c]); tercera = marques.indexOf('tria');
        }
        if (marques.includes('menys')) {
          const c = marques.indexOf('menys');
          comprova(S[c][0].esZero() && S[c][1].esZero() && !S[c][2].esZero() && marques.filter(Boolean).length === 1, () => `${on}: l'equació en vermell no és «0 = c»`);
        }
      } else if (fila === FILA.reduccio) {
        const [l0, m0] = comprovaReduccio(grups, parell, ['λ', 'μ'], on, tex);
        sol = {l: l0, m: m0};
      } else if (fila === FILA.tercera) {
        const S = [0, 1, 2].map(c => [u[c], w[c].oposada(), PQ[c]]);
        // «-λ - μ = -3 ⇒ -2 - 1 = -3» (verd si es compleix) o «… = 1 ≠ 3» (vermell); «0 = 0» si no té incògnites.
        const f0 = S[tercera];
        comprova(tex.endsWith(grups.Tq.marca === 'mes' ? '\\quad \\text{(es compleix!)}' : '\\quad \\text{(no es compleix)}'), () => `${on}: falta dir si es compleix`);
        if (f0[0].esZero() && f0[1].esZero()) {
          comprova(pla('Tq') === '0=0' && f0[2].esZero() && grups.Tq.marca === 'mes', () => `${on}: «${pla('Tq')}» no és la tercera equació (0 = 0)`);
          return;
        }
        const [eq, sub] = pla('Tq').split('⇒');
        const [e0, d0] = eq.split('=');
        const f = S[tercera];
        const ff = ([t, s_]) => valorXYZD(`(${e0})-(${d0})`, {t, s: s_});
        comprova(ts.every(p_ => ff(p_).igual(f[0].producte(p_[0]).suma(f[1].producte(p_[1])).resta(f[2]))), () => `${on}: «${eq}» no és la tercera equació`);
        const [e, val, ...neq] = sub.split('=');
        const vk = f[0].producte(sol.l).suma(f[1].producte(sol.m));
        const [valor, diferent] = val.split('≠');
        comprova(substitucioCorrecta(e, f.slice(0, 2), [sol.l, sol.m], null)
          && valorXYZD(e, {}).igual(vk) && M.llegeixNombre(valor).igual(vk) && grups.Tq.marca === (vk.igual(f[2]) ? 'mes' : 'menys')
          && (vk.igual(f[2]) ? diferent === undefined : M.llegeixNombre(diferent).igual(f[2])) && !neq.length, () => `${on}: «${pla('Tq')}» no és la tercera equació amb λ i μ`);
      } else if (fila === FILA.conclusio) {
        const Lr = grups.Lr ? grups.Lr.tex : null;
        comprova(!/\\cap|\\varnothing|\\subset/.test(tex), () => `${on}: notació de conjunts a la resposta`);
        if (cas === 'tallen') {
          const m = /^λ=(.*)⇒R(\(.*\))$/.exec(pla('Lv'));          // «R(3,2,0)», sense «=» (David)
          const l0 = valorXYZD(m[1], {}), X = vectorPla(m[2]);
          comprova(l0.igual(sol.l) && igualsV(X, P.map((x, j) => x.suma(u[j].producte(l0)))) && paralV(X.map((x, j) => x.resta(Q[j])), w), () => `${on}: «${pla('Lv')}» no és el punt d'intersecció`);
          comprova(Lr === '\\text{Les rectes } r \\text{ i } s \\text{ es tallen en el punt } R', () => `${on}: la posició no és «es tallen»`);
        } else {
          // La resposta, amb una frase (David: res de r ∩ s).
          const esperat = {creuen: [undefined, '\\text{Les rectes } r \\text{ i } s \\text{ es creuen}'],
            paraleles: ['\\text{cap } \\lambda \\text{ les compleix totes}\\ \\Rightarrow\\ Q \\notin r', '\\text{Les rectes } r \\text{ i } s \\text{ són paral}\\mathord{\\cdotp}\\text{leles}'],
            coincidents: ['\\text{el mateix } \\lambda\\ \\Rightarrow\\ Q \\in r', '\\text{Les rectes } r \\text{ i } s \\text{ són coincidents}']}[cas];
          comprova((grups.Lv ? grups.Lv.tex : undefined) === esperat[0] && Lr === esperat[1], () => `${on}: «${grups.Lv && grups.Lv.tex}», «${Lr}» no és el cas (${cas})`);
        }
      } else if (fila === FILA.esquema) {
        comprova(tex === Geometria.esquema({tallen: 'rectes-es-tallen', creuen: 'rectes-es-creuen', paraleles: 'rectes-paraleles', coincidents: 'rectes-coincidents'}[cas]), () => `${on}: no és l'esquema del cas`);
      } else if (fila === FILA.comprovacio) {
        comprova(false, () => `${on}: no s'han d'escriure comprovacions`);
        comprova(pla('Cq').startsWith('«PQ»=Q-P=') && igualsV(vectorPla(pla('Cq').split('=')[2]), PQ), () => `${on}: «${pla('Cq')}» no és Q − P`);
        if (paral) {
          const m = /^(.*)\\ \\Rightarrow\\ \\overrightarrow\{PQ\} \\(n?)parallel \\vec\{u\}$/.exec(grups.Cd.tex);
          const diu = llegeixProporcio(m[1], u, PQ, '\\vec{u}', '\\overrightarrow{PQ}', 'u', 'PQ');
          comprova(diu === (m[2] === '') && diu === (cas === 'coincidents'), () => `${on}: la proporcionalitat de PQ i u no és certa`);
        } else {
          const B = cossosVmatrix(grups.Cd.tex)[0].map(f => f.map(c => M.llegeixNombre(c)));
          const D3 = detLaplace([PQ, u, w]);
          const [valor, ne] = pla('Cv').split('≠');
          comprova(B.length === 3 && [PQ, u, w].every((f, a) => igualsV(B[a], f)) && valorXYZD(pla('Cs'), {}).igual(D3) && M.llegeixNombre(valor).igual(D3)
            && (D3.esZero() ? ne === undefined : ne === '0') && D3.esZero() === (cas === 'tallen'), () => `${on}: el determinant de PQ, u, v no és cert`);
        }
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  comprova(passos[passos.length - 1].classes[FILA.conclusio] === 'final', () => `${nom}: la resposta no està destacada`);
  return {linies, cas};
}

seccio('posició relativa de dues rectes', () => {
  const L = p => DuesRectes.llegeixAdreca(p);
  comprova(L({}).valors.r === '1,0,2;1,1,-1' && L({r: ' 1,2,0 ; 1,-1,2', s: '0,1,1;-2,2,-4'}).valors.r === '1,2,0;1,-1,2', 'DuesRectes.llegeixAdreca');
  for (const [p, patro] of [
    [{r: '1,1,1;0,0,0', s: '1,1,1;1,0,0'}, /\(0, 0, 0\)/], [{r: '1,1,1;1,0,0'}, /hi han de ser/], [{r: '1,1;1,0', s: '1,1,1;1,0,0'}, /3 elements/],
    [{r: '1,1,m;1,0,1', s: '1,1,1;1,0,0'}, /paràmetre/], [{r: '1,1,1;1,0,0', s: '1,1,1;100,0,0'}, /−99 a 99/], [{r: '1,(1,1;1,0,0', s: '1,1,1;1,0,0'}, /^No entenc/],
  ]) comprova(patro.test(L(p).error || ''), () => `DuesRectes.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  for (const v of DuesRectes.exemples) comprova(DuesRectes.valida(v) === null, () => `l'exemple ${JSON.stringify(v)} no és vàlid: ${DuesRectes.valida(v)}`);

  const casos = DuesRectes.exemples.map(v => Object.assign({}, v));
  const atzar = aleatori(2038);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  const vec = (m = 3) => [enter(-m, m), enter(-m, m), enter(-m, m)];
  const txt = (A, d) => `${A.join(',')};${d.join(',')}`;
  for (let i = 0; i < 1600; i++) {
    const tipus = i % 4;
    const P = vec(), u = vec();
    let Q = vec(), w = vec();
    if (tipus === 1) {                                                  // es tallen en X
      const X = vec(), l = enter(-2, 2), m = enter(-2, 2);
      P.splice(0, 3, ...X.map((x, j) => x - l * u[j])); Q = X.map((x, j) => x - m * w[j]);
    } else if (tipus >= 2) {                                            // paral·leles o coincidents
      const k = [-2, -1, 2, 3][enter(0, 3)];
      w = u.map(x => k * x);
      if (tipus === 3) { const t = enter(-2, 2); Q = P.map((x, j) => x + t * u[j]); }
    }
    if ([...P, ...Q, ...u, ...w].some(x => Math.abs(x) > 99)) continue;
    casos.push({r: txt(P, u), s: txt(Q, w)});
  }
  let valids = 0, linies = 0, passos = 0;
  const comptes = {};
  for (const p of casos) {
    const r = L(p);
    if (r.error) continue;
    const v = r.valors;
    valids++;
    const nom = `r = ${v.r}, s = ${v.s}`;
    const t = L(DuesRectes.escriuAdreca(v)).valors;
    comprova(t.r === v.r && t.s === v.s, () => `${nom}: anada i tornada de l'adreça`);
    let llista;
    try {
      llista = DuesRectes.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, DuesRectes.files, nom);
    const res = comprovaDuesRectes(llista, v, nom);
    linies += res.linies;
    comptes[res.cas] = (comptes[res.cas] || 0) + 1;
    passos += llista.length;
  }
  comprova(valids > 1000 && ['tallen', 'creuen', 'paraleles', 'coincidents'].every(c => comptes[c] > 150), () => `pocs casos o no hi ha de tots: ${valids}, ${JSON.stringify(comptes)}`);
  return `${valids} casos (${JSON.stringify(comptes)}), ${passos} passos, ${linies} línies comprovades`;
});


/* ── RADICALS: VALORS EXACTES DE LA FORMA q·√r ─────────────────────── */

/**
 * Un valor q·√r (q, r Fraccio; r ≥ 0, sense factors quadrats: r = 1 si és racional). Les
 * distàncies són d'aquesta forma. Les sumes només es poden fer amb el mateix r (a la pissarra,
 * només se sumen nombres racionals, dins dels valors absoluts i de les arrels).
 */
function radical(q, r = fr(1)) {
  if (q.esZero() || r.esZero()) return {q: fr(0), r: fr(1)};
  // √(a/b) = √(ab)/b; i √(ab) = k√m, amb m sense quadrats.
  const ab = r.num * r.den;
  let k = 1, m = ab;
  for (let p = 2; p * p <= m; p++) while (m % (p * p) === 0) { m /= p * p; k *= p; }
  return {q: q.producte(fr(k, r.den)), r: fr(m)};
}
const radicalIgual = (a, b) => a.q.igual(b.q) && a.r.igual(b.r);
const radicalQuadrat = a => a.q.producte(a.q).producte(a.r);

/**
 * Llegeix un text pla de textPla amb nombres, + − * /, parèntesis, sqrt(…), valors absoluts |…| i ^2,
 * i en torna el valor q·√r. Llança si surt una suma de radicals diferents.
 */
function valorRadical(text) {
  const t = text.replace(/\s+/g, '');
  let i = 0, dins = 0;                         // dins: valors absoluts oberts (dins d'un, «|» el tanca)
  const mira = () => t[i];
  const espera = c => { if (t[i] !== c) throw new Error(`s'esperava «${c}» a «${t}» (posició ${i})`); i++; };
  function suma() {
    let v = producte();
    while (mira() === '+' || mira() === '-') {
      const op = t[i++];
      const w = producte();
      if (v.q.esZero()) { v = op === '+' ? w : {q: w.q.oposada(), r: w.r}; continue; }
      if (w.q.esZero()) continue;
      if (!v.r.igual(w.r)) throw new Error(`suma de radicals diferents a «${t}»`);
      v = radical(op === '+' ? v.q.suma(w.q) : v.q.resta(w.q), v.r);
    }
    return v;
  }
  function producte() {
    let v = unari();
    while (mira() === '*' || mira() === '/' || mira() === '(' || (mira() && (/[\da-z]/.test(mira()) || (mira() === '|' && !dins)) && /[\d)]/.test(t[i - 1]))) {
      const op = mira() === '*' || mira() === '/' ? t[i++] : '*';
      const w = unari();
      v = op === '*' ? radical(v.q.producte(w.q), v.r.producte(w.r)) : radical(v.q.quocient(w.q).quocient(w.r), v.r.producte(w.r));
    }
    return v;
  }
  function unari() {
    if (mira() === '-') { i++; const v = unari(); return {q: v.q.oposada(), r: v.r}; }
    if (mira() === '+') { i++; return unari(); }
    let v = atom();
    if (mira() === '^') {
      i++;
      const e = /^\(?(\d+)\)?/.exec(t.slice(i));
      i += e[0].length;
      if (e[1] !== '2') throw new Error('només quadrats');
      v = radical(radicalQuadrat(v));
    }
    return v;
  }
  function atom() {
    if (mira() === '(') { i++; const v = suma(); espera(')'); return v; }
    if (t.startsWith('sqrt(', i)) {
      i += 5;
      const v = suma();
      espera(')');
      if (!v.r.igual(1) || v.q.signe() < 0) throw new Error('arrel d\'un nombre no racional o negatiu');
      return radical(fr(1), v.q);
    }
    if (mira() === '|') {
      i++; dins++;
      const v = suma();
      espera('|'); dins--;
      return {q: v.q.abs(), r: v.r};
    }
    const m = /^\d+/.exec(t.slice(i));
    if (!m) throw new Error(`no entenc «${t.slice(i)}»`);
    i += m[0].length;
    return radical(fr(Number(m[0])));
  }
  const v = suma();
  if (i !== t.length) throw new Error(`sobra «${t.slice(i)}»`);
  return v;
}

/* ── 25. GEOMETRIA: DISTÀNCIES ─────────────────────────────────────── */

/** Un text pla amb la variable «v» canviada per un nombre, i el seu valor q·√r. */
const radicalAmb = (text, v, x) => valorRadical(text.split(v).join(`(${textPla(M.texNombre(x))})`));
/** La distància |N| / √S com a radical: √(N²/S). */
const distancia = (N, S) => radical(fr(1), N.producte(N).quocient(S));
/** El text pla d'un radical simplificat (sense arrels al denominador i amb el radicand sense quadrats). */
const radicalSimplificat = t => !/\/\(?sqrt/.test(t) && [...t.matchAll(/sqrt\((\d+)\)/g)].every(m => radical(fr(1), fr(Number(m[1]))).r.igual(Number(m[1])));

/**
 * Veritat d'un guió de distàncies. Model, per a cada problema: la distància d'un punt a un pla
 * |n·P + D| / |n| (comparada pel quadrat: d² és racional); dos plans paral·lels si n₁ × n₂ = 0 (i
 * no són el mateix si els termes independents no van en la mateixa proporció); 0 si es tallen;
 * recta paral·lela al pla si u·n = 0; els plans a distància d: (D − D_π)² = d²|n|²; els punts de
 * la recta a distància d: P + λu amb (n·(P + λu) + D)² = d²|n|²; punt–recta: |QP × u|² / |u|².
 * Cada fila: les dades, l'esquema del problema, la posició (amb les raons), el punt, el producte
 * vectorial, cada tros de la fórmula (el seu valor és la distància; la substitució és la de les
 * dades; el resultat, simplificat) i les solucions (que compleixen la condició).
 */
function comprovaDistancies(passos, p, nom) {
  const FILA = Distancies.FILA;
  const npD = (pl, Q) => escalarV(pl.n, Q).suma(pl.D);
  const S = pl => escalarV(pl.n, pl.n);
  const esquemes = {'punt-pla': 'distancia-punt-pla', 'punt-pla-arrel': 'distancia-punt-pla', 'plans-paralels': 'paralels', 'plans-secants': 'dos-plans',
    'recta-paralela': 'recta-paralela', 'recta-secant': 'recta-secant', 'plans-distancia': 'plans-a-distancia', 'punts-recta': 'punts-a-distancia', 'punt-recta': 'distancia-punt-recta'};
  // La distància del model.
  let d = null, punt = null, pla = p.pi;
  if (p.id === 'punt-pla' || p.id === 'punt-pla-arrel') { punt = p.P; d = distancia(npD(p.pi, p.P), S(p.pi)); }
  if (p.id === 'plans-paralels' || p.id === 'plans-secants') {
    pla = p.sigma;
    if (!paralV(p.pi.n, p.sigma.n)) d = radical(fr(0));
  }
  if (p.id === 'recta-paralela' || p.id === 'recta-secant') punt = p.r.P;
  if (p.id === 'recta-paralela' || p.id === 'recta-secant') d = escalarV(p.r.u, p.pi.n).esZero() ? distancia(npD(p.pi, p.r.P), S(p.pi)) : radical(fr(0));
  if (p.id === 'punt-recta') {
    const QP = p.P.map((x, i) => x.resta(p.r.P[i]));
    const w = creuV(QP, p.r.u);
    d = radical(fr(1), escalarV(w, w).quocient(escalarV(p.r.u, p.r.u)));
  }
  const d2 = p.d ? p.d.producte(p.d) : null;
  let linies = 0, solucions = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const grups = grupsAmbClau(tex);
      const pla_ = k => textPla(grups[k].tex);
      if (fila === FILA.dades) {
        const linies = Object.keys(grups).filter(k => /^Dd\d$/.test(k)).map(pla_);
        for (const l of linies) {
          let m;
          if ((m = puntAmbNom(l)) && m.nom === 'P' && m.resta === '') comprova(igualsV(vectorPla(m.cos), p.P), () => `${on}: «${l}»`);
          else if ((m = /^r:\(x,y,z\)=(\(.*?\))\+λ(\(.*\))$/.exec(l))) comprova(igualsV(vectorPla(m[1]), p.r.P) && igualsV(vectorPla(m[2]), p.r.u), () => `${on}: «${l}»`);
          else if ((m = /^d=(.*)$/.exec(l))) comprova(M.llegeixNombre(m[1]).igual(p.d), () => `${on}: «${l}»`);
          else {
            const [nomP, eq] = l.split(':');
            const pl = {'(pi)': p.pi, '(pi)_1': p.pi, '(pi)_2': p.sigma}[nomP];
            const [e, z] = eq.split('=');
            comprova(pl && z === '0' && igualsV(coeficientsAfins(e), pl.n.concat([pl.D])), () => `${on}: «${l}» no és de les dades`);
          }
        }
      } else if (fila === FILA.esquema) {
        comprova(tex === Geometria.esquema(esquemes[p.id]), () => `${on}: no és l'esquema del problema`);
      } else if (fila === FILA.posicio) {
        if (p.id === 'plans-paralels' || p.id === 'plans-secants') {
          comprova(grups.Ps.tex === `\\vec{n}_1 = ${Geometria.texPunt(p.pi.n)},\\quad \\vec{n}_2 = ${Geometria.texPunt(p.sigma.n)}`, () => `${on}: els vectors normals`);
          if (grups.Pt) {
            const t = grups.Pt.tex;
            if (paralV(p.pi.n, p.sigma.n)) {
              const m = /^(.*),\\quad (-?\d+) \\neq (-?\d+) \\cdot \(?(-?\d+)\)?\\ \\Rightarrow\\ \\pi_1 \\parallel \\pi_2$/.exec(t);
              const k = p.sigma.n.find(x => !x.esZero()).quocient(p.pi.n.find(x => !x.esZero()));
              comprova(m && llegeixProporcio(m[1], p.pi.n, p.sigma.n, '\\vec{n}_1', '\\vec{n}_2', 'n_1', 'n_2') && fr(Number(m[2])).igual(p.sigma.D)
                && fr(Number(m[3])).igual(k) && fr(Number(m[4])).igual(p.pi.D) && !p.sigma.D.igual(k.producte(p.pi.D)), () => `${on}: «${t}» no és cert`);
            } else {
              const m = /^(.*)\\ \\Rightarrow\\ \\vec\{n\}_1 \\nparallel \\vec\{n\}_2$/.exec(t);
              comprova(m && llegeixProporcio(m[1], p.pi.n, p.sigma.n, '\\vec{n}_1', '\\vec{n}_2', 'n_1', 'n_2') === false, () => `${on}: «${t}» no és cert`);
            }
          }
        } else if (p.id === 'recta-paralela' || p.id === 'recta-secant') {
          const a = escalarV(p.r.u, p.pi.n);
          // u i n, amb nom abans de fer-los servir (David).
          comprova(grups.Pu && grups.Pu.tex === `\\vec{u} = ${Geometria.texPunt(p.r.u)},\\quad \\vec{n} = ${Geometria.texPunt(p.pi.n)}`, () => `${on}: falten u i n`);
          if (!grups.Ps) return;
          const [esq, expr, val] = pla_('Ps').split('=');
          comprova(esq === '«u»*«n»' && expr === textPla(Geometria.texEscalar(p.r.u, p.pi.n)) && val === (a.esZero() ? '0' : `${textPla(M.texNombre(a))}≠0`), () => `${on}: «${pla_('Ps')}» no és u · n`);
          if (grups.Pt) {
            const m = /^P\((.*?)\):\\quad (.*) = (-?\d+) \\neq 0\\ \\Rightarrow\\ r \\parallel \\pi$/.exec(grups.Pt.tex);
            if (m) m.splice(1, 1);                 // «P(1,\ 0,\ 2):» (el punt, amb les coordenades)
            comprova(grups.Pt.tex.startsWith(Geometria.texPuntNom('P', p.r.P) + ':'), () => `${on}: P no és el punt de la recta`);
            const v = npD(p.pi, p.r.P);
            comprova(a.esZero() && m && valorXYZD(textPla(m[1]), {}).igual(v) && fr(Number(m[2])).igual(v) && !v.esZero(), () => `${on}: «${grups.Pt.tex}» no és cert`);
          }
        } else if (p.id === 'plans-distancia') {
          const [nomP, eq] = pla_('Ps').split(':');
          const [e, z] = eq.split('=');
          const amb = D => valorXYZD(e, {}) && [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]].map(([x, y, w]) => valorXYZD(e, {x: fr(x), y: fr(y), z: fr(w), D}));
          const [v0, vx, vy, vz] = amb(fr(5));
          comprova(nomP === "(pi)'" && z === '0' && v0.igual(fr(5)) && igualsV([vx, vy, vz].map(x => x.resta(v0)), p.pi.n), () => `${on}: «${pla_('Ps')}» no és un pla paral·lel a π`);
        }
      } else if (fila === FILA.punt) {
        if (p.id === 'plans-paralels') {
          const [, cos] = /⇒[xyz]=-?[\d/()]+:P(\(.*\))∈\(pi\)_1$/.exec(pla_('Pp')) || [];          // «P(-1,0,0)», sense «=»
          const P = vectorPla(cos);
          comprova(npD(p.pi, P).esZero(), () => `${on}: «${pla_('Pp')}»: P no és de π₁`);
          punt = P;
          d = distancia(npD(p.sigma, P), S(p.sigma));
        } else if (p.id === 'punts-recta') {
          const cs = partsPerComes(/^\((.*)\)$/.exec(pla_('Gc'))[1]);
          comprova(grups.Gp.tex === 'P_{\\lambda}' && !grups.Gq && [-1, 0, 2].every(t => cs.every((e, j) => valorXYZD(e, {t: fr(t)}).igual(p.r.P[j].suma(p.r.u[j].producte(t))))),
            () => `${on}: «${pla_('Gc')}» no és el punt genèric`);
        } else if (p.id === 'punt-recta') {
          comprova(pla_('Pq') === textPla(`${Geometria.texPuntNom('Q', p.r.P)} \\in r,\\quad \\vec{u} = ${Geometria.texPunt(p.r.u)}`), () => `${on}: «${pla_('Pq')}»`);
          // El vector, directament amb el seu valor (David: res de «P − Q»).
          comprova(/^«QP»=\(/.test(pla_('Pv')) && igualsV(vectorPla(pla_('Pv').split('=')[1]), p.P.map((x, j) => x.resta(p.r.P[j]))), () => `${on}: «${pla_('Pv')}» no és el vector QP`);
        }
      } else if (fila === FILA.producte) {
        comprovaFilaProducte(tex, grups, p.P.map((x, j) => x.resta(p.r.P[j])), p.r.u, '\\overrightarrow{QP} \\times \\vec{u}', on);
      } else if (fila === FILA.valor) {
        comprovaFilaValorProducte(grups, p.P.map((x, j) => x.resta(p.r.P[j])), p.r.u, '\\overrightarrow{QP} \\times \\vec{u}', on, tex);
      } else if (fila === FILA.formula) {
        const noms = {'punt-pla': 'd(P, \\pi)', 'punt-pla-arrel': 'd(P, \\pi)', 'plans-paralels': 'd(\\pi_1, \\pi_2) = d(P, \\pi_2)', 'plans-secants': 'd(\\pi_1, \\pi_2)',
          'recta-paralela': 'd(r, \\pi) = d(P, \\pi)', 'recta-secant': 'd(r, \\pi)', 'plans-distancia': "d(\\pi, \\pi')", 'punts-recta': 'd(P_{\\lambda}, \\pi)', 'punt-recta': 'd(P, r)'};
        comprova(grups.Fl.tex === noms[p.id], () => `${on}: «${grups.Fl.tex}» no és el que es calcula`);
        if (p.id === 'plans-distancia') {
          const Dvals = [-5, 0, 4].map(x => fr(x));
          const esperat = D => distancia(D.resta(p.pi.D), S(p.pi));
          if (grups.Fs) comprova(Dvals.every(D => radicalIgual(radicalAmb(pla_('Fs'), 'D', D), esperat(D))) && M.llegeixNombre(pla_('Fd')).igual(p.d), () => `${on}: «${pla_('Fs')} = ${pla_('Fd')}» no és la distància entre π i π'`);
          if (grups.Fa) {
            const [e, v] = pla_('Fa').split('=');
            comprova(Dvals.every(D => radicalIgual(radicalAmb(e, 'D', D), radical(D.resta(p.pi.D).abs()))) && radicalQuadrat(valorRadical(v)).igual(d2.producte(S(p.pi))), () => `${on}: «${pla_('Fa')}» no és equivalent`);
          }
          return;
        }
        if (p.id === 'punts-recta') {
          const lvals = [-2, 0, 1, 3].map(x => fr(x));
          const esperat = l => distancia(npD(p.pi, p.r.P.map((x, j) => x.suma(p.r.u[j].producte(l)))), S(p.pi));
          comprova(lvals.every(l => radicalIgual(radicalAmb(pla_('Fs'), 'λ', l), esperat(l))) && M.llegeixNombre(pla_('Fd')).igual(p.d), () => `${on}: «${pla_('Fs')}» no és la distància de P_λ al pla`);
          return;
        }
        // Les altres: cada tros val la distància.
        if (grups.Fg) {
          const formula = p.id === 'punt-recta' ? '\\dfrac{\\left|\\overrightarrow{QP} \\times \\vec{u}\\right|}{\\left|\\vec{u}\\right|}' : '\\dfrac{\\left|Ax_0 + By_0 + Cz_0 + D\\right|}{\\sqrt{A^2 + B^2 + C^2}}';
          comprova(grups.Fg.tex === formula, () => `${on}: la fórmula no és la de la distància`);
        }
        if (grups.Fs && p.id !== 'punt-recta') {
          // La substitució: el pla al punt, i el mòdul del vector normal.
          const m = /^\\dfrac\{\\left\|(.*)\\right\|\}\{(.*)\}$/.exec(grups.Fs.tex);
          const e = textPla(m[1]);
          comprova(substitucioCorrecta(e, pla.n, punt, pla.D) && m[2] === Geometria.texModul(pla.n), () => `${on}: «${pla_('Fs')}» no és el pla al punt, sobre el mòdul de n`);
        }
        if (grups.Fs && p.id === 'punt-recta') {
          const w = creuV(p.P.map((x, j) => x.resta(p.r.P[j])), p.r.u);
          comprova(grups.Fs.tex === `\\dfrac{${Geometria.texModul(w)}}{${Geometria.texModul(p.r.u)}}`, () => `${on}: els mòduls no són els de QP × u i u`);
        }
        if (grups.Fa && p.id !== 'punt-recta') {
          const m = /^\\dfrac\{\\left\|(-?\d+)\\right\|\}\{\\sqrt\{(\d+)\}\}$/.exec(grups.Fa.tex);
          comprova(m && fr(Number(m[1])).igual(npD(pla, punt)) && fr(Number(m[2])).igual(S(pla)), () => `${on}: «${grups.Fa.tex}» no és |N| / √S`);
        }
        for (const k of ['Fs', 'Fa', 'Fb', 'Fr'].filter(c => grups[c])) {
          comprova(radicalIgual(valorRadical(pla_(k)), d), () => `${on}: «${pla_(k)}» no val la distància (${d.q.num}/${d.q.den}·√${d.r.num})`);
        }
        if (grups.Fr) comprova(radicalSimplificat(pla_('Fr')), () => `${on}: «${pla_('Fr')}» no està simplificat`);
      } else if (fila === FILA.solucions) {
        const Ss = ['S0', 'S1'].filter(k => grups[k]).map(pla_);
        comprova(Ss.length === 2, () => `${on}: no hi ha les dues solucions`);
        const vals = Ss.map(l => {
          const [eq, ...resta] = l.split('⇒');
          const [e, v] = eq.split('=');
          if (p.id === 'plans-distancia') {
            const [dD, nomP, pl] = resta[0].split(':');
            const D = M.llegeixNombre(dD.split('=')[1]);
            const [ep, z] = pl.split('=');
            comprova(dD.startsWith('D=') && radicalIgual(radicalAmb(e, 'D', D), valorRadical(v)) && z === '0' && igualsV(coeficientsAfins(ep), p.pi.n.concat([D]))
              && D.resta(p.pi.D).producte(D.resta(p.pi.D)).igual(d2.producte(S(p.pi))) && /^\(pi\)'_[12]$/.test(nomP), () => `${on}: «${l}» no és un pla a distància d`);
            return D;
          }
          const l0 = M.llegeixNombre(resta[0].split('=')[1]);
          const pn = puntAmbNom(resta[1]);          // «P_1(1,2,2)», sense «=» (David)
          comprova(pn && /^P_[12]$/.test(pn.nom) && pn.resta === '', () => `${on}: «${resta[1]}» no és un punt amb nom`);
          const P = vectorPla(pn.cos);
          const N = npD(p.pi, P);
          comprova(radicalIgual(radicalAmb(e, 'λ', l0), valorRadical(v)) && igualsV(P, p.r.P.map((x, j) => x.suma(p.r.u[j].producte(l0))))
            && N.producte(N).igual(d2.producte(S(p.pi))), () => `${on}: «${l}» no és un punt de r a distància d`);
          return l0;
        });
        comprova(vals.length === 2 && !vals[0].igual(vals[1]), () => `${on}: les dues solucions són iguals`);
        solucions = 2;
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  const filaFinal = p.id === 'plans-distancia' || p.id === 'punts-recta' ? FILA.solucions : FILA.formula;
  comprova(final.classes[filaFinal] === 'final', () => `${nom}: la resposta no està destacada`);
  if (p.id === 'plans-distancia' || p.id === 'punts-recta') comprova(solucions === 2, () => `${nom}: falten les solucions`);
  else comprova(grupsAmbClau(final.files[FILA.formula]).Fr, () => `${nom}: falta el resultat`);
  return linies;
}

seccio('distàncies', () => {
  let linies = 0, passos = 0;
  for (const problema of Distancies.problemes) {
    const llista = Distancies.passos({p: problema.id});
    comprovaGuio(llista, Distancies.files, problema.id);
    linies += comprovaDistancies(llista, problema, problema.id);
    passos += llista.length;
  }
  // Les arrels simplificades de geometria.js: √q = c·√m, per a moltes fraccions q.
  for (let a = 0; a <= 40; a++) for (let b = 1; b <= 12; b++) {
    const q = fr(a, b);
    const t = textPla(Geometria.texArrel(Geometria.arrelQuadrada(q)));
    comprova(radicalIgual(valorRadical(t), radical(fr(1), q)) && radicalSimplificat(t), () => `√(${a}/${b}) s'escriu «${t}»`);
  }
  // El model de les arrels.
  comprova(radicalIgual(valorRadical('((3sqrt(6))/(6))'), valorRadical('sqrt(6)/2')) && radicalIgual(valorRadical('|-9|/sqrt(36)'), radical(fr(3, 2)))
    && !radicalIgual(valorRadical('sqrt(22)/sqrt(2)'), valorRadical('sqrt(12)')), 'radicals');
  return `${Distancies.problemes.length} problemes, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 26. GEOMETRIA: PROJECCIONS I SIMÈTRICS ────────────────────────── */

/**
 * Veritat d'un guió de projeccions. Model independent: la projecció sobre un pla,
 * H = P − ((n·P + D)/|n|²)·n; sobre una recta, H = Q + (((P − Q)·u)/|u|²)·u; el simètric, 2H − P.
 * A la pissarra el punt projectat es diu Q (David), i l'esquema mostra P′ només als simètrics.
 * La funció de λ que s'iguala a 0: n·(P + λn) + D (pla) o u·((Q − P) + λu) (recta). Files: les
 * dades; la recta perpendicular o el punt genèric de la recta; el punt genèric (o PR_λ); la condició
 * (la mateixa funció de λ, i sense parèntesis); aλ = c; λ i H; P′ (cada component, 2h − p).
 */
function comprovaProjeccions(passos, p, nom) {
  const FILA = Projeccions.FILA;
  const pla = Boolean(p.pi);
  const base = pla ? p.P : p.r.P.map((x, i) => x.resta(p.P[i]));          // el punt genèric: base + λ·dir
  const dir = pla ? p.pi.n : p.r.u;
  const f = t => escalarV(dir, base.map((x, i) => x.suma(dir[i].producte(t)))).suma(pla ? p.pi.D : fr(0));
  const H = pla ? p.P.map((x, i) => x.resta(p.pi.n[i].producte(escalarV(p.pi.n, p.P).suma(p.pi.D).quocient(escalarV(p.pi.n, p.pi.n)))))
    : p.r.P.map((x, i) => x.suma(p.r.u[i].producte(escalarV(p.P.map((y, j) => y.resta(p.r.P[j])), p.r.u).quocient(escalarV(p.r.u, p.r.u)))));
  const Sim = H.map((h, i) => h.producte(2).resta(p.P[i]));
  const ts = [-2, 0, 1, 3].map(t => fr(t));
  const recta = t => /^[a-z]:\(x,y,z\)=(\(.*?\))\+λ(\(.*\))$/.exec(t);
  const esGeneric = (t, B, d) => { const cs = partsPerComes(/^\((.*)\)$/.exec(t)[1]); return cs.length === 3 && ts.every(l => cs.every((e, j) => valorXYZD(e, {t: l}).igual(B[j].suma(d[j].producte(l))))); };
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const grups = grupsAmbClau(tex);
      const pt = k => textPla(grups[k].tex);
      if (fila === FILA.dades) {
        comprova(pt('Dd0') === 'P' + textPla(Geometria.texPunt(p.P)), () => `${on}: «${pt('Dd0')}» no és P`);          // sense «=» (David)
        if (pla) {
          const [nomP, eq] = pt('Dd1').split(':');
          const [e, z] = eq.split('=');
          comprova(nomP === '(pi)' && z === '0' && igualsV(coeficientsAfins(e), p.pi.n.concat([p.pi.D])), () => `${on}: «${pt('Dd1')}» no és el pla`);
        } else {
          const m = recta(pt('Dd1'));
          comprova(m && igualsV(vectorPla(m[1]), p.r.P) && igualsV(vectorPla(m[2]), p.r.u), () => `${on}: «${pt('Dd1')}» no és la recta`);
        }
      } else if (fila === FILA.esquema) {
        comprova(tex === Geometria.esquema(`${p.id.startsWith('simetric') ? 'simetric' : 'projeccio'}-${pla ? 'pla' : 'recta'}`), () => `${on}: no és l'esquema`);
      } else if (fila === FILA.recta) {
        if (pla) {
          const m = recta(pt('Rs'));
          comprova(pt('Rs').startsWith('s:') && m && igualsV(vectorPla(m[1]), p.P) && igualsV(vectorPla(m[2]), p.pi.n), () => `${on}: «${pt('Rs')}» no és la perpendicular per P`);
        } else {
          const pn = puntAmbNom(pt('Xg'));          // «R_λ(…)», sense «=»
          comprova(pn && pn.nom === 'R_λ' && pn.resta === '' && esGeneric(pn.cos, p.r.P, p.r.u), () => `${on}: «${pt('Xg')}» no és el punt genèric de r`);
        }
      } else if (fila === FILA.generic) {
        comprova(grups.Gp.tex === (pla ? 'P_{\\lambda}' : '\\overrightarrow{PR_{\\lambda}}') && Boolean(grups.Gq) === !pla && esGeneric(pt('Gc'), base, dir), () => `${on}: «${pt('Gc')}» no és el que toca`);
      } else if (fila === FILA.substitucio || fila === FILA.desenvolupa) {
        const [esq, z] = fila === FILA.substitucio ? ['Gs', 'Gz'] : ['Gx', 'Gw'];
        comprova(pt(z) === '0' && ts.every(t => valorXYZD(pt(esq), {t}).igual(f(t))), () => `${on}: «${pt(esq)} = 0» no és la condició`);
        if (fila === FILA.substitucio) comprova(pla ? !grups.Gn : grups.Gn.tex === '\\overrightarrow{PR_{\\lambda}} \\cdot \\vec{u}', () => `${on}: l'etiqueta de la condició`);
        if (fila === FILA.desenvolupa) comprova(!/[()]/.test(pt(esq)), () => `${on}: encara hi ha parèntesis`);
      } else if (fila === FILA.equacio) {
        const d = M.llegeixNombre(pt('Gd'));
        comprova(valorXYZD(pt('Ge'), {t: fr(0)}).esZero() && ts.every(t => valorXYZD(pt('Ge'), {t}).resta(d).igual(f(t))), () => `${on}: «${pt('Ge')} = ${pt('Gd')}» no és aλ = c`);
      } else if (fila === FILA.peu) {
        const l0 = M.llegeixNombre(pt('Hl').split('=')[1]);
        const pn = puntAmbNom(pt('Hp'));          // «Q(0,1,2)», sense «=»
        const Hd = vectorPla(pn.cos);
        const B = pla ? p.P : p.r.P;
        comprova(pt('Hl').startsWith('λ=') && f(l0).esZero() && pn.nom === 'Q' && pn.resta === '' && igualsV(Hd, H) && igualsV(Hd, B.map((x, j) => x.suma(dir[j].producte(l0)))),
          () => `${on}: «${pt('Hl')} ⇒ ${pt('Hp')}» no és el peu`);
      } else if (fila === FILA.simetric) {
        // «P′(2·1 − 3, …)» i després «P′(−1, 3, −3)»: sense operar amb punts (David), coordenada a coordenada.
        const cs = partsPerComes(/^\((.*)\)$/.exec(pt('Sc'))[1]);
        const operat = cs.every(e => !/\*/.test(e));
        comprova(grups.Sl.tex === "P'" && !grups.Sf && !grups.Sq && cs.length === 3 && cs.every((e, j) => valorXYZD(e, {}).igual(Sim[j]))
          && (operat || cs.every((e, j) => e === `2*${textPla(M.texEntreParentesis(H[j]))}-${textPla(M.texEntreParentesis(p.P[j]))}`)),
        () => `${on}: P′ no és el simètric (2q − p a cada coordenada)`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  comprova(final.classes[p.id.startsWith('simetric') ? FILA.simetric : FILA.peu] === 'final' && (p.id.startsWith('simetric') ? final.files[FILA.simetric] : !final.files[FILA.simetric]),
    () => `${nom}: la resposta no és la que toca o no està destacada`);
  return linies;
}

seccio('projeccions i simètrics', () => {
  let linies = 0, passos = 0;
  for (const problema of Projeccions.problemes) {
    const llista = Projeccions.passos({p: problema.id});
    comprovaGuio(llista, Projeccions.files, problema.id);
    linies += comprovaProjeccions(llista, problema, problema.id);
    passos += llista.length;
  }
  return `${Projeccions.problemes.length} problemes, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 27. GEOMETRIA: ÀREA D'UN TRIANGLE I VOLUM D'UN TETRAEDRE ──────── */

/**
 * Veritat d'un guió d'àrees i volums. Model independent: S² = |AB × AC|²/4 (producte vectorial per
 * Laplace); V = |det(AB, AC, AD)|/6 (Laplace); el quart vèrtex: D de la recta amb
 * |det(AB, AC, AD)| = 6V. Files: les dades; l'esquema; els vectors (diferències, punt genèric);
 * el producte vectorial (les files compartides); el producte mixt (determinant, o funció de λ);
 * cada tros de la fórmula (el seu valor és l'àrea o el volum; el resultat, simplificat); les
 * solucions.
 */
function comprovaAreaVolum(passos, p, nom) {
  const FILA = AreaVolum.FILA;
  const dif = (X, Y) => Y.map((y, i) => y.resta(X[i]));
  const AB = dif(p.A, p.B), AC = dif(p.A, p.C);
  const w = creuV(AB, AC);
  const tri = p.id.startsWith('triangle');
  const area = radical(fr(1), escalarV(w, w).quocient(4));
  const det = D => detLaplace([AB, AC, dif(p.A, D)]);
  const V = p.D ? det(p.D).abs().quocient(6) : p.V;
  const Dl = t => p.r.P.map((x, i) => x.suma(p.r.u[i].producte(t)));
  const ts = [-2, 0, 1, 3].map(t => fr(t));
  const esGeneric = (t, B, d) => { const cs = partsPerComes(/^\((.*)\)$/.exec(t)[1]); return cs.length === 3 && ts.every(l => cs.every((e, j) => valorXYZD(e, {t: l}).igual(B[j].suma(d[j].producte(l))))); };
  let linies = 0, solucions = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const grups = grupsAmbClau(tex);
      const pt = k => textPla(grups[k].tex);
      if (fila === FILA.dades) {
        for (const l of Object.keys(grups).filter(k => /^Dd\d$/.test(k)).map(pt)) {
          let m;
          if ((m = puntAmbNom(l)) && /^[ABCD]$/.test(m.nom) && m.resta === '') comprova(igualsV(vectorPla(m.cos), p[m.nom]), () => `${on}: «${l}»`);          // sense «=»
          else if ((m = /^r:\(x,y,z\)=(\(.*?\))\+λ(\(.*\))$/.exec(l))) comprova(igualsV(vectorPla(m[1]), p.r.P) && igualsV(vectorPla(m[2]), p.r.u), () => `${on}: «${l}»`);
          else comprova(/^«Volum»=/.test(l) && M.llegeixNombre(l.slice(8)).igual(p.V), () => `${on}: «${l}»`);
        }
      } else if (fila === FILA.esquema) {
        comprova(tex === Geometria.esquema(tri ? 'triangle' : p.id), () => `${on}: no és l'esquema`);
      } else if (fila === FILA.dibuix) {
        // Les dues solucions del quart vèrtex, dibuixades sota la resposta (David).
        comprova(p.id === 'quart-vertex' && tex === Geometria.esquema('quart-vertex-solucions') && i === passos.length - 1, () => `${on}: no és el dibuix de les dues solucions`);
      } else if (fila === FILA.vectors) {
        for (const [k, X, Y, n] of [['Ea', p.A, p.B, 'AB'], ['Eb', p.A, p.C, 'AC'], ['Ec', p.A, p.D, 'AD']]) {
          if (!grups[k]) continue;
          if (k === 'Ec' && p.r) {
            const [n1, cos, ...mes] = pt(k).split('=');          // directament el valor (David: res de «D_λ − A»)
            comprova(n1 === '«AD_λ»' && !mes.length && esGeneric(cos, dif(p.A, p.r.P), p.r.u), () => `${on}: «${pt(k)}» no és el vector AD_λ`);
            continue;
          }
          const parts = pt(k).split('=');
          comprova(parts.length === 2 && parts[0] === `«${n}»` && igualsV(vectorPla(parts[1]), dif(X, Y)), () => `${on}: «${pt(k)}» no és ${n} (directament el valor)`);
        }
        if (grups.Ed) {
          const pn = puntAmbNom(pt('Ed'));          // «D_λ(…)», sense «=»
          comprova(pn && pn.nom === 'D_λ' && pn.resta === '' && esGeneric(pn.cos, p.r.P, p.r.u), () => `${on}: «${pt('Ed')}» no és el punt genèric de r`);
        }
      } else if (fila === FILA.producte) {
        comprovaFilaProducte(tex, grups, AB, AC, '\\overrightarrow{AB} \\times \\overrightarrow{AC}', on);
      } else if (fila === FILA.valor) {
        comprovaFilaValorProducte(grups, AB, AC, '\\overrightarrow{AB} \\times \\overrightarrow{AC}', on, tex);
      } else if (fila === FILA.mixt) {
        if (p.id === 'tetraedre') {
          const B = cossosVmatrix(grups.Md.tex)[0].map(f => f.map(c => M.llegeixNombre(c)));
          const D3 = det(p.D);
          comprova(grups.Mn.tex === '\\det(\\overrightarrow{AB}, \\overrightarrow{AC}, \\overrightarrow{AD})' && [AB, AC, dif(p.A, p.D)].every((f, a) => igualsV(B[a], f))
            && valorXYZD(pt('Ms'), {}).igual(D3) && (!grups.Mv || M.llegeixNombre(pt('Mv')).igual(D3)), () => `${on}: el producte mixt no és cert`);
        } else {
          const f = t => det(Dl(t));
          comprova(grups.Mn.tex === '(\\overrightarrow{AB} \\times \\overrightarrow{AC}) \\cdot \\overrightarrow{AD_{\\lambda}}'
            && ['Ms', 'Mv'].filter(k => grups[k]).every(k => ts.every(t => valorXYZD(pt(k), {t}).igual(f(t)))), () => `${on}: «${pt('Ms')}» no és el producte mixt`);
          if (grups.Mv) comprova(!/[()]/.test(pt('Mv')), () => `${on}: encara hi ha parèntesis`);
        }
      } else if (fila === FILA.formula) {
        comprova(grups.Fl.tex === (tri ? '\\text{Àrea}' : '\\text{Volum}'), () => `${on}: no és «Àrea» o «Volum»`);
        if (grups.Fg) comprova(grups.Fg.tex === (tri ? '\\dfrac{1}{2}\\left|\\overrightarrow{AB} \\times \\overrightarrow{AC}\\right|'
          : '\\dfrac{1}{6}\\left|\\det(\\overrightarrow{AB}, \\overrightarrow{AC}, \\overrightarrow{AD})\\right|'), () => `${on}: la fórmula no és la que toca`);
        if (p.id === 'quart-vertex') {
          comprova(ts.every(t => radicalIgual(radicalAmb(pt('Fs'), 'λ', t), radical(det(Dl(t)).abs().quocient(6)))) && M.llegeixNombre(pt('Fd')).igual(p.V), () => `${on}: «${pt('Fs')}» no és el volum amb D_λ`);
          if (grups.Fa) {
            const [e, v] = pt('Fa').split('=');
            comprova(ts.every(t => radicalIgual(radicalAmb(e, 'λ', t), radical(det(Dl(t)).abs()))) && M.llegeixNombre(v).igual(p.V.producte(6)), () => `${on}: «${pt('Fa')}» no és 6V`);
          }
          return;
        }
        if (tri && grups.Fs) comprova(grups.Fs.tex === `\\dfrac{1}{2}${Geometria.texModul(w)}`, () => `${on}: el mòdul no és el de AB × AC`);
        const valor = tri ? area : radical(V);
        for (const k of ['Fs', 'Fa', 'Fb', 'Fr'].filter(c => grups[c])) comprova(radicalIgual(valorRadical(pt(k)), valor), () => `${on}: «${pt(k)}» no val ${tri ? "l'àrea" : 'el volum'}`);
        if (grups.Fr) comprova(radicalSimplificat(pt('Fr')), () => `${on}: «${pt('Fr')}» no està simplificat`);
      } else if (fila === FILA.solucions) {
        const Ss = ['S0', 'S1'].filter(k => grups[k]).map(pt);
        const ls = Ss.map(l => {
          const [eq, dl, dd] = l.split('⇒');
          const [e, v] = eq.split('=');
          const l0 = M.llegeixNombre(dl.split('=')[1]);
          const pn = puntAmbNom(dd);          // «D_1(3,3,1)», sense «=»
          comprova(pn && /^D_[12]$/.test(pn.nom) && pn.resta === '', () => `${on}: «${dd}» no és un punt amb nom`);
          const D = vectorPla(pn.cos);
          comprova(radicalIgual(radicalAmb(e, 'λ', l0), valorRadical(v)) && igualsV(D, Dl(l0)) && det(D).abs().igual(p.V.producte(6)), () => `${on}: «${l}» no és un quart vèrtex amb volum V`);
          return l0;
        });
        comprova(ls.length === 2 && !ls[0].igual(ls[1]), () => `${on}: no hi ha dues solucions diferents`);
        solucions = 2;
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  comprova(final.classes[p.id === 'quart-vertex' ? FILA.solucions : FILA.formula] === 'final', () => `${nom}: la resposta no està destacada`);
  if (p.id === 'quart-vertex') comprova(solucions === 2, () => `${nom}: falten les solucions`);
  else comprova(grupsAmbClau(final.files[FILA.formula]).Fr, () => `${nom}: falta el resultat`);
  return linies;
}

seccio('àrea i volum', () => {
  let linies = 0, passos = 0;
  for (const problema of AreaVolum.problemes) {
    const llista = AreaVolum.passos({p: problema.id});
    comprovaGuio(llista, AreaVolum.files, problema.id);
    linies += comprovaAreaVolum(llista, problema, problema.id);
    passos += llista.length;
  }
  return `${AreaVolum.problemes.length} problemes, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 28. GEOMETRIA: PERPENDICULAR COMUNA I DISTÀNCIA ENTRE RECTES ──── */

/**
 * Veritat d'un guió de la perpendicular comuna. Model independent: d² = det(PQ, u, v)² / |u × v|²
 * (Laplace); es tallen si det = 0. Files: les dades; l'esquema; els punts genèrics; el vector
 * Q_μ − P_λ (funció de λ i μ); les condicions (· u i · v) i el sistema (la mateixa funció);
 * la reducció (cada línia és certa per a la solució); els peus (de la seva recta, i P₀Q₀ perpendicular
 * a u i a v); la distància (cada tros val d) o «P₀ = Q₀ ⇒ d = 0»; el producte vectorial (si es
 * tallen); la perpendicular comuna (per P₀, amb una direcció perpendicular a u i a v).
 */
function comprovaPerpendicularComuna(passos, v, nom) {
  const FILA = PerpendicularComuna.FILA;
  const llegeix = t => Matrius.nombres(Matrius.llegeixMatriu(t, 2, 3, 99).A);
  const [P, u] = llegeix(v.r), [Q, w] = llegeix(v.s);
  const PQ = Q.map((x, i) => x.resta(P[i]));
  const uv = creuV(u, w);
  const D3 = detLaplace([PQ, u, w]);
  const tallen = D3.esZero();
  const d = radical(fr(1), D3.producte(D3).quocient(escalarV(uv, uv)));
  const vec = (l, m) => PQ.map((x, i) => x.resta(u[i].producte(l)).suma(w[i].producte(m)));   // Q_μ − P_λ
  const parells = [[0, 0], [1, 0], [0, 1], [2, -3], [-1, 2]].map(([a, b]) => [fr(a), fr(b)]);
  let sistema = null, sol = {}, P0 = null, Q0 = null;
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const grups = grupsAmbClau(tex);
      const pt = k => textPla(grups[k].tex);
      if (fila === FILA.dades) {
        for (const [k, R0, dd, l] of [['Dr', P, u, 'λ'], ['Ds', Q, w, 'μ']]) {
          const m = new RegExp(`^${k[1]}:\\(x,y,z\\)=(\\(.*?\\))\\+${l}(\\(.*\\))$`).exec(pt(k));
          comprova(m && igualsV(vectorPla(m[1]), R0) && igualsV(vectorPla(m[2]), dd), () => `${on}: «${pt(k)}» no és la recta de les dades`);
        }
      } else if (fila === FILA.esquema) {
        comprova(tex === Geometria.esquema('perpendicular-comuna'), () => `${on}: no és l'esquema`);
      } else if (fila === FILA.generics) {
        for (const [k, R0, dd, nomP, l, rr, kv] of [['Ga', P, u, 'P_λ', 't', 'r', 'Gu'], ['Gb', Q, w, 'Q_μ', 's', 's', 'Gw']]) {
          // «P_λ(…) ∈ r», sense «=» (David), i el vector director amb nom.
          const pn = puntAmbNom(pt(k));
          comprova(pn && pn.nom === nomP && pn.resta === `∈${rr}`, () => `${on}: «${pt(k)}» no és el punt genèric`);
          comprova(grups[kv] && pt(kv) === `«${kv === 'Gu' ? 'u' : 'v'}»=(${dd.map(x => textPla(M.texNombre(x))).join(',')})`, () => `${on}: falta el vector director`);
          const cs = partsPerComes(pn.cos.slice(1, -1));
          comprova(cs.length === 3 && [-1, 0, 2].every(x => cs.every((e, j) => valorXYZD(e, {[l]: fr(x)}).igual(R0[j].suma(dd[j].producte(x))))), () => `${on}: «${pt(k)}» no és el punt genèric`);
        }
      } else if (fila === FILA.vector) {
        const parts = pt('Gv').split('=');          // directament el valor (David: res de «Q_μ − P_λ»)
        const cs = partsPerComes(parts[1].slice(1, -1));
        comprova(parts.length === 2 && parts[0] === '«P_λQ_μ»' && parells.every(([l, m]) => cs.every((e, j) => valorXYZD(e, {t: l, s: m}).igual(vec(l, m)[j]))),
          () => `${on}: «${pt('Gv')}» no és Q_μ − P_λ`);
      } else if (fila === FILA.condicions) {
        if (grups.Ca) {
          for (const [k, dd, n2] of [['Ca', u, 'u'], ['Cb', w, 'v']]) {
            const [esq, e, z] = pt(k).split('=');
            comprova(esq === `«P_λQ_μ»*«${n2}»` && z === '0' && parells.every(([l, m]) => valorXYZD(e, {t: l, s: m}).igual(escalarV(vec(l, m), dd))), () => `${on}: «${pt(k)}» no és la condició`);
          }
        } else {
          sistema = [['E1', u], ['E2', w]].map(([k, dd]) => {
            const [e, c] = pt(k).split('=');
            const f = (l, m) => valorXYZD(`(${e})-(${c})`, {t: l, s: m});
            comprova(parells.every(([l, m]) => f(l, m).igual(escalarV(vec(l, m), dd))), () => `${on}: «${pt(k)}» no és la condició agrupada`);
            const c0 = f(fr(0), fr(0));
            return [f(fr(1), fr(0)).resta(c0), f(fr(0), fr(1)).resta(c0), c0.oposada()];
          });
        }
      } else if (fila === FILA.reduccio) {
        // El sistema 2×2 pel mètode de reducció (mai Cramer): totes les línies són certes per a la solució.
        const [l0, m0] = comprovaReduccio(grups, sistema, ['λ', 'μ'], on, tex);
        sol = {l: l0, m: m0};
      } else if (fila === FILA.peus) {
        // «λ = −2 ⇒ P_0(1, 2, 0)», sense «=» al punt (David).
        const [la, pa] = pt('Pa').split('⇒'), [mb, pb] = pt('Pb').split('⇒');
        const nA = puntAmbNom(pa), nB = puntAmbNom(pb);
        P0 = vectorPla(nA.cos); Q0 = vectorPla(nB.cos);
        const dif = Q0.map((x, j) => x.resta(P0[j]));
        comprova(nA.nom === 'P_0' && nB.nom === 'Q_0' && la === `λ=${textPla(M.texNombre(sol.l))}` && mb === `μ=${textPla(M.texNombre(sol.m))}`
          && igualsV(P0, P.map((x, j) => x.suma(u[j].producte(sol.l)))) && igualsV(Q0, Q.map((x, j) => x.suma(w[j].producte(sol.m))))
          && escalarV(dif, u).esZero() && escalarV(dif, w).esZero(), () => `${on}: «${pt('Pa')}», «${pt('Pb')}» no són els peus`);
      } else if (fila === FILA.distancia) {
        if (tallen) {
          comprova(grups.Mn.tex === 'P_0 = Q_0\\ \\Rightarrow\\ d(r, s) = 0' && igualsV(P0, Q0), () => `${on}: no és «d = 0»`);
        } else {
          const dif = Q0.map((x, j) => x.resta(P0[j]));
          comprova(grups.Mn.tex === 'd(r, s)' && grups.Mf.tex === '\\left|\\overrightarrow{P_0Q_0}\\right|' && igualsV(vectorPla(pt('Mv').slice(1, -1)), dif)
            && grups.Ms.tex === Geometria.texModul(dif), () => `${on}: la distància no és |P₀Q₀|`);
          for (const k of ['Ms', 'Ma', 'Mr'].filter(c => grups[c])) comprova(radicalIgual(valorRadical(pt(k)), d), () => `${on}: «${pt(k)}» no val la distància`);
          const ultim = grups.Mr ? 'Mr' : 'Ma';
          comprova(radicalSimplificat(pt(ultim)), () => `${on}: el resultat no està simplificat`);
        }
      } else if (fila === FILA.producte) {
        comprovaFilaProducte(tex, grups, u, w, '\\vec{u} \\times \\vec{v}', on);
      } else if (fila === FILA.valor) {
        comprovaFilaValorProducte(grups, u, w, '\\vec{u} \\times \\vec{v}', on, tex);
      } else if (fila === FILA.perpendicular) {
        const m = /^p:\(x,y,z\)=(\(.*?\))\+t(\(.*\))$/.exec(pt('Rp'));
        const A0 = vectorPla(m[1]), dir = vectorPla(m[2]);
        comprova(igualsV(A0, P0) && dir.some(x => !x.esZero()) && escalarV(dir, u).esZero() && escalarV(dir, w).esZero(), () => `${on}: «${pt('Rp')}» no és la perpendicular comuna`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  comprova(final.classes[FILA.distancia] === 'final' && final.classes[FILA.perpendicular] === 'final', () => `${nom}: la resposta no està destacada`);
  return {linies, tallen};
}

seccio('perpendicular comuna', () => {
  const L = p => PerpendicularComuna.llegeixAdreca(p);
  comprova(L({}).valors.r === '3,0,0;1,-1,0', 'PerpendicularComuna.llegeixAdreca');
  for (const [p, patro] of [[{r: '1,2,0;1,-1,2', s: '0,1,1;-2,2,-4'}, /paral·leles/], [{r: '1,1,1;0,0,0', s: '1,1,1;1,0,0'}, /\(0, 0, 0\)/], [{r: '1,1,1;1,0,0'}, /hi han de ser/]]) {
    comprova(patro.test(L(p).error || ''), () => `PerpendicularComuna.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  }
  const casos = PerpendicularComuna.exemples.map(v => Object.assign({}, v));
  const atzar = aleatori(2039);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  const vec = () => [enter(-3, 3), enter(-3, 3), enter(-3, 3)];
  for (let i = 0; i < 700; i++) {
    const P = vec(), u = vec(), w = vec();
    let Q = vec();
    if (i % 3 === 0) { const X = vec(), l = enter(-2, 2), m = enter(-2, 2); P.splice(0, 3, ...X.map((x, j) => x - l * u[j])); Q = X.map((x, j) => x - m * w[j]); }
    casos.push({r: `${P.join(',')};${u.join(',')}`, s: `${Q.join(',')};${w.join(',')}`});
  }
  let valids = 0, linies = 0, passos = 0;
  const comptes = {tallen: 0, creuen: 0};
  for (const p of casos) {
    const r = L(p);
    if (r.error) continue;
    const v = r.valors;
    valids++;
    const nom = `r = ${v.r}, s = ${v.s}`;
    let llista;
    try {
      llista = PerpendicularComuna.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, PerpendicularComuna.files, nom);
    const res = comprovaPerpendicularComuna(llista, v, nom);
    linies += res.linies;
    comptes[res.tallen ? 'tallen' : 'creuen']++;
    passos += llista.length;
  }
  comprova(valids > 500 && comptes.tallen > 100 && comptes.creuen > 300, () => `pocs casos: ${valids}, ${JSON.stringify(comptes)}`);
  return `${valids} casos (${JSON.stringify(comptes)}), ${passos} passos, ${linies} línies comprovades`;
});


/* ── 30. INTEGRALS: PRIMITIVA AMB UNA CONDICIÓ ─────────────────────── */

/** Valor exacte d'un text pla amb les variables donades ({x: Fraccio, C: Fraccio, …}). */
const valorAmb = (text, vars) => exacte(M.llegeix(text, {variables: Object.keys(vars)}), {variables: vars, funcions: {}});
const PUNTS_X = [-3, -1, 0, 1, 2, 5].map(x => fr(x));
/** El text pla d'una fila que porta una integral: sense «∫», «dx» ni límits (els límits es tornen a part). */
function senseIntegral(tex) {
  let limits = null;
  const t = tex.replace(/\\htmlData\{k=([A-Za-z0-9]*)I\}\{\\displaystyle\\int\}(?:_\{\\htmlData\{k=\w+\}\{([^}]*)\}\}\^\{\\htmlData\{k=\w+\}\{([^}]*)\}\})?/, (tot, P, a, b) => {
    if (a !== undefined) limits = [a, b];
    return '';
  }).replace(/\\,\\htmlData\{k=\w*D\}\{dx\}/, '');
  return {text: textPla(t), limits};
}

/**
 * Veritat d'un guió de primitiva amb una condició. Model: Fm = ∫ f (Mates.integraTermes no es fa
 * servir: es compara per derivació, F'(x) = f(x), amb diferències exactes) i C = y₀ − Fm(x₀).
 * Cada fila: f; F(x) = la integral de f (l'integrand és f), la regla i la primitiva (polinomis
 * en x i C iguals a Fm + C); la condició (cada versió val Fm(x₀) + C, i és igual a y₀); C aïllada
 * (cada part val C₀); la resposta (és Fm + C₀) i la comprovació (cada versió val y₀).
 */
function comprovaPrimitiva(passos, v, nom) {
  const FILA = Primitiva.FILA;
  const f = Dd.termesDe(v);
  const fx = x => M.valorTermes(f, x);
  // La primitiva del model, Fm(x) = Σ c·x^(n+1)/(n+1), comprovada per la derivada (diferència central exacta per a grau ≤ 4).
  const Fm = x => f.reduce((s, t) => s.suma(M.Fraccio.de(t.c).producte(x.potencia(t.n + 1)).quocient(t.n + 1)), fr(0));
  for (const x of PUNTS_X) {
    const derivada = Fm(x.suma(2)).oposada().suma(Fm(x.suma(1)).producte(8)).resta(Fm(x.resta(1)).producte(8)).suma(Fm(x.resta(2))).quocient(12);
    comprova(derivada.igual(fx(x)), () => `${nom}: el model no és una primitiva`);
  }
  const x0 = fr(v.x0), y0 = fr(v.y0), C0 = y0.resta(Fm(x0));
  const Cs = [fr(0), fr(1), fr(-7, 2)];
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      if (fila === FILA.funcio) {
        const [esq, dre] = textPla(tex).split('=');
        comprova(esq === 'f(x)' && PUNTS_X.every(x => valorAmb(dre, {x}).igual(fx(x))), () => `${on}: «${textPla(tex)}» no és f`);
      } else if (fila === FILA.primitiva) {
        const {text} = senseIntegral(tex);
        const [esq, dre] = text.split('=');
        comprova(esq === 'F(x)', () => `${on}: no és F(x)`);
        if (tex.includes('\\int')) comprova(PUNTS_X.every(x => valorAmb(dre, {x}).igual(fx(x))), () => `${on}: l'integrand no és f`);
        else comprova(dre.endsWith('+C') && PUNTS_X.every(x => Cs.every(C => valorAmb(dre, {x, C}).igual(Fm(x).suma(C)))), () => `${on}: «${dre}» no és ∫ f + C`);
      } else if (fila === FILA.condicio) {
        const pla = textPla(tex);
        if (/^F\(/.test(pla)) {
          comprova(pla === `F(${textPla(M.texNombre(x0))})=${textPla(M.texNombre(y0))}`, () => `${on}: «${pla}» no és la condició`);
        } else if (pla.startsWith('C=')) {
          const parts = pla.split('=').slice(1);
          comprova(parts.every(p => valorAmb(p, {}).igual(C0)) && parts.length >= 1, () => `${on}: «${pla}»: C no és ${C0.num}/${C0.den}`);
          comprova(parts.length === 1 || valorAmb(parts[0], {}).igual(C0), () => `${on}: «${pla}»`);
        } else {
          const [esq, dre] = pla.split('=');
          comprova(esq.endsWith('+C') && Cs.every(C => valorAmb(esq, {C}).igual(Fm(x0).suma(C))) && valorAmb(dre, {}).igual(y0), () => `${on}: «${pla}» no és F(x₀) = y₀`);
        }
      } else if (fila === FILA.resposta) {
        const [esq, dre] = textPla(tex).split('=');
        comprova(esq === 'F(x)' && PUNTS_X.every(x => valorAmb(dre, {x}).igual(Fm(x).suma(C0))), () => `${on}: la resposta no és ∫ f + C₀`);
      } else if (fila === FILA.comprovacio) {
        const [esq, dre] = textPla(tex).split('=');
        comprova(esq === `F(${textPla(M.texNombre(x0))})` && valorAmb(dre, {}).igual(y0), () => `${on}: «${textPla(tex)}» no val y₀`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  comprova(passos[passos.length - 1].classes[FILA.resposta] === 'final', () => `${nom}: la resposta no està destacada`);
  return linies;
}

seccio('primitiva amb una condició', () => {
  const L = p => Primitiva.llegeixAdreca(p);
  const d = (a3, a2, a1, a0, x0, y0) => ({a3, a2, a1, a0, x0, y0});
  for (const [p, esperat] of [[{}, d(0, 6, -4, 1, 1, 3)], [{f: 'x^3-x', x0: '-2', y0: '7'}, d(1, 0, -1, 0, -2, 7)]]) {
    comprova(iguals(L(p).valors, esperat), () => `Primitiva.llegeixAdreca(${JSON.stringify(p)}) → ${JSON.stringify(L(p))}`);
  }
  for (const [p, patro] of [[{x0: '6'}, /entre −5 i 5/], [{y0: '21'}, /entre −20 i 20/], [{x0: '1/2'}, /no és un nombre enter/], [{f: 'x^4'}, /grau 4/], [{f: '7'}, /dependre de x/], [{f: '(x'}, /^No entenc/]]) {
    comprova(patro.test(L(p).error || ''), () => `Primitiva.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  }
  const casos = Primitiva.exemples.slice();
  const atzar = aleatori(2040);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  for (let i = 0; i < 1500; i++) casos.push(d(enter(-3, 3), enter(-9, 9), enter(-9, 9), enter(-9, 9), enter(-5, 5), enter(-20, 20)));
  let valids = 0, linies = 0, passos = 0;
  for (const v of casos) {
    if (Primitiva.valida(v)) continue;
    valids++;
    const nom = `f = ${Dd.textFuncio(v)}, F(${v.x0}) = ${v.y0}`;
    comprova(iguals(L(Primitiva.escriuAdreca(v)).valors, v), () => `${nom}: anada i tornada de l'adreça`);
    const llista = Primitiva.passos(v);
    comprovaGuio(llista, Primitiva.files, nom);
    linies += comprovaPrimitiva(llista, v, nom);
    passos += llista.length;
  }
  return `${valids} casos, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 31. INTEGRALS: REGLA DE BARROW ────────────────────────────────── */

/** Una primitiva de f (termes), comprovada per la derivada (diferència central exacta per a grau ≤ 4). */
function primitivaModel(f, nom) {
  const Fm = x => f.reduce((s, t) => s.suma(M.Fraccio.de(t.c).producte(x.potencia(t.n + 1)).quocient(t.n + 1)), fr(0));
  for (const x of PUNTS_X) {
    const derivada = Fm(x.suma(2)).oposada().suma(Fm(x.suma(1)).producte(8)).resta(Fm(x.resta(1)).producte(8)).suma(Fm(x.resta(2))).quocient(12);
    comprova(derivada.igual(M.valorTermes(f, x)), () => `${nom}: el model no és una primitiva`);
  }
  return Fm;
}

/**
 * Veritat d'un guió de Barrow. Model: I = Fm(b) − Fm(a), amb Fm una primitiva (per derivació).
 * Files: la integral (integrand f, límits a i b; «F(b) − F(a)» literal; cada nombre de la cadena val
 * I, la diferència escrita amb els valors de F); F(x) (la integral de f, la regla i la primitiva, igual
 * a Fm); F(b) i F(a) (cada versió val Fm(b) o Fm(a)).
 */
function comprovaBarrow(passos, v, nom) {
  const FILA = Barrow.FILA;
  const f = Dd.termesDe(v);
  const Fm = primitivaModel(f, nom);
  const [a, b] = [fr(v.a), fr(v.b)];
  const I = Fm(b).resta(Fm(a));
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      if (fila === FILA.integral) {
        const {text, limits} = senseIntegral(tex);
        const [integrand, ...resta] = text.split('=');
        comprova(limits && fr(Number(limits[0])).igual(a) && fr(Number(limits[1])).igual(b) && PUNTS_X.every(x => valorAmb(integrand, {x}).igual(M.valorTermes(f, x))),
          () => `${on}: «${text}» no és la integral de f entre a i b`);
        if (resta.length) comprova(resta[0] === `F(${textPla(M.texNombre(b))})-F(${textPla(M.texNombre(a))})`, () => `${on}: «${resta[0]}» no és F(b) − F(a)`);
        if (resta.length > 1) {
          comprova(resta.slice(1).every(p => valorAmb(p, {}).igual(I)), () => `${on}: «${text}»: la integral no val ${I.num}/${I.den}`);
          comprova(resta[1] === `${textPla(M.texNombre(Fm(b)))}-${textPla(M.texEntreParentesis(Fm(a)))}`, () => `${on}: «${resta[1]}» no és F(b) − F(a) amb els valors`);
        }
      } else if (fila === FILA.primitiva) {
        const {text} = senseIntegral(tex);
        const [esq, dre] = text.split('=');
        comprova(esq === 'F(x)', () => `${on}: no és F(x)`);
        if (tex.includes('\\int')) comprova(PUNTS_X.every(x => valorAmb(dre, {x}).igual(M.valorTermes(f, x))), () => `${on}: l'integrand no és f`);
        else comprova(PUNTS_X.every(x => valorAmb(dre, {x}).igual(Fm(x))), () => `${on}: «${dre}» no és una primitiva de f (amb C = 0)`);
      } else {
        const x = fila === FILA.fb ? b : a;
        const [esq, dre] = textPla(tex).split('=');
        comprova(esq === `F(${textPla(M.texNombre(x))})` && valorAmb(dre, {}).igual(Fm(x)), () => `${on}: «${textPla(tex)}» no val F(${x.num})`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  const final = passos[passos.length - 1];
  comprova(final.classes[FILA.integral] === 'final' && senseIntegral(final.files[FILA.integral]).text.split('=').length === 4, () => `${nom}: falta el resultat o no està destacat`);
  return linies;
}

seccio('regla de Barrow', () => {
  const L = p => Barrow.llegeixAdreca(p);
  const d = (a3, a2, a1, a0, a, b) => ({a3, a2, a1, a0, a, b});
  for (const [p, esperat] of [[{}, d(0, 3, -2, 0, 0, 2)], [{f: 'x^3', a: '-2', b: '1'}, d(1, 0, 0, 0, -2, 1)]]) {
    comprova(iguals(L(p).valors, esperat), () => `Barrow.llegeixAdreca(${JSON.stringify(p)}) → ${JSON.stringify(L(p))}`);
  }
  for (const [p, patro] of [[{a: '2', b: '1'}, /a < b/], [{b: '6'}, /entre −5 i 5/], [{a: '1/2'}, /no és un nombre enter/], [{f: 'x^4'}, /grau 4/], [{f: '(x'}, /^No entenc/]]) {
    comprova(patro.test(L(p).error || ''), () => `Barrow.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  }
  const casos = Barrow.exemples.slice();
  const atzar = aleatori(2041);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  for (let i = 0; i < 1500; i++) { const a = enter(-5, 4); casos.push(d(enter(-3, 3), enter(-9, 9), enter(-9, 9), enter(-9, 9), a, enter(a + 1, 5))); }
  let valids = 0, linies = 0, passos = 0, negatives = 0;
  for (const v of casos) {
    if (Barrow.valida(v)) continue;
    valids++;
    const nom = `f = ${Dd.textFuncio(v)}, [${v.a}, ${v.b}]`;
    comprova(iguals(L(Barrow.escriuAdreca(v)).valors, v), () => `${nom}: anada i tornada de l'adreça`);
    const llista = Barrow.passos(v);
    comprovaGuio(llista, Barrow.files, nom);
    linies += comprovaBarrow(llista, v, nom);
    passos += llista.length;
    if (/\{-/.test(llista[llista.length - 1].files[0].split('k=Iv')[1] || '')) negatives++;
  }
  return `${valids} casos (${negatives} negatives), ${passos} passos, ${linies} línies comprovades`;
});


/* ── 32. INTEGRALS: ÀREA ENTRE UNA CORBA I L'EIX OX ────────────────── */

/** Les arrels racionals diferents d'un polinomi (coeficients Fraccio, de grau 0 cap amunt), en ordre. */
const arrelsOrdenades = p => [...new Map((arrelsX(p) || []).map(r => [`${r.num}/${r.den}`, r])).values()].sort((a, b) => a.resta(b).signe());
/** Una línia «\displaystyle\int_{l}^{r} … \,dx = F(r) - F(l) = A - (B) = I» → {l, r, Fr, Fl, resta, I} (text pla). */
function llegeixBarrow(tex, integrand = 'f\\(x\\)', F = 'F') {
  const m = new RegExp(`^\\\\displaystyle\\\\int_\\{(.+?)\\}\\^\\{(.+?)\\} ${integrand}\\\\,dx = ${F}\\((.+?)\\) - ${F}\\((.+?)\\) = (.*) = (.*)$`).exec(tex);
  if (!m) throw new Error(`«${tex}» no és una integral per Barrow`);
  return {l: textPla(m[1]), r: textPla(m[2]), Fr: textPla(m[3]), Fl: textPla(m[4]), resta: textPla(m[5]), I: textPla(m[6])};
}
/** Comprova la fila d'una primitiva sense C («F(x) = ∫…», la regla i la simplificada) contra Fm, per a l'integrand «g». */
function comprovaFilaPrimitiva(tex, g, Fm, on, F = 'F') {
  const {text} = senseIntegral(tex);
  const [esq, dre] = text.split('=');
  comprova(esq === `${F}(x)`, () => `${on}: no és ${F}(x)`);
  if (tex.includes('\\int')) comprova(PUNTS_X.every(x => valorAmb(dre, {x}).igual(g(x))), () => `${on}: l'integrand no és el que toca`);
  else comprova(PUNTS_X.every(x => valorAmb(dre, {x}).igual(Fm(x))), () => `${on}: «${dre}» no és una primitiva (amb C = 0)`);
}

/**
 * Les files de Matrius.passosArrels (i Integrals.passosTalls) per a un polinomi de coeficients
 * «coefs» (grau ≤ 3) en X: «equacio» i les «lliures», que fan de «prova», «ruffini», «segon» o
 * «treball» segons el que hi ha escrit. Model: les arrels (arrelsX). L'equació (també la
 * factoritzada, amb «·») té les solucions de p = 0 (i la sencera és proporcional a p); abans, si
 * es dona «nomEq» (text pla, «|A|», «f(x)»), hi pot haver l'equació tal com es planteja, «nomEq=0».
 * Cada prova d'arrel és certa, d'un divisor, i s'atura a la primera arrel; Ruffini, columna a
 * columna, amb l'arrel trobada; «segon» («x = r o (la resta) = 0») té totes les solucions;
 * «treball» té, sempre, les mateixes solucions que l'equació que s'hi resol (la de «segon» després
 * de la «o», o, de grau ≤ 2, la de «equacio»), i aquesta és el quocient de Ruffini. Al final, en
 * lila, totes les solucions i només nombres (mai el factor x).
 * «fase(i)»: si es dona, només es comproven aquestes files als passos i en què és certa (després,
 * la pàgina pot reaprofitar les files lliures).
 */
function comprovadorTalls({passos, FILA, X, coefs, nom, nomEq = null, fase = () => true, textPla = textPlaBase}) {
  const totes = conjunt(arrelsX(coefs) || []);
  const grau = coefs.reduce((g, c, k) => (c.esZero() ? g : k), -1);
  const proporcional = text => {
    const q = M.polinomi(M.llegeix(text, {variables: [X]}), X);
    const j = coefs.findIndex(c => !c.esZero());
    if (!q || !q[j] || q[j].esZero()) return false;
    const r = coefs[j].quocient(q[j]);
    return coefs.every((c, i) => c.igual((q[i] || fr(0)).producte(r)));
  };
  let provaArrel = null, resta = null, taulaFinal = null;
  const paper = tex => (tex.includes('{k=Pv0}') ? 'prova' : tex.startsWith('\\begin{array}{r|') ? 'ruffini' : tex.includes('{k=Wv}') ? 'segon' : 'treball');
  const restaDe = pas => {           // les solucions de l'equació que es resol a la fila de treball
    const sg = FILA.lliures.map(f => pas.files[f]).find(t => t && paper(t) === 'segon');
    if (sg) { const pla = textPla(sg); return solucionsX(pla.slice(pla.indexOf('|') + 1), X); }
    return totes;
  };
  function fila(tex, filaPissarra, i, on) {
    const pas = passos[i];
    if (!fase(i)) return false;
    const fila = filaPissarra === FILA.equacio ? 'equacio' : FILA.lliures.includes(filaPissarra) ? paper(tex) : null;
    if (fila === 'equacio') {
      const pla = textPla(tex);
      if (nomEq !== null && pla === `${nomEq}=0`) return true;           // l'equació tal com es planteja
      comprova(solucionsX(pla, X) === totes, () => `${on}: «${pla}» no té les solucions de l'equació (${totes})`);
      const pEq = /^[^=|±]*=0$/.test(pla) && !pla.includes('*(') && M.polinomi(M.llegeix(pla.split('=')[0], {variables: [X]}), X);
      if (pEq && pEq.length - 1 === grau) comprova(proporcional(pla.split('=')[0]), () => `${on}: «${pla}» no és el polinomi (per un nombre)`);
      comprova(!/(\)|[a-z])\(/.test(pla), () => `${on}: «${pla}»: el producte s'escriu amb «·»`);
    } else if (fila === 'prova') {
      const ls = tex.startsWith('\\begin{array}') ? liniesDArray(tex) : [textPla(tex)];
      const eq = textPla(pas.files[FILA.equacio]).split('=')[0];
      ls.forEach((l, q) => {
        const m = new RegExp(`^${X}=(-?\\d+):(.*)=(-?\\d+)(≠0)?$`).exec(l);
        if (!m) throw new Error(`prova «${l}» no prevista`);
        const c = fr(Number(m[1])), v_ = fr(Number(m[3]));
        comprova(valorX(m[2], X, c).igual(v_) && valorX(eq, X, c).igual(v_) && Boolean(m[4]) === !v_.esZero(), () => `${on}: «${l}» és fals`);
        const c0 = M.polinomi(M.llegeix(eq, {variables: [X]}), X)[0];
        comprova(c0.esEnter() && c0.num % Number(m[1]) === 0, () => `${on}: ${m[1]} no és un divisor del terme independent`);
        comprova(q === ls.length - 1 || !v_.esZero(), () => `${on}: després d'una arrel no cal provar-ne més`);
        if (v_.esZero()) provaArrel = c;
      });
    } else if (fila === 'ruffini') {
      const m = /^\\begin\{array\}\{r\|r+\}(.*)\\end\{array\}$/.exec(tex.trim());
      if (!m) throw new Error('taula de Ruffini no prevista');
      const [dalt, mig, baix] = m[1].replace('\\hline', '').split('\\\\').map(f => f.split('&').map(c => textPla(c.trim())));
      const nums = f => f.slice(1).map(c => (c === '' ? null : fr(Number(c))));
      const [D, Mg, B] = [nums(dalt), nums(mig), nums(baix)];
      const r = fr(Number(mig[0]));
      const eq = textPla(pas.files[FILA.equacio]);
      const q = !eq.includes('*(') && M.polinomi(M.llegeix(eq.split('=')[0], {variables: [X]}), X);
      comprova(eq.includes('*(') || (q && D.length === 4 && D.every((c, k) => c && c.igual(q[3 - k] || fr(0)))), () => `${on}: a dalt no hi ha els coeficients de l'equació`);
      comprova(provaArrel && r.igual(provaArrel), () => `${on}: l'arrel ${mig[0]} no és la que s'ha trobat`);
      B.forEach((b, k) => {
        if (b === null) return;
        comprova(k === 0 ? b.igual(D[0]) && Mg[0] === null : Mg[k] && Mg[k].igual(B[k - 1].producte(r)) && b.igual(D[k].suma(Mg[k])), () => `${on}: la columna ${k + 1} de Ruffini és falsa`);
      });
      taulaFinal = {B};
    } else if (fila === 'segon') {
      const pla = textPla(tex);
      comprova(solucionsX(pla, X) === totes, () => `${on}: «${pla}» no té totes les solucions de l'equació (${totes})`);
      if (pla.includes('|')) {
        const s = restaDe(pas);
        if (resta === null) resta = s;
        comprova(s === resta, () => `${on}: l'equació que queda ha canviat`);
      }
    } else if (fila === 'treball') {
      const pla = textPla(tex);
      const s = restaDe(pas);
      comprova(solucionsX(pla, X) === s, () => `${on}: «${pla}» no té les solucions de l'equació que s'hi resol (${s})`);
    } else return false;
    return true;
  }
  function final() {
    const files = [FILA.equacio].concat(FILA.lliures);
    const teLila = q => files.some(f => (q.files[f] || '').includes('marca=solucio'));
    const ultim = passos.filter((q, i) => fase(i) && teLila(q)).pop();
    const lila = [];
    if (ultim) for (const f of files) {
      for (const m of (ultim.files[f] || '').matchAll(/\\htmlData\{k=(\w+),marca=solucio\}\{/g)) {
        const t = textPla(grupsAmbClau(ultim.files[f])[m[1]].tex);
        const n = t.includes('=') ? t.split('=')[1] : t;
        comprova(/^-?[\d(]/.test(n), () => `${nom}: en lila hi ha «${t}», que no és una solució`);
        lila.push(M.llegeixNombre(n));
      }
    }
    comprova(conjunt(lila) === totes, () => `${nom}: les solucions en lila (${conjunt(lila)}) no són les de l'equació (${totes})`);
    // Primer, l'equació tal com es planteja (David): «|A| = 0», «f(x) = 0»…
    if (nomEq !== null) comprova(passos.some((q, i) => fase(i) && q.files[FILA.equacio] && textPla(q.files[FILA.equacio]) === `${nomEq}=0`), () => `${nom}: falta l'equació ${nomEq} = 0 tal com es planteja`);
    if (taulaFinal) {
      comprova(taulaFinal.B.every(b => b !== null) && taulaFinal.B[3].esZero(), () => `${nom}: la taula de Ruffini no acaba amb residu 0`);
      comprova(resta !== null && conjunt(arrelsX(taulaFinal.B.slice(0, 3).reverse()) || []) === resta, () => `${nom}: l'equació que queda no és el quocient`);
    }
  }
  return {fila, final};
}

/**
 * Veritat d'un guió d'àrea entre una corba i l'eix. Model: les arrels racionals de f (arrelsX), les de
 * dins de (a, b) parteixen l'interval; a cada tros el signe de f és constant (comprovat en sis punts);
 * I_k per Barrow amb una primitiva Fm; A = Σ |I_k|. Files: f; la gràfica; f(x) = 0 resolta
 * (comprovadorTalls) i el resum de talls; el signe a cada tros (un punt de dins, el valor i el
 * signe); F(x); cada integral (límits, F(r) − F(l) amb els valors, el resultat); l'àrea (cada part
 * val A; la primera, els valors absoluts de les integrals en ordre).
 */
function comprovaAreaEix(passos, v, nom) {
  const FILA = AreaEix.FILA;
  const f = Dd.termesDe(v);
  const val = x => M.valorTermes(f, x);
  const Fm = primitivaModel(f, nom);
  const [a, b] = [fr(v.a), fr(v.b)];
  const p = [v.a0, v.a1, v.a2, v.a3].map(x => fr(x));
  while (p.length > 1 && p[p.length - 1].esZero()) p.pop();
  const arrels = arrelsOrdenades(p);
  const punts = [a].concat(arrels.filter(r => r.resta(a).signe() > 0 && b.resta(r).signe() > 0), [b]);
  const trossos = punts.slice(1).map((r, k) => [punts[k], r]);
  for (const [l, r] of trossos) {
    const s = [1, 2, 3, 4, 5].map(j => val(l.suma(r.resta(l).producte(fr(j, 6)))).signe());
    comprova(s.every(x => x === s[0] && x !== 0), () => `${nom}: el model té un tros on f canvia de signe`);
  }
  const Is = trossos.map(([l, r]) => Fm(r).resta(Fm(l)));
  const A = Is.reduce((s, I) => s.suma(I.abs()), fr(0));
  const comprovador = comprovadorTalls({passos, FILA, X: 'x', coefs: p, nom, nomEq: 'f(x)'});
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const resum = (pas.files[FILA.equacio] || '').includes('k=Zf}');
      if (fila === FILA.funcio) {
        const [esq, dre] = textPla(tex).split('=');
        comprova(esq === 'f(x)' && PUNTS_X.every(x => valorAmb(dre, {x}).igual(val(x))), () => `${on}: no és f`);
      } else if (!resum && (fila === FILA.equacio || FILA.lliures.includes(fila))) {
        comprova(comprovador.fila(tex, fila, i, on), () => `${on}: fila de les arrels no prevista`);
      } else if (fila === FILA.equacio) {
        const g = grupsAmbClau(tex);
        const sols = textPla(g.Zs.tex);
        comprova(g.Zf.tex === 'f(x) = 0' && (arrels.length ? sols === arrels.map(r => `x=${textPla(M.texNombre(r))}`).join(',') : g.Zs.tex === '\\text{cap solució}'), () => `${on}: «${sols}» no són els talls`);
      } else if (fila === FILA.grafica && tex.startsWith('<svg')) {
        comprova(tex.endsWith('</svg>'), () => `${on}: no és una gràfica`);
      } else if (fila === FILA.primitiva) {
        comprovaFilaPrimitiva(tex, val, Fm, on);
      } else if (fila === FILA.integrals) {
        const g = grupsAmbClau(tex);
        Object.keys(g).filter(k => /^J\d$/.test(k)).forEach(k => {
          const n = Number(k[1]);
          const [l, r] = trossos[n];
          const B = llegeixBarrow(g[k].tex);
          comprova(valorAmb(B.l, {}).igual(l) && valorAmb(B.r, {}).igual(r) && valorAmb(B.Fr, {}).igual(r) && valorAmb(B.Fl, {}).igual(l)
            && B.resta === `${textPla(M.texNombre(Fm(r)))}-${textPla(M.texEntreParentesis(Fm(l)))}` && valorAmb(B.I, {}).igual(Is[n]), () => `${on}: la integral del tros ${n + 1} no és certa`);
        });
      } else if (fila === FILA.area) {
        const parts = textPla(tex).split('=');
        comprova(parts[0] === '«Àrea»' && parts.slice(1).every(q => radicalIgual(valorRadical(q), radical(A))), () => `${on}: «${textPla(tex)}» no val l'àrea (escrita «Àrea =»)`);
        comprova(parts[1] === Is.map(I => `|${textPla(M.texNombre(I))}|`).join('+'), () => `${on}: «${parts[1]}» no són els valors absoluts de les integrals`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  comprovador.final();
  const final = passos[passos.length - 1];
  comprova(final.classes[FILA.area] === 'final' && textPla(final.files[FILA.area]).split('=').length >= 3, () => `${nom}: falta l'àrea o no està destacada`);
  return {linies, trossos: trossos.length};
}

seccio('àrea entre una corba i l\'eix', () => {
  const L = p => AreaEix.llegeixAdreca(p);
  const d = (a3, a2, a1, a0, a, b) => ({a3, a2, a1, a0, a, b});
  comprova(iguals(L({}).valors, d(1, 0, -4, 0, -2, 2)) && iguals(L({f: 'x^2-1', a: '0', b: '3'}).valors, d(0, 1, 0, -1, 0, 3)), 'AreaEix.llegeixAdreca');
  for (const [p, patro] of [[{a: '2', b: '1'}, /a < b/], [{f: 'x^2-2'}, /no són nombres racionals/], [{f: 'x^3-2'}, /no són nombres racionals/], [{b: '6'}, /entre −5 i 5/], [{f: '(x'}, /^No entenc/]]) {
    comprova(patro.test(L(p).error || ''), () => `AreaEix.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  }
  const casos = AreaEix.exemples.slice();
  const atzar = aleatori(2042);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  for (let i = 0; i < 2500; i++) {
    // Molts amb arrels enteres: k·(x − r1)(x − r2)(x − r3) o de grau més petit.
    const grau = enter(1, 3), k = [1, -1, 2, -2][enter(0, 3)];
    let q = [fr(k)];
    for (let j = 0; j < grau; j++) q = M.producteDePolinomis(q, [fr(-enter(-3, 3)), fr(1)]);
    if (i % 4 === 0) q = [enter(-9, 9), enter(-9, 9), enter(-3, 3), enter(-1, 1)].map(x => fr(x));
    const c = [0, 1, 2, 3].map(j => (q[j] ? q[j].num : 0));
    if (c.some(x => Math.abs(x) > 9)) continue;
    const a = enter(-5, 4);
    casos.push(d(c[3], c[2], c[1], c[0], a, enter(a + 1, 5)));
  }
  let valids = 0, linies = 0, passos = 0;
  const trossos = {};
  for (const v of casos) {
    if (AreaEix.valida(v)) continue;
    valids++;
    const nom = `f = ${Dd.textFuncio(v)}, [${v.a}, ${v.b}]`;
    comprova(iguals(L(AreaEix.escriuAdreca(v)).valors, v), () => `${nom}: anada i tornada de l'adreça`);
    const llista = AreaEix.passos(v);
    comprovaGuio(llista, AreaEix.files, nom);
    const r = comprovaAreaEix(llista, v, nom);
    linies += r.linies;
    trossos[r.trossos] = (trossos[r.trossos] || 0) + 1;
    passos += llista.length;
  }
  comprova(valids > 1000 && trossos[1] && trossos[2] && trossos[3] && trossos[4], () => `pocs casos o no hi ha de tots: ${valids}, ${JSON.stringify(trossos)}`);
  return `${valids} casos (trossos: ${JSON.stringify(trossos)}), ${passos} passos, ${linies} línies comprovades`;
});


/* ── 33. INTEGRALS: ÀREA ENTRE DUES CORBES ─────────────────────────── */

/**
 * Veritat d'un guió d'àrea entre dues corbes. Model: h = f − g (coeficients restats aquí), les seves
 * arrels racionals (arrelsX; n'hi ha d'haver dues, almenys); els trossos entre talls consecutius
 * (a cada un el signe de h és constant, comprovat en cinc punts); I_k per Barrow amb una primitiva
 * de h; A = Σ |I_k|. Files: f i g; la gràfica; la diferència (les dues versions són h); h = 0
 * resolta (comprovadorTalls) i el resum de talls; el signe a cada tros; H(x); les integrals; l'àrea.
 */
function comprovaAreaCorbes(passos, v, nom) {
  const FILA = AreaCorbes.FILA;
  const f = Dd.termesAmb(v, 'a', 3), gt = Dd.termesAmb(v, 'b', 3);
  const p = [0, 1, 2, 3].map(n => fr(v['a' + n] - v['b' + n]));
  while (p.length > 1 && p[p.length - 1].esZero()) p.pop();
  const h = M.termes(p);
  const val = x => M.valorTermes(f, x).resta(M.valorTermes(gt, x));
  const Hm = primitivaModel(h, nom);
  const arrels = arrelsOrdenades(p);
  comprova(arrels.length >= 2, () => `${nom}: el model no té dos talls`);
  const trossos = arrels.slice(1).map((r, k) => [arrels[k], r]);
  for (const [l, r] of trossos) {
    const s = [1, 2, 3, 4, 5].map(j => val(l.suma(r.resta(l).producte(fr(j, 6)))).signe());
    comprova(s.every(x => x === s[0] && x !== 0), () => `${nom}: el model té un tros on f − g canvia de signe`);
  }
  const Is = trossos.map(([l, r]) => Hm(r).resta(Hm(l)));
  const A = Is.reduce((s, I) => s.suma(I.abs()), fr(0));
  const comprovador = comprovadorTalls({passos, FILA, X: 'x', coefs: p, nom, nomEq: 'f(x)-g(x)'});
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const resum = (pas.files[FILA.equacio] || '').includes('k=Zf}');
      if (fila === FILA.funcions) {
        const [lf, lg] = liniesDArray(tex);
        const [ef, df] = lf.split('='), [eg, dg] = lg.split('=');
        comprova(ef === 'f(x)' && eg === 'g(x)' && PUNTS_X.every(x => valorAmb(df, {x}).igual(M.valorTermes(f, x)) && valorAmb(dg, {x}).igual(M.valorTermes(gt, x))), () => `${on}: no són f i g`);
      } else if (fila === FILA.diferencia) {
        const [esq, dre] = textPla(tex).split('=');
        comprova(esq === 'f(x)-g(x)' && PUNTS_X.every(x => valorAmb(dre, {x}).igual(val(x))), () => `${on}: «${textPla(tex)}» no és f − g`);
      } else if (!resum && (fila === FILA.equacio || FILA.lliures.includes(fila))) {
        comprova(comprovador.fila(tex, fila, i, on), () => `${on}: fila de les arrels no prevista`);
      } else if (fila === FILA.equacio) {
        const g = grupsAmbClau(tex);
        comprova(g.Zf.tex === 'f(x) = g(x)' && textPla(g.Zs.tex) === arrels.map(r => `x=${textPla(M.texNombre(r))}`).join(','), () => `${on}: «${textPla(g.Zs.tex)}» no són els talls`);
      } else if (fila === FILA.grafica && tex.startsWith('<svg')) {
        comprova(tex.endsWith('</svg>'), () => `${on}: no és una gràfica`);
      } else if (fila === FILA.primitiva) {
        comprovaFilaPrimitiva(tex, val, Hm, on, 'H');
      } else if (fila === FILA.integrals) {
        const g = grupsAmbClau(tex);
        Object.keys(g).filter(k => /^J\d$/.test(k)).forEach(k => {
          const n = Number(k[1]);
          const [l, r] = trossos[n];
          const B = llegeixBarrow(g[k].tex, '\\(f\\(x\\) - g\\(x\\)\\)', 'H');
          comprova(valorAmb(B.l, {}).igual(l) && valorAmb(B.r, {}).igual(r) && valorAmb(B.Fr, {}).igual(r) && valorAmb(B.Fl, {}).igual(l)
            && B.resta === `${textPla(M.texNombre(Hm(r)))}-${textPla(M.texEntreParentesis(Hm(l)))}` && valorAmb(B.I, {}).igual(Is[n]), () => `${on}: la integral del tros ${n + 1} no és certa`);
        });
      } else if (fila === FILA.area) {
        const parts = textPla(tex).split('=');
        comprova(parts[0] === '«Àrea»' && parts.slice(1).every(q => radicalIgual(valorRadical(q), radical(A))), () => `${on}: «${textPla(tex)}» no val l'àrea (escrita «Àrea =»)`);
        comprova(parts[1] === Is.map(I => `|${textPla(M.texNombre(I))}|`).join('+'), () => `${on}: «${parts[1]}» no són els valors absoluts de les integrals`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  comprovador.final();
  const final = passos[passos.length - 1];
  comprova(final.classes[FILA.area] === 'final' && textPla(final.files[FILA.area]).split('=').length >= 3, () => `${nom}: falta l'àrea o no està destacada`);
  return {linies, trossos: trossos.length};
}

seccio('àrea entre dues corbes', () => {
  const L = p => AreaCorbes.llegeixAdreca(p);
  const d = (a3, a2, a1, a0, b3, b2, b1, b0) => ({a3, a2, a1, a0, b3, b2, b1, b0});
  comprova(iguals(L({}).valors, d(0, 1, 0, 0, 0, 0, 1, 2)) && iguals(L({f: 'x^3', g: 'x'}).valors, d(1, 0, 0, 0, 0, 0, 1, 0)), 'AreaCorbes.llegeixAdreca');
  for (const [p, patro] of [[{f: 'x^2', g: 'x^2+1'}, /constant/], [{f: 'x', g: 'x'}, /iguals/], [{f: 'x^2', g: '2'}, /racionals/], [{f: 'x^2', g: '2x-1'}, /dos punts/], [{g: 'x^4'}, /grau 4/], [{f: '(x'}, /^No entenc/]]) {
    comprova(patro.test(L(p).error || ''), () => `AreaCorbes.llegeixAdreca(${JSON.stringify(p)}) hauria de donar ${patro}: ${JSON.stringify(L(p))}`);
  }
  const casos = AreaCorbes.exemples.slice();
  const atzar = aleatori(2043);
  const enter = (a, b) => a + Math.floor(atzar() * (b - a + 1));
  for (let i = 0; i < 2000; i++) {
    // g a l'atzar, i f = g + k·(x − r1)(x − r2)(…): la diferència té arrels enteres.
    const grau = enter(2, 3), k = [1, -1, 2][enter(0, 2)];
    let q = [fr(k)];
    for (let j = 0; j < grau; j++) q = M.producteDePolinomis(q, [fr(-enter(-3, 3)), fr(1)]);
    const gc = [enter(-3, 3), enter(-3, 3), enter(-2, 2), enter(-1, 1)];
    const fc = [0, 1, 2, 3].map(j => gc[j] + (q[j] ? q[j].num : 0));
    if (fc.some(x => Math.abs(x) > 9)) continue;
    casos.push(d(fc[3], fc[2], fc[1], fc[0], gc[3], gc[2], gc[1], gc[0]));
  }
  let valids = 0, linies = 0, passos = 0;
  const trossos = {};
  for (const v of casos) {
    if (AreaCorbes.valida(v)) continue;
    valids++;
    const nom = `f = ${M.textPolinomi(Dd.termesAmb(v, 'a', 3))}, g = ${M.textPolinomi(Dd.termesAmb(v, 'b', 3))}`;
    comprova(iguals(L(AreaCorbes.escriuAdreca(v)).valors, v), () => `${nom}: anada i tornada de l'adreça`);
    const llista = AreaCorbes.passos(v);
    comprovaGuio(llista, AreaCorbes.files, nom);
    const r = comprovaAreaCorbes(llista, v, nom);
    linies += r.linies;
    trossos[r.trossos] = (trossos[r.trossos] || 0) + 1;
    passos += llista.length;
  }
  comprova(valids > 800 && trossos[1] && trossos[2], () => `pocs casos o no hi ha de tots: ${valids}, ${JSON.stringify(trossos)}`);
  return `${valids} casos (trossos: ${JSON.stringify(trossos)}), ${passos} passos, ${linies} línies comprovades`;
});


/* ── 34. INTEGRALS: UN PARÀMETRE A PARTIR D'UNA INTEGRAL ───────────── */

/** Els coeficients (grau ≤ 3, de grau 0 cap amunt) d'una funció polinòmica de k, interpolada i comprovada en dos punts més. */
function interpola3(fn, nom) {
  const ks = [0, 1, 2, 3].map(x => fr(x)), ys = ks.map(fn);
  const Mx = ks.map((x, i) => [0, 1, 2, 3].map(e => x.potencia(e)).concat([ys[i]]));
  for (let c = 0; c < 4; c++) {
    const f = Mx.findIndex((r, i) => i >= c && !r[c].esZero());
    [Mx[c], Mx[f]] = [Mx[f], Mx[c]];
    for (let i = 0; i < 4; i++) if (i !== c) { const q = Mx[i][c].quocient(Mx[c][c]); Mx[i] = Mx[i].map((x, j) => x.resta(Mx[c][j].producte(q))); }
  }
  const coefs = Mx.map((r, i) => r[4].quocient(r[i]));
  comprova([fr(5), fr(-7, 2)].every(k => coefs.reduce((s, c, i) => s.suma(c.producte(k.potencia(i))), fr(0)).igual(fn(k))), () => `${nom}: el model no és de grau ≤ 3 en k`);
  return coefs;
}

/**
 * Veritat d'un guió de paràmetre. Model independent: I(k) = la integral, calculada per a cada k amb
 * una primitiva comprovada per derivació (primitivaModel); el polinomi I(k) − V interpolat; les
 * solucions (arrelsX) i la resposta (la positiva si l'enunciat demana k > 0). Files: les dades
 * (literals); els talls (paràbola: les dues equacions són la mateixa i 0 i k la compleixen); la
 * primitiva (la integral és f; el resultat té f per derivada i val 0 a x = 0); Barrow (cada valor
 * és I(k)); l'equació (cada equació té les solucions del model; o la cadena acaba en la resposta);
 * la resposta.
 */
function comprovaAreaParametre(passos, p, nom) {
  const FILA = AreaParametre.FILA;
  const integrand = {limit: k => [fr(1), fr(2)], coeficient: k => [fr(0), fr(2), k], parabola: k => [fr(0), k, fr(-1)]}[p.id];
  const limits = {limit: k => [fr(0), k], coeficient: () => [fr(0), fr(3)], parabola: k => [fr(0), k]}[p.id];
  const I = k => { const Fm = primitivaModel(M.termes(integrand(k)), nom); const [l, r] = limits(k); return Fm(r).resta(Fm(l)); };
  const coefs = interpola3(k => I(k).resta(p.V), nom);
  const sols = arrelsOrdenades(coefs);
  const positiu = p.id !== 'coeficient';
  const valides = sols.filter(k => !positiu || k.signe() > 0);
  comprova(valides.length === 1, () => `${nom}: el model no té una sola solució`);
  const k0 = valides[0];
  const ks = [fr(1), fr(2), fr(3), fr(1, 2)];
  const fx = (x, k) => integrand(k).reduce((s, c, n) => s.suma(c.producte(x.potencia(n))), fr(0));
  const DADES = {limit: '\\displaystyle\\int_0^k (2x + 1)\\,dx = 6,\\quad k > 0', coeficient: '\\displaystyle\\int_0^3 (kx^2 + 2x)\\,dx = 27', parabola: 'f(x) = kx - x^2,\\quad k > 0,\\quad A = 36'};
  const senseInt = t => textPla(t.replace(/\\displaystyle\\int(_\{?\w\}?\^\{?\w\}?)?/g, '').replace(/\\,dx/g, ''));
  let linies = 0;
  passos.forEach((pas, i) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${i + 1}, fila ${fila + 1}`;
    linies++;
    try {
      const g = grupsAmbClau(tex);
      if (fila === FILA.dades) {
        comprova(g.Dd.tex === DADES[p.id], () => `${on}: les dades no són les de l'enunciat`);
      } else if (fila === FILA.grafica) {
        comprova(tex.startsWith('<svg') && p.id === 'parabola', () => `${on}: no és la gràfica`);
      } else if (fila === FILA.talls) {
        const [e1, e2, sol] = textPla(g.Tk.tex).split('⇔');
        const punts = [fr(-2), fr(1, 3), fr(4)];
        comprova(ks.every(k => punts.every(x => valorAmb(e1.split('=')[0], {x, k}).igual(fx(x, k)) && valorAmb(e2.split('=')[0], {x, k}).igual(fx(x, k))))
          && sol === 'x=0|x=k' && ks.every(k => fx(fr(0), k).esZero() && fx(k, k).esZero()), () => `${on}: els talls no són certs`);
      } else if (fila === FILA.primitiva) {
        if (p.id === 'limit') comprovaFilaPrimitiva(tex, x => fx(x, fr(0)), x => primitivaModel(M.termes(integrand(fr(0))), nom)(x), on);
        else {
          const [esq, int, prim] = senseInt(g.Fp.tex).split('=');
          comprova(esq === 'F(x)' && ks.every(k => PUNTS_X.every(x => valorAmb(int, {x, k}).igual(fx(x, k)))), () => `${on}: l'integrand no és f`);
          const Fk = (x, k) => valorAmb(prim, {x, k});
          comprova(ks.every(k => Fk(fr(0), k).esZero() && PUNTS_X.every(x => Fk(x.suma(2), k).oposada().suma(Fk(x.suma(1), k).producte(8)).resta(Fk(x.resta(1), k).producte(8)).suma(Fk(x.resta(2), k)).quocient(12).igual(fx(x, k)))),
            () => `${on}: «${prim}» no és una primitiva de f (amb C = 0)`);
        }
      } else if (fila === FILA.barrow) {
        const parts = senseInt(g.Bk.tex).split('=');
        const inici = 0;
        comprova(ks.every(k => PUNTS_X.every(x => valorAmb(parts[inici], {x, k}).igual(fx(x, k)))), () => `${on}: l'integrand no és f`);
        comprova(parts[inici + 1] === (p.id === 'coeficient' ? 'F(3)-F(0)' : 'F(k)-F(0)'), () => `${on}: «${parts[inici + 1]}» no és Barrow`);
        comprova(parts.slice(inici + 2).every(e => ks.every(k => valorAmb(e, {k}).igual(I(k)))), () => `${on}: «${parts.join('=')}» no val la integral`);
      } else if (fila === FILA.equacio) {
        const pla = textPla(tex);
        if (p.id === 'limit') {
          comprova(solucionsX(pla, 'k') === conjunt(sols), () => `${on}: «${pla}» no té les solucions de I(k) = V (${conjunt(sols)})`);
          comprova(passos.slice(0, i).some(q => q.files[FILA.equacio]) || pla === 'k^(2)+k=6',
            () => `${on}: «${pla}»: primer cal escriure k² + k = 6 (la integral val 6)`);
        } else {
          const eqs = pla.split('⇒');
          // |…| (l'àrea, valor absolut de la integral): es llegeix el de dins i se'n pren el valor absolut.
          const amb = (t, vars) => (/^\|.*\|$/.test(t) ? valorAmb(t.slice(1, -1), vars).abs() : valorAmb(t, vars));
          const [l0, r0] = eqs[0].split('=');
          comprova(ks.every(k => amb(l0, {k}).igual(p.id === 'parabola' ? I(k).abs() : I(k))) && valorAmb(r0, {}).igual(p.V), () => `${on}: «${eqs[0]}» no és I(k) = V`);
          comprova(p.id !== 'parabola' || /^\|.*\|$/.test(l0), () => `${on}: l'àrea és el valor absolut de la integral`);
          eqs.forEach(e => {
            const costats = e.split('=');
            if (costats[0] === 'k') comprova(costats.slice(1).every(c => valorAmb(c, {}).igual(k0)), () => `${on}: «${e}»: k no és ${k0.num}/${k0.den}`);
            else comprova(amb(costats[0], {k: k0}).igual(valorAmb(costats[1], {k: k0})) && (p.id === 'parabola' || !amb(costats[0], {k: k0.suma(1)}).igual(valorAmb(costats[1], {k: k0.suma(1)}))), () => `${on}: «${e}» no té la solució k = ${k0.num}`);
          });
        }
      } else if (fila === FILA.treball) {
        // Els càlculs de l'equació (que es queda a la seva fila): les mateixes solucions. Al final, les que
        // no compleixen k > 0, tatxades: totes ho són, i només elles, i només quan ja hi ha la resposta.
        comprova(p.id === 'limit' && pas.files[FILA.equacio], () => `${on}: fila de treball sense equació a sobre`);
        const tatxades = [];
        const sense = tex.replace(/\\textcolor\{#b91c1c\}\{\\cancel\{/g, '⟪').replace(/\}\}(?=\\quad\\text\{o\}|$)/g, m => m);
        let net = '', profunditat = 0, dins = null;
        for (let q = 0; q < sense.length; q++) {
          const c = sense[q];
          if (c === '⟪') { dins = ''; profunditat = 0; continue; }
          if (dins !== null) {
            if (c === '{') profunditat++;
            if (c === '}') { if (profunditat === 0) { tatxades.push(dins); net += dins; dins = null; q++; continue; } profunditat--; }
            dins += c;
          } else net += c;
        }
        comprova(solucionsX(textPla(net), 'k') === conjunt(sols), () => `${on}: «${textPla(net)}» no té les solucions de I(k) = V (${conjunt(sols)})`);
        const dolentes = sols.filter(k => k.signe() <= 0);
        if (tatxades.length) {
          comprova(conjunt(tatxades.map(t => M.llegeixNombre(textPla(t).split('=')[1]))) === conjunt(dolentes) && pas.files[FILA.resposta],
            () => `${on}: les solucions tatxades no són les que no compleixen k > 0`);
        }
        if (i === passos.length - 1) comprova(tatxades.length === dolentes.length, () => `${on}: al final, cal tatxar ${conjunt(dolentes)}`);
      } else if (fila === FILA.resposta) {
        const pla = textPla(tex);
        const m = /^(k>0⇒)?k=(.*)$/.exec(pla);
        comprova(m && valorAmb(m[2], {}).igual(k0) && Boolean(m[1]) === (p.id === 'limit'), () => `${on}: «${pla}» no és la resposta`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  comprova(passos[passos.length - 1].classes[FILA.resposta] === 'final', () => `${nom}: la resposta no està destacada`);
  return linies;
}

seccio('paràmetre a partir d\'una integral', () => {
  let linies = 0, passos = 0;
  for (const problema of AreaParametre.problemes) {
    const llista = AreaParametre.passos({p: problema.id});
    comprovaGuio(llista, AreaParametre.files, problema.id);
    linies += comprovaAreaParametre(llista, problema, problema.id);
    passos += llista.length;
  }
  return `${AreaParametre.problemes.length} problemes, ${passos} passos, ${linies} línies comprovades`;
});


/* ── 3 i 4 (bis). GUIONS I VERITAT DE LA RECTA TANGENT ─────────────── */

seccio('guions i veritat de recta-tangent', () => {
  const casos = casosRectaTangent();
  let linies = 0, passos = 0, maxim = 0;
  const modes = {};
  for (const v of casos) {
    const nom = `f = ${M.textPolinomi(M.termes([v.a0, v.a1, v.a2, v.a3]))}, ${v.mode === 'pendent' ? 'm = ' + v.m : v.mode + ' en x0 = ' + v.x0}`;
    let llista;
    try {
      llista = RT.passos(v);
    } catch (e) {
      comprova(false, () => `${nom}: passos() llança ${e.stack}`);
      continue;
    }
    comprovaGuio(llista, RT.files, nom);
    linies += comprovaVeritat(llista, v, nom);
    passos += llista.length;
    maxim = Math.max(maxim, llista.length);
    const clau = v.mode + (v.mode === 'pendent' ? rectesModel(v).length : v.mode === 'normal' && rectesModel(v)[0].vertical ? '-vertical' : '');
    modes[clau] = (modes[clau] || 0) + 1;
  }
  comprova(['tangent', 'normal', 'normal-vertical', 'pendent0', 'pendent1', 'pendent2'].every(k => modes[k] > 0), () => `falten tipus de casos: ${JSON.stringify(modes)}`);
  return `${casos.length} casos (${Object.entries(modes).map(([k, n]) => k + ' ' + n).join(', ')}), ${passos} passos (fins a ${maxim} per cas), ${linies} línies comprovades`;
});


/* ── REGLES GENERALS (totes les pàgines) ───────────────────────────── */

/*
 * Les millores que el David va demanar en un lloc valen a tot arreu (auditoria, octubre 2026). Aquí es
 * comproven a tots els passos de tots els exemples (i variants) de totes les pàgines: la pissarra, els
 * textos dels passos i l'enunciat.
 */
/* ── GRÀFICA D'UNA FUNCIÓ ──────────────────────────────────────────── */

/**
 * Model independent de cada funció de grafica-funcio.js: f, f' i f'' escrites a mà (aquí es comproven amb derivades
 * numèriques), els punts que no són del domini, els zeros, els punts crítics (amb el que són) i les inflexions (també
 * comprovats numèricament). Els límits i les asímptotes surten de f, numèricament.
 */
const MODELS_GRAFICA = (() => {
  const r3 = Math.sqrt(3);
  return {
    'cubica': {f: x => x ** 3 - 6 * x ** 2 + 9 * x, f1: x => 3 * x ** 2 - 12 * x + 9, f2: x => 6 * x - 12,
      fora: [], zeros: [0, 3], critics: [[1, 'màxim'], [3, 'mínim']], inflexions: [2]},
    'cubica-arrels': {f: x => x ** 3 - 3 * x, f1: x => 3 * x ** 2 - 3, f2: x => 6 * x,
      fora: [], zeros: [-r3, 0, r3], critics: [[-1, 'màxim'], [1, 'mínim']], inflexions: [0]},
    'quartica': {f: x => x ** 4 - 4 * x ** 3, f1: x => 4 * x ** 3 - 12 * x ** 2, f2: x => 12 * x ** 2 - 24 * x,
      fora: [], zeros: [0, 4], critics: [[0, null], [3, 'mínim']], inflexions: [0, 2]},
    'racional-obliqua': {f: x => (x * x - 2 * x) / (x - 1), f1: x => (x * x - 2 * x + 2) / (x - 1) ** 2, f2: x => -2 / (x - 1) ** 3,
      fora: [1], zeros: [0, 2], critics: [], inflexions: []},
    'racional-horitzontal': {f: x => 5 * x / (x * x + 1), f1: x => 5 * (1 - x * x) / (x * x + 1) ** 2, f2: x => 10 * x * (x * x - 3) / (x * x + 1) ** 3,
      fora: [], zeros: [0], critics: [[-1, 'mínim'], [1, 'màxim']], inflexions: [-r3, 0, r3]},
    'racional-verticals': {f: x => x * x / (x * x - 4), f1: x => -8 * x / (x * x - 4) ** 2, f2: x => 8 * (3 * x * x + 4) / (x * x - 4) ** 3,
      fora: [-2, 2], zeros: [0], critics: [[0, 'màxim']], inflexions: []},
    // Amb radicals: dom = els intervals del domini [a, b, a hi és, b hi és].
    'arrel-cubica': {f: x => Math.sqrt(1 + x ** 3), f1: x => 3 * x * x / (2 * Math.sqrt(1 + x ** 3)),
      f2: x => 3 * x * (x ** 3 + 4) / (4 * (1 + x ** 3) ** 1.5), dom: [[-1, Infinity, true, false]],
      fora: [], zeros: [-1], critics: [[0, null]], inflexions: [0]},
    'producte-arrel': {f: x => x * Math.sqrt(x + 3), f1: x => (3 * x + 6) / (2 * Math.sqrt(x + 3)), f2: x => (3 * x + 12) / (4 * (x + 3) ** 1.5),
      dom: [[-3, Infinity, true, false]], fora: [], zeros: [-3, 0], critics: [[-2, 'mínim']], inflexions: []},
    'arrel-obliques': {f: x => Math.sqrt(x * x - 4), f1: x => x / Math.sqrt(x * x - 4), f2: x => -4 / (x * x - 4) ** 1.5,
      dom: [[-Infinity, -2, false, true], [2, Infinity, true, false]], fora: [], zeros: [-2, 2], critics: [], inflexions: []},
  };
})();
const TITOLS_GRAFICA = ['1. Domini i possibles asímptotes verticals', '2. Límits en l\'infinit i possibles asímptotes horitzontals i asímptotes obliqües',
  '3. Punts de tall amb els eixos', '4. Creixement, decreixement i extrems relatius', '5. Concavitat positiva o concavitat negativa i punts d\'inflexió',
  '6. Taula de valors', '7. Gràfica de la funció'];
const TIPUS_GRAFICA = new Set(['f', 'apartat', 'domini', 'inequacio', 'equacio:Q', 'equacio:f', 'equacio:f1', 'equacio:f2', 'limits', 'asimptotes', 'valors', 'punts',
  'derivada1', 'derivada2', 'proves1', 'proves2', 'taula1', 'taula2', 'conclusio1', 'conclusio2', 'taula-valors', 'grafica']);

/** Derivada numèrica (cinc punts). */
const derivadaNum = (g, x) => { const h = 1e-4 * Math.max(1, Math.abs(x)); return (-g(x + 2 * h) + 8 * g(x + h) - 8 * g(x - h) + g(x - 2 * h)) / (12 * h); };
const quasiIgual = (a, b, tol = 1e-8) => (a === b) || Math.abs(a - b) <= tol * Math.max(1, Math.abs(a), Math.abs(b));

/**
 * Les línies lògiques d'una fila (TeX): una llista {l} dona una línia per element; una llista {rl} (f'(x) & = A \\ & = B)
 * és una sola línia; una llista dins d'una línia (Formules.enLinies) també. Torna el text pla de cada línia (textPla).
 */
function liniesLogiques(tex) {
  const t = tex.trim();
  const m = /^\\begin\{array\}\{(l|rl)\}([\s\S]*)\\end\{array\}$/.exec(t);
  if (!m) return [textPla(t.replace(/\\qquad/g, ''))];
  // Parteix pels «\\» de primer nivell (no dins d'una llista interior).
  const peces = [];
  let prof = 0, inici = 0;
  const s = m[2];
  for (let i = 0; i < s.length; i++) {
    if (s.startsWith('\\begin{array}', i)) prof++;
    else if (s.startsWith('\\end{array}', i)) prof--;
    else if (prof === 0 && s.startsWith('\\\\', i)) { peces.push(s.slice(inici, i)); i++; inici = i + 1; }
  }
  peces.push(s.slice(inici));
  const netes = peces.map(p => p.replace(/^\s*\[[^\]]*\]/, '').trim()).map(p => liniesLogiques(p).join(''));
  if (m[1] === 'rl') return [netes.join('').replace(/&/g, '')];
  // Una línia que comença per «=» continua l'anterior (una cadena partida en línies: Formules.enLinies).
  const linies = [];
  for (const l of netes.map(x => x.replace(/&/g, ''))) {
    if (l.startsWith('=') && linies.length) linies[linies.length - 1] += l; else linies.push(l);
  }
  return linies;
}

/** Una expressió en x (text pla), com a funció numèrica; f(x), f'(x) i f''(x) són les del model. */
function expressioNum(text, model) {
  const t = text.replace(/f''\(x\)/g, 'E').replace(/f'\(x\)/g, 'D').replace(/f\(x\)/g, 'F').replace(/([\w)])sqrt\(/g, '$1*sqrt(');   // «x√(x+3)»
  const arbre = M.llegeix(t, {variables: ['x', 'F', 'D', 'E']});
  return x => M.avalua(arbre, {variables: {x, F: model.f(x), D: model.f1(x), E: model.f2(x)}});
}
/** Un valor (text pla): un nombre exacte, ±∞, o «exacte≈aproximat». {v, aprox}. */
function valorNum(text) {
  const [exacte, aprox] = text.split('≈');
  if (/^\+?∞$/.test(exacte)) return {v: Infinity, aprox};
  if (exacte === '-∞') return {v: -Infinity, aprox};
  return {v: M.avalua(M.llegeix(exacte), {}), aprox};
}
const decimal2 = x => { const s = (Math.round(Math.abs(x) * 100) / 100).toFixed(2).replace('.', ','); return (x < 0 && s !== '0,00' ? '-' : '') + s; };

/** Els zeros d'una funció a [a, b] (numèrics): canvis de signe (no pols) i zeros exactes de la graella. */
function zerosNum(g, [a, b]) {
  const n = 20480, h = (b - a) / n, zeros = [];
  const afegeix = z => { if (!zeros.some(w => Math.abs(w - z) < 1e-6)) zeros.push(z); };
  let xa = a, ya = g(a);
  for (let i = 1; i <= n; i++) {
    const x = a + i * h, y = g(x);
    if (Number.isFinite(y) && Math.abs(y) < 1e-12) afegeix(x);
    if (Number.isFinite(ya) && Number.isFinite(y) && ya * y < 0) {
      let [l, r, yl] = [xa, x, ya];
      for (let k = 0; k < 60; k++) { const mm = (l + r) / 2, ym = g(mm); if (yl * ym <= 0) r = mm; else { l = mm; yl = ym; } }
      const z = (l + r) / 2;
      if (Math.abs(g(z)) < 1e-6 * Math.max(1, Math.abs(ya), Math.abs(y))) afegeix(z);   // no és un pol
    }
    [xa, ya] = [x, y];
  }
  return zeros.sort((p, q) => p - q);
}
const mateixosValors = (A, B) => A.length === B.length && A.every((a, i) => Math.abs(a - B[i]) < 1e-6);

/** Límit numèric de g en un punt: {a, costat} (lateral) o {inf: ±1}. Torna ±Infinity, un nombre o NaN. */
function limitNum(g, punt) {
  const xs = punt.inf ? [1e3, 1e5, 1e7].map(t => punt.inf * t) : [1e-3, 1e-5, 1e-7].map(h => punt.a + punt.costat * h);
  const ys = xs.map(x => { try { return g(x); } catch (e) { return NaN; } });
  if (ys.some(y => Number.isNaN(y))) return NaN;
  const [y0, y1, y2] = ys.map(Math.abs);
  // Infinit: molt gran i creixent, o bé creix com una potència (√x: ×100 a cada pas).
  if (!Number.isFinite(ys[2]) || (y2 > 1e5 && y2 > y1 && y1 > y0) || (y2 > 100 && y1 > 2 * y0 && y2 > 2 * y1)) return ys[2] > 0 ? Infinity : -Infinity;
  return ys[2];
}
const mateixLimit = (a, b) => (Number.isFinite(a) || Number.isFinite(b) ? Math.abs(a - b) < 1e-4 : a === b);
/** «lim_x→1^(-)…», «lim_x→+∞…», «lim_x→±∞…»: {punts, resta}. */
function llegeixLim(text) {
  const m = /^lim_x→(±∞|[+-]?∞|.+?\^\([+-]\))(.*)$/.exec(text);
  if (!m) return null;
  const p = m[1];
  const punts = p === '±∞' ? [{inf: 1}, {inf: -1}] : /∞$/.test(p) ? [{inf: p.startsWith('-') ? -1 : 1}]
    : [{a: M.avalua(M.llegeix(p.replace(/\^\([+-]\)$/, '')), {}), costat: p.endsWith('(-)') ? -1 : 1}];
  return {punts, resta: m[2], clau: p};
}
/** «(a,b)» (amb a i b que poden tenir parèntesis) → [a, b] numèrics. */
function llegeixParell(text) {
  if (text[0] !== '(' || text[text.length - 1] !== ')') return null;
  const dins = text.slice(1, -1);
  let prof = 0;
  for (let i = 0; i < dins.length; i++) {
    if (dins[i] === '(') prof++; else if (dins[i] === ')') prof--; else if (dins[i] === ',' && prof === 0) return [valorNum(dins.slice(0, i)).v, valorNum(dins.slice(i + 1)).v];
  }
  return null;
}
/** «(a,b)∪(c,d)» → [[a, b], [c, d]]; «capinterval» → []. */
function llegeixIntervals(text) {
  if (text === '«capinterval»') return [];
  const peces = [];
  let prof = 0, inici = 0;
  for (let i = 0; i < text.length; i++) {
    if (text[i] === '(') prof++; else if (text[i] === ')') prof--; else if (text[i] === '∪' && prof === 0) { peces.push(text.slice(inici, i)); inici = i + 1; }
  }
  peces.push(text.slice(inici));
  return peces.map(llegeixParell);
}
/** «P_1(a,b),P_2(c,d)», «Q(a,b)»: [{nom, x, y}]. */
function llegeixPunts(text) {
  const punts = [];
  const re = /([A-Z](?:_\d+)?)\(/g;
  let m;
  while ((m = re.exec(text))) {
    let prof = 1, i = re.lastIndex;
    for (; i < text.length && prof; i++) { if (text[i] === '(') prof++; else if (text[i] === ')') prof--; }
    const p = llegeixParell(text.slice(re.lastIndex - 1, i));
    punts.push({nom: m[1], x: p[0], y: p[1]});
    re.lastIndex = i;
  }
  return punts;
}
/** Una taula (TeX): files de cel·les en text pla. */
function cellesTaula(tex) {
  const m = /^\\begin\{array\}\{[^}]*\}([\s\S]*)\\end\{array\}$/.exec(tex.trim());
  return m[1].split(/\\\\\s*\\hline|\\\\/).map(f => f.split('&').map(c => (c.trim() ? textPla(c.trim()) : '')));
}

/** La veritat de tots els passos d'un problema de la gràfica d'una funció. */
function comprovaGrafica(id) {
  const G = GraficaFuncio, model = MODELS_GRAFICA[id], nom = `grafica-funcio ${id}`;
  const passos = G.passos({p: id});
  comprovaGuio(passos, G.files, nom);
  const W = [-12, 12];                               // la finestra de cerca numèrica
  const dom = model.dom || [[-Infinity, Infinity, false, false]];
  const dinsDom = x => dom.some(([a, b, ta, tb]) => (x > a || (ta && x === a)) && (x < b || (tb && x === b)));
  const foraDe = x => model.fora.some(a => Math.abs(a - x) < 1e-9) || !dinsDom(x);
  const mostres = [-3.7, -2.3, -1.4, -0.6, 0.4, 1.3, 1.7, 2.6, 3.4, 4.3].filter(x => !model.fora.some(a => Math.abs(a - x) < 0.05) && dinsDom(x - 0.05) && dinsDom(x + 0.05));
  // Els extrems del domini (tancats): els zeros que hi hagi no es veuen com a canvis de signe.
  const vores = dom.flatMap(([a, b, ta, tb]) => [...(ta ? [a] : []), ...(tb ? [b] : [])]);
  const zerosG = g => {
    const z = zerosNum(g, W);
    for (const v of vores) { const y = g(v); if (Number.isFinite(y) && Math.abs(y) < 1e-9 && !z.some(w => Math.abs(w - v) < 1e-6)) z.push(v); }
    return z.sort((p, q) => p - q);
  };

  /* El model, comprovat: derivades, zeros, punts crítics, inflexions. */
  for (const x of mostres) {
    comprova(quasiIgual(model.f1(x), derivadaNum(model.f, x), 1e-5), () => `${nom}: el model de f' no és la derivada de f en ${x}`);
    comprova(quasiIgual(model.f2(x), derivadaNum(model.f1, x), 1e-5), () => `${nom}: el model de f'' no és la derivada de f' en ${x}`);
  }
  const fins = g => x => (foraDe(x) ? NaN : g(x));
  comprova(mateixosValors(zerosG(fins(model.f)), model.zeros), () => `${nom}: el model té zeros mal posats`);
  const crit = zerosNum(fins(model.f1), W), infl = zerosNum(fins(model.f2), W);
  for (let x = W[0] + 0.0037; x < W[1]; x += 0.0131) comprova(dinsDom(x) === Number.isFinite(model.f(x)) || model.fora.some(a => Math.abs(a - x) < 1e-3), () => `${nom}: el domini del model no és on f existeix (x = ${x})`);
  comprova(mateixosValors(crit, model.critics.map(c => c[0])), () => `${nom}: el model té punts crítics mal posats (${crit})`);
  const canvi = (g, x) => Math.sign(g(x - 1e-3)) !== Math.sign(g(x + 1e-3));
  for (const [x, t] of model.critics) {
    const esperat = !canvi(model.f1, x) ? null : model.f1(x - 1e-3) > 0 ? 'màxim' : 'mínim';
    comprova(esperat === t, () => `${nom}: el model diu que en ${x} hi ha ${t}`);
  }
  comprova(mateixosValors(infl.filter(x => canvi(model.f2, x)), model.inflexions), () => `${nom}: el model té inflexions mal posades`);
  const esperatsEq = {'equacio:Q': model.fora, 'equacio:f': model.zeros, 'equacio:f1': crit, 'equacio:f2': infl};
  const limitF = punt => limitNum(model.f, punt);

  /* Totes les files de tots els passos, segons el seu tipus (cada contingut, un sol cop). */
  const vist = new Set();
  passos.forEach((pas, ip) => {
    const on = `${nom}, pas ${ip + 1}`;
    comprova(Array.isArray(pas.tipus) && pas.tipus.length === G.files, () => `${on}: falten els tipus de les files`);
    pas.files.forEach((tex, i) => {
      if (!tex) return;
      const tipus = pas.tipus[i];
      comprova(TIPUS_GRAFICA.has(tipus), () => `${on}, fila ${i}: tipus desconegut «${tipus}»`);
      const k = tipus + '\n' + tex;
      if (vist.has(k)) return;
      vist.add(k);
      const lloc = `${on}, fila ${i} (${tipus})`;
      const principal = pas.tipus.indexOf(tipus) === i;
      try { comprovaFilaGrafica(tipus, tex, model, {lloc, W, mostres, foraDe, dinsDom, dom, zerosG, esperatsEq, limitF, crit, infl, principal}); }
      catch (e) { comprova(false, () => `${lloc}: no s'ha pogut llegir (${e.message}): «${tex.slice(0, 120)}»`); }
    });
  });

  /* L'últim pas: els set apartats en ordre, les solucions en lila, les taules plenes, la gràfica. */
  const ultim = passos[passos.length - 1];
  const titols = ultim.files.filter((t, i) => ultim.tipus[i] === 'apartat').map(t => t.slice(1));
  comprova(iguals(titols, TITOLS_GRAFICA), () => `${nom}: els títols dels apartats no són els set, en ordre: ${JSON.stringify(titols)}`);
  comprova(ultim.files.some((t, i) => ultim.tipus[i] === 'grafica' && t.startsWith('<svg') && t.includes('class="corba"')), () => `${nom}: a l'últim pas hi ha d'haver la gràfica amb la corba`);
  for (const [tipus, esperats] of Object.entries(esperatsEq)) {
    const lila = ultim.files.flatMap((t, i) => (ultim.tipus[i] === tipus ? contingutsMarcats(t, 'solucio').map(x => valorNum(textPla(x)).v) : []));
    comprova(mateixosValors(lila.sort((a, b) => a - b), esperats), () => `${nom}: les solucions en lila de ${tipus} (${lila}) no són ${esperats}`);
  }
  for (const t of ['taula1', 'taula2']) {
    const i = ultim.tipus.indexOf(t);
    comprova(i >= 0, () => `${nom}: falta la ${t}`);
    if (i < 0) continue;
    const c = cellesTaula(ultim.files[i]);
    comprova(c[1].slice(1).every((x, j) => x || j % 2 === 1) && c[2].slice(1).every((x, j) => x || j % 2 === 1), () => `${nom}: la ${t} no és plena a l'últim pas`);
  }
}

/** Comprova una fila (TeX) segons el seu tipus. */
function comprovaFilaGrafica(tipus, tex, model, c) {
  const {lloc} = c;
  if (tipus === 'grafica') { comprova(tex.startsWith('<svg'), () => `${lloc}: no és un dibuix`); return; }
  if (tipus === 'apartat') { comprova(TITOLS_GRAFICA.includes(tex.slice(1)), () => `${lloc}: títol desconegut`); return; }
  const identitat = (text, g) => {
    // «(…)'»: la derivada (indicada) de l'expressió de dins, numèrica.
    const dins = /^\((.*)\)'$/.exec(text);
    if (dins) {
      const e = expressioNum(dins[1], model);
      for (const x of c.mostres) comprova(quasiIgual(derivadaNum(e, x), g(x), 1e-6), () => `${lloc}: la derivada de «${dins[1]}» no és la del model en x = ${x}`);
      return;
    }
    const h = expressioNum(text, model);
    for (const x of c.mostres) comprova(quasiIgual(h(x), g(x)), () => `${lloc}: «${text}» no és igual a la funció del model en x = ${x} (${h(x)} ≠ ${g(x)})`);
  };
  if (tipus === 'f' || tipus === 'derivada1' || tipus === 'derivada2') {
    const [esq, ...parts] = liniesLogiques(tex)[0].split('=');
    const g = tipus === 'f' ? model.f : tipus === 'derivada1' ? model.f1 : model.f2;
    comprova(esq === {f: 'f(x)', derivada1: "f'(x)", derivada2: "f''(x)"}[tipus], () => `${lloc}: el membre esquerre és «${esq}»`);
    comprova(parts.length > 0, () => `${lloc}: no hi ha cap expressió`);
    for (const p of parts) identitat(p, g);
    return;
  }
  if (tipus === 'domini') {
    const t = textPla(tex);
    const iv = /^«Dom»f=([[(].*)$/.exec(t);
    if (iv) {
      // Una unió d'intervals: «[-1,+∞)», «(-∞,-2]∪[2,+∞)».
      const llegits = iv[1].split('∪').map(p => {
        const q = /^([[(])(.*),(.*)([\])])$/.exec(p);
        return q && [valorNum(q[2]).v, valorNum(q[3]).v, q[1] === '[', q[4] === ']'];
      });
      comprova(JSON.stringify(llegits) === JSON.stringify(c.dom), () => `${lloc}: el domini «${t}» no és el del model (${JSON.stringify(c.dom)})`);
      return;
    }
    const m = /^«Dom»f=ℝ(?:-\{(.*)\})?$/.exec(t);
    comprova(m && !model.dom, () => `${lloc}: el domini no s'entén: «${t}»`);
    if (!m) return;
    const fora = m[1] ? m[1].split(',').map(s => valorNum(s).v).sort((a, b) => a - b) : [];
    comprova(mateixosValors(fora, model.fora), () => `${lloc}: el domini «${t}» no és el del model (fora: ${model.fora})`);
    return;
  }
  if (tipus === 'inequacio') {
    // «A ≥ B ⇔ C ≥ D ⇔ …»: cada inequació (o unió d'inequacions) té per solucions el domini.
    const REL = {'≥': (a, b) => a >= b, '≤': (a, b) => a <= b, '>': (a, b) => a > b, '<': (a, b) => a < b};
    for (const part of liniesLogiques(tex).join('').split('⇔')) {
      const disj = part.split('|').map(d => {
        const q = /^(.*?)(≥|≤|>|<)(.*)$/.exec(d);
        comprova(q, () => `${lloc}: «${d}» no és una inequació`);
        return q && [expressioNum(q[1], model), REL[q[2]], expressioNum(q[3], model)];
      }).filter(Boolean);
      const compleix = x => disj.some(([l, r, rr]) => r(l(x), rr(x)));
      let mal = null;
      for (let x = c.W[0] + 0.0037; x < c.W[1]; x += 0.0131) if (compleix(x) !== c.dinsDom(x)) { mal = x; break; }
      for (const v of c.dom.flat().filter(Number.isFinite)) if (compleix(v) !== c.dinsDom(v)) mal = v;
      comprova(mal === null, () => `${lloc}: «${part}» no té per solucions el domini (x = ${mal})`);
    }
    return;
  }
  if (tipus.startsWith('equacio:')) {
    const esperats = c.esperatsEq[tipus];
    const {net, tatxades} = separaTatxades(tex);
    // Les solucions tatxades no són del domini.
    for (const q of tatxades) {
      const v = valorNum(textPla(q).split('=')[1]).v;
      comprova(c.foraDe(v), () => `${lloc}: s'ha tatxat «${textPla(q)}», que és del domini`);
    }
    tex = net;
    for (const linia of liniesLogiques(tex)) {
      let zeros = [];
      for (const disj of linia.split('|')) {
        const variants = disj.includes('±') ? [disj.replace(/±/g, '+'), disj.replace(/±/g, '-')] : [disj];
        for (const v of variants) {
          const [L, Rr, ...resta] = v.split('=');
          comprova(Rr !== undefined && !resta.length, () => `${lloc}: «${v}» no és una equació`);
          if (Rr === undefined) continue;
          const l = expressioNum(L, model), r = expressioNum(Rr, model);
          zeros = zeros.concat(c.zerosG(x => (c.foraDe(x) ? NaN : l(x) - r(x))));
        }
      }
      zeros = zeros.filter((z, j) => zeros.findIndex(w => Math.abs(w - z) < 1e-6) === j).sort((a, b) => a - b);
      // La fila de l'equació té les mateixes solucions; les files de treball (on es resol un factor), només solucions de l'equació.
      const bo = c.principal ? mateixosValors(zeros, esperats) : zeros.every(z => esperats.some(e => Math.abs(e - z) < 1e-6));
      comprova(bo, () => `${lloc}: «${linia}» té les solucions ${zeros.map(z => z.toFixed(4))}, i l'equació, ${esperats.map(z => z.toFixed(4))}`);
    }
    return;
  }
  if (tipus === 'limits') {
    for (const linia of liniesLogiques(tex)) {
      const parts = linia.split('=');
      const lims = parts.map(llegeixLim);
      const primer = lims.findIndex(Boolean);
      comprova(primer >= 0 && primer <= 1 && (primer === 0 || ['m', 'n'].includes(parts[0])), () => `${lloc}: «${linia}» no comença amb un límit`);
      if (primer < 0) continue;
      const ref = lims[primer];
      const g0 = expressioNum(ref.resta, model);
      const esperat = ref.punts.map(p => limitNum(g0, p));
      for (let j = primer; j < parts.length; j++) {
        if (lims[j]) {
          comprova(lims[j].clau === ref.clau, () => `${lloc}: «${parts[j]}» no és el mateix límit`);
          const g = expressioNum(lims[j].resta, model);
          ref.punts.forEach((p, q) => comprova(mateixLimit(limitNum(g, p), esperat[q]), () => `${lloc}: «${parts[j]}» no té el mateix límit (${limitNum(g, p)} ≠ ${esperat[q]})`));
        } else {
          comprova(j === parts.length - 1, () => `${lloc}: un valor al mig d'una cadena de límits: «${parts[j]}»`);
          const v = valorNum(parts[j]).v;
          esperat.forEach(e => comprova(mateixLimit(v, e), () => `${lloc}: el resultat «${parts[j]}» no és el límit (${e})`));
        }
      }
      // Un límit de f és el del model; m = lim f/x; n = lim (f − m·x).
      if (/^f\(x\)$/.test(ref.resta)) ref.punts.forEach((p, q) => comprova(mateixLimit(esperat[q], c.limitF(p)), () => `${lloc}: el límit no és el de f`));
    }
    return;
  }
  if (tipus === 'asimptotes') {
    const t = textPla(tex);
    const verticals = model.fora.filter(a => !Number.isFinite(c.limitF({a, costat: 1})));
    const lMes = c.limitF({inf: 1}), lMenys = c.limitF({inf: -1});
    if (/vertical/.test(t)) {
      const xs = t.startsWith('«Nohi') ? [] : [...t.matchAll(/x=([^«]+)/g)].map(m => valorNum(m[1]).v);
      comprova(mateixosValors(xs, verticals), () => `${lloc}: «${t}», però les asímptotes verticals són x = ${verticals}`);
    } else if (/horitzontal/.test(t)) {
      const h = Number.isFinite(lMes) ? lMes : null;
      comprova(t.startsWith('«Nohi') ? h === null : (h !== null && quasiIgual(valorNum(t.split('y=')[1]).v, h, 1e-6) && quasiIgual(lMenys, h, 1e-6)),
        () => `${lloc}: «${t}», però el límit a l'infinit és ${lMes}`);
    } else if (/obliq/.test(t)) {
      // «Asímptota obliqua a +∞: …» (o a −∞): la d'aquell costat; si no ho diu, la de +∞ (i és la mateixa a −∞).
      const costat = /a-∞/.test(t.replace(/«|»/g, '')) ? -1 : 1;
      const lCostat = costat > 0 ? lMes : lMenys;
      const m = Math.round(limitNum(x => model.f(x) / x, {inf: costat}) * 1e6) / 1e6;
      const hiHa = !Number.isFinite(lCostat) && Number.isFinite(m) && Math.abs(m) > 1e-9;
      if (t.startsWith('«Nohi')) comprova(!hiHa, () => `${lloc}: sí que hi ha asímptota obliqua`);
      else {
        const n = limitNum(x => model.f(x) - m * x, {inf: costat});
        const r = expressioNum(t.split('y=')[1], model);
        comprova(hiHa && quasiIgual(r(1) - r(0), m, 1e-6) && quasiIgual(r(0), n, 1e-6), () => `${lloc}: «${t}», però m = ${m} i n = ${n}`);
      }
    } else comprova(false, () => `${lloc}: no s'entén «${t}»`);
    return;
  }
  if (tipus === 'valors') {
    for (const linia of liniesLogiques(tex)) {
      const [esq, ...parts] = linia.split('=');
      const m = /^f\((.*)\)$/.exec(esq);
      comprova(m && parts.length, () => `${lloc}: «${linia}» no és «f(a) = …»`);
      if (!m) continue;
      const a = valorNum(m[1]).v, esperat = model.f(a);
      for (const p of parts) {
        const {v, aprox} = valorNum(p);
        comprova(quasiIgual(v, esperat), () => `${lloc}: «${p}» no és f(${a}) = ${esperat}`);
        if (aprox !== undefined) comprova(aprox === decimal2(esperat), () => `${lloc}: «≈ ${aprox}» no és ${decimal2(esperat)}`);
      }
    }
    return;
  }
  if (tipus === 'proves1' || tipus === 'proves2') {
    const g = tipus === 'proves1' ? model.f1 : model.f2, prima = tipus === 'proves1' ? "'" : "''";
    for (const linia of liniesLogiques(tex)) {
      const m = /^(.*)([<>])0$/.exec(linia);
      comprova(m, () => `${lloc}: «${linia}» no acaba amb «> 0» o «< 0»`);
      if (!m) continue;
      const [esq, ...parts] = m[1].split('=');
      const t = new RegExp(`^f${prima}\\((.*)\\)$`).exec(esq);
      comprova(t, () => `${lloc}: «${esq}» no és f${prima}(t)`);
      if (!t) continue;
      const x = valorNum(t[1]).v, esperat = g(x);
      for (const p of parts) {
        const {v, aprox} = valorNum(p);
        comprova(quasiIgual(v, esperat), () => `${lloc}: «${p}» no és f${prima}(${x}) = ${esperat}`);
        if (aprox !== undefined) comprova(aprox === decimal2(esperat), () => `${lloc}: «≈ ${aprox}» no és ${decimal2(esperat)}`);
      }
      comprova((m[2] === '>') === (esperat > 0), () => `${lloc}: el signe de f${prima}(${x}) no és «${m[2]} 0»`);
    }
    return;
  }
  if (tipus === 'taula1' || tipus === 'taula2') {
    const primera = tipus === 'taula1', g = primera ? model.f1 : model.f2;
    const [cap, fd, ff] = cellesTaula(tex);
    comprova(cap[0] === 'x' && fd[0] === (primera ? "f'(x)" : "f''(x)") && ff[0] === 'f(x)', () => `${lloc}: les etiquetes de la taula`);
    // Les columnes esperades: a cada tros del domini (obert), els intervals que hi fan els punts que no són del domini i
    // els zeros de la derivada; entre dos trossos, res.
    const especials = [...model.fora, ...(primera ? c.crit : c.infl)].sort((a, b) => a - b);
    const esperades = [];
    for (const [a, b] of c.dom) {
      let esq = a;
      for (const p of especials.filter(x => x > a && x < b)) { esperades.push({interval: [esq, p]}, {punt: p}); esq = p; }
      esperades.push({interval: [esq, b]});
    }
    const columnes = cap.slice(1).map(s_ => (s_.startsWith('x=') ? {punt: valorNum(s_.slice(2)).v} : {interval: llegeixParell(s_)}));
    const eqv = (p, q) => p === q || Math.abs(p - q) < 1e-9;
    const igualsCol = (p, q) => (p.punt !== undefined ? q.punt !== undefined && eqv(p.punt, q.punt) : Boolean(q.interval) && eqv(p.interval[0], q.interval[0]) && eqv(p.interval[1], q.interval[1]));
    comprova(columnes.length === esperades.length && columnes.every((col, j) => igualsCol(esperades[j], col)),
      () => `${lloc}: les columnes de la taula (${cap.slice(1).join(' | ')}) no són les esperades (${JSON.stringify(esperades)})`);
    if (columnes.length !== esperades.length) return;
    columnes.forEach((col, n) => {
      const cel = fd[1 + n], cf = ff[1 + n];
      if (col.interval) {
        const [a, b] = esperades[n].interval;
        const prova = Number.isFinite(a) && Number.isFinite(b) ? (a + b) / 2 : Number.isFinite(a) ? a + 1 : Number.isFinite(b) ? b - 1 : 0;
        const s_ = g(prova) > 0 ? '+' : '-';
        if (cel) comprova(cel === s_, () => `${lloc}: a l'interval ${col.interval} el signe és ${s_}, no «${cel}»`);
        if (cf) comprova(cf === (primera ? (s_ === '+' ? '↗' : '↘') : (s_ === '+' ? '∪' : '∩')), () => `${lloc}: a l'interval ${col.interval}, «${cf}»`);
      } else {
        const x = col.punt;
        const fora = model.fora.some(a => Math.abs(a - x) < 1e-9);
        if (cel) comprova(cel === (fora ? '∄' : '0'), () => `${lloc}: al punt ${x}, «${cel}»`);
        const esq = g(x - 1e-3) > 0, dre = g(x + 1e-3) > 0;
        const esperat = fora ? '∄' : esq === dre ? '' : primera ? (esq ? '«màxim»' : '«mínim»') : '«inflexió»';
        if (cf || !esperat) comprova(cf === esperat, () => `${lloc}: al punt ${x}, «${cf}» en lloc de «${esperat}»`);
      }
    });
    return;
  }
  if (tipus === 'conclusio1' || tipus === 'conclusio2') {
    const primera = tipus === 'conclusio1', g = primera ? model.f1 : model.f2;
    const xs = [];
    for (let x = c.W[0] + 0.0037; x < c.W[1]; x += 0.0131) if (!c.foraDe(x) && [...model.fora, ...c.crit, ...c.infl].every(a => Math.abs(a - x) > 1e-3)) xs.push(x);
    const dins = (ivs, x) => ivs.some(([a, b]) => x > a && x < b);
    const especials = primera ? model.critics.filter(([, t]) => t) : model.inflexions.map(x => [x, 'inflexió']);
    const trobats = [];
    for (const linia of liniesLogiques(tex)) {
      const m = /^«(Creixent:|Decreixent:|Concavitatpositiva:|Concavitatnegativa:)»(.*)$/.exec(linia);
      if (m) {
        const ivs = llegeixIntervals(m[2]);
        const positiu = /Creixent|positiva/.test(m[1]);
        comprova(xs.every(x => dins(ivs, x) === (positiu ? g(x) > 0 : g(x) < 0)), () => `${lloc}: «${linia}» no és on ${primera ? "f'" : "f''"} ${positiu ? '> 0' : '< 0'}`);
        comprova(model.fora.every(a => !dins(ivs, a)) && ivs.every(([a, b]) => c.dinsDom(Number.isFinite(a) ? a + 1e-9 : b - 1) && c.dinsDom(Number.isFinite(b) ? b - 1e-9 : a + 1)
          && !c.dom.some(([p, q]) => (p > a && p < b) || (q > a && q < b))), () => `${lloc}: «${linia}» conté un punt que no és del domini`);
        continue;
      }
      const e = /^«(Màximrelatiuen|Mínimrelatiuen|Puntd'inflexióen|Puntsd'inflexióen)»(.*)$/.exec(linia);
      if (e) {
        const tipusE = e[1].startsWith('Màxim') ? 'màxim' : e[1].startsWith('Mínim') ? 'mínim' : 'inflexió';
        for (const [x, y] of llegeixIntervalsPunts(e[2])) {
          trobats.push([x, tipusE]);
          comprova(quasiIgual(y, model.f(x)), () => `${lloc}: la y de (${x}, ${y}) no és f(${x})`);
        }
        continue;
      }
      comprova(/^«Nohihaextremsrelatius»$|^«Nohihapuntsd'inflexió»$/.test(linia), () => `${lloc}: no s'entén «${linia}»`);
      comprova(!especials.length, () => `${lloc}: «${linia}», però n'hi ha`);
    }
    if (trobats.length || especials.length) {
      const ordena = l => l.slice().sort((p, q) => p[0] - q[0]);
      comprova(JSON.stringify(ordena(trobats).map(([x, t]) => [x.toFixed(6), t])) === JSON.stringify(ordena(especials).map(([x, t]) => [x.toFixed(6), t])),
        () => `${lloc}: els ${primera ? 'extrems' : 'punts d\'inflexió'} no són els del model`);
    }
    return;
  }
  if (tipus === 'punts') {
    const t = textPla(tex);
    if (t === "«Notallal'eixd'ordenades»") { comprova(c.foraDe(0), () => `${lloc}: 0 és del domini`); return; }
    if (t === "«Notallal'eixd'abscisses»") { comprova(!model.zeros.length, () => `${lloc}: sí que talla l'eix d'abscisses`); return; }
    const punts = llegeixPunts(t);
    if (punts.length === 1 && punts[0].nom === 'Q') {
      comprova(punts[0].x === 0 && quasiIgual(punts[0].y, model.f(0)), () => `${lloc}: «${t}» no és (0, f(0))`);
      return;
    }
    const noms = model.zeros.length > 1 ? model.zeros.map((_, i) => `P_${i + 1}`) : ['P'];
    comprova(iguals(punts.map(p => p.nom), noms) && mateixosValors(punts.map(p => p.x), model.zeros) && punts.every(p => p.y === 0),
      () => `${lloc}: «${t}» no són els talls amb l'eix d'abscisses (${model.zeros})`);
    return;
  }
  if (tipus === 'taula-valors') {
    const [fx, fy] = cellesTaula(tex);
    comprova(fx[0] === 'x' && fy[0] === 'f(x)' && fx.length === fy.length, () => `${lloc}: la taula de valors`);
    const xs = [];
    for (let j = 1; j < fx.length; j++) {
      const x = valorNum(fx[j]), y = valorNum(fy[j]);
      xs.push(x.v);
      comprova(quasiIgual(y.v, model.f(x.v)), () => `${lloc}: (${fx[j]}, ${fy[j]}): f(${x.v}) = ${model.f(x.v)}`);
      if (x.aprox !== undefined) comprova(x.aprox === decimal2(x.v), () => `${lloc}: «${fx[j]}»`);
      if (y.aprox !== undefined) comprova(y.aprox === decimal2(y.v), () => `${lloc}: «${fy[j]}»`);
    }
    comprova(xs.every((x, j) => !j || x > xs[j - 1]), () => `${lloc}: la taula no és ordenada`);
    const cal = [...model.zeros, ...(c.foraDe(0) ? [] : [0]), ...model.critics.filter(([, t]) => t).map(([x]) => x), ...model.inflexions];
    comprova(cal.every(x => xs.some(w => Math.abs(w - x) < 1e-9)), () => `${lloc}: hi falten talls, extrems o inflexions`);
    comprova(xs.filter(x => !cal.some(w => Math.abs(w - x) < 1e-9)).length >= 2, () => `${lloc}: hi falten els dos punts més`);
    return;
  }
  comprova(false, () => `${lloc}: tipus sense comprovació`);
}
/** El contingut (TeX) de cada símbol amb la marca «marca» d'una fila (les claus equilibrades). */
function contingutsMarcats(tex, marca) {
  const r = [], re = new RegExp(`\\\\htmlData\\{k=[^},]*,marca=${marca}\\}\\{`, 'g');
  let m;
  while ((m = re.exec(tex))) {
    let prof = 1, i = re.lastIndex;
    for (; i < tex.length && prof; i++) { if (tex[i] === '\\') i++; else if (tex[i] === '{') prof++; else if (tex[i] === '}') prof--; }
    r.push(tex.slice(re.lastIndex, i - 1));
  }
  return r;
}
/** «(a,b),(c,d)» → [[a, b], [c, d]] (els punts d'una conclusió). */
function llegeixIntervalsPunts(text) {
  const peces = [];
  let prof = 0, inici = 0;
  for (let i = 0; i < text.length; i++) {
    if (text[i] === '(') prof++; else if (text[i] === ')') prof--; else if (text[i] === ',' && prof === 0) { peces.push(text.slice(inici, i)); inici = i + 1; }
  }
  peces.push(text.slice(inici));
  return peces.map(llegeixParell);
}

seccio("gràfica d'una funció", () => {
  const ids = GraficaFuncio.PROBLEMES.map(p => p.id);
  comprova(iguals(ids.slice().sort(), Object.keys(MODELS_GRAFICA).sort()), () => `gràfica d'una funció: falta el model d'algun problema (${ids})`);
  for (const id of ids) if (MODELS_GRAFICA[id]) comprovaGrafica(id);
  // Les adreces: ?p=<id>, i un id que no existeix.
  for (const id of ids) comprova(iguals(GraficaFuncio.llegeixAdreca({p: id}), {valors: {p: id}}), () => `gràfica: adreça ?p=${id}`);
  comprova(GraficaFuncio.llegeixAdreca({p: 'no'}).error, () => 'gràfica: una adreça amb un problema que no existeix');
  return `${ids.length} funcions`;
});


/* ── DOMINI D'UNA FUNCIÓ ───────────────────────────────────────────── */
/*
 * Model escrit aquí, a mà, per a cada funció: el text pla de f, f com a nombre (JS) per saber on es pot calcular,
 * el domini esperat i les condicions (relació i g). Les files del guió es llegeixen per la seva funció (FILA):
 * f; la cadena d'equivalències de cada condició (cada pas, amb el mateix conjunt de solucions que la condició);
 * l'equació g = 0 i el seu treball (mateixes arrels que g); la taula de signes (trossos i signes de g, marcats els
 * que serveixen); la recta real (SVG: un grup per línia, els segments i els punts oberts i tancats que toquen);
 * la intersecció; el domini.
 */
const INF_D = Infinity;
const TOT_D = [[-INF_D, INF_D, false, false]];
const obert = (...ext) => ext.map(([a, b]) => [a, b, false, false]);
const MODELS_DOMINI = {
  'polinomi': {fPla: 'x^(3)-3x+1', num: x => x ** 3 - 3 * x + 1, dom: TOT_D, conds: []},
  'fraccio-lineal': {fPla: '((x+1)/(x-2))', num: x => (x + 1) / (x - 2), dom: obert([-INF_D, 2], [2, INF_D]), conds: [{rel: 'ne', g: 'x-2'}]},
  'fraccio-quadrat': {fPla: '((1)/(x^(2)-4))', num: x => 1 / (x * x - 4), dom: obert([-INF_D, -2], [-2, 2], [2, INF_D]), conds: [{rel: 'ne', g: 'x^2-4'}]},
  'fraccio-trinomi': {fPla: '((x)/(x^(2)-x-2))', num: x => x / (x * x - x - 2), dom: obert([-INF_D, -1], [-1, 2], [2, INF_D]), conds: [{rel: 'ne', g: 'x^2-x-2'}]},
  'fraccio-sense-arrels': {fPla: '((x)/(x^(2)+1))', num: x => x / (x * x + 1), dom: TOT_D, conds: [{rel: 'ne', g: 'x^2+1'}]},
  'arrel-lineal': {fPla: 'sqrt(x-3)', num: x => Math.sqrt(x - 3), dom: [[3, INF_D, true, false]], conds: [{rel: 'ge', g: 'x-3'}]},
  'arrel-negatiu': {fPla: 'sqrt(5-2x)', num: x => Math.sqrt(5 - 2 * x), dom: [[-INF_D, 2.5, false, true]], conds: [{rel: 'ge', g: '5-2x'}]},
  'arrel-cercle': {fPla: 'sqrt(1-x^(2))', num: x => Math.sqrt(1 - x * x), dom: [[-1, 1, true, true]], conds: [{rel: 'ge', g: '1-x^2'}]},
  'arrel-quadrat': {fPla: 'sqrt(x^(2)-4)', num: x => Math.sqrt(x * x - 4), dom: [[-INF_D, -2, false, true], [2, INF_D, true, false]], conds: [{rel: 'ge', g: 'x^2-4'}]},
  'arrel-sempre': {fPla: 'sqrt(1+x^(2))', num: x => Math.sqrt(1 + x * x), dom: TOT_D, conds: [{rel: 'ge', g: '1+x^2'}]},
  'arrel-quarta': {fPla: '((x^(2)-3x)^(1/4))', num: x => Math.pow(x * x - 3 * x, 0.25), dom: [[-INF_D, 0, false, true], [3, INF_D, true, false]], conds: [{rel: 'ge', g: 'x^2-3x'}]},
  'arrel-denominador': {fPla: '((1)/(sqrt(x-3)))', num: x => 1 / Math.sqrt(x - 3), dom: obert([3, INF_D]), conds: [{rel: 'gt', g: 'x-3'}]},
  'arrel-denominador-cercle': {fPla: '((1)/(sqrt(1-x^(2))))', num: x => 1 / Math.sqrt(1 - x * x), dom: obert([-1, 1]), conds: [{rel: 'gt', g: '1-x^2'}]},
  'arrel-i-fraccio': {fPla: '((sqrt(x+2))/(x-1))', num: x => Math.sqrt(x + 2) / (x - 1), dom: [[-2, 1, true, false], [1, INF_D, false, false]],
    conds: [{rel: 'ge', g: 'x+2'}, {rel: 'ne', g: 'x-1'}]},
  'arrel-cubica': {fPla: '((x-1)^(1/3))', num: x => Math.cbrt(x - 1), dom: TOT_D, conds: []},
  'arrel-cubica-denominador': {fPla: '((1)/(((x+2)^(1/3))))', num: x => 1 / Math.cbrt(x + 2), dom: obert([-INF_D, -2], [-2, INF_D]), conds: [{rel: 'ne', g: 'x+2'}]},
  'logaritme-lineal': {fPla: 'ln(x-1)', num: x => Math.log(x - 1), dom: obert([1, INF_D]), conds: [{rel: 'gt', g: 'x-1'}]},
  'logaritme-cercle': {fPla: 'ln(4-x^(2))', num: x => Math.log(4 - x * x), dom: obert([-2, 2]), conds: [{rel: 'gt', g: '4-x^2'}]},
  'logaritme-sempre': {fPla: 'ln(x^(2)+1)', num: x => Math.log(x * x + 1), dom: TOT_D, conds: [{rel: 'gt', g: 'x^2+1'}]},
  'logaritme-i-fraccio': {fPla: '((ln(x))/(x-2))', num: x => Math.log(x) / (x - 2), dom: obert([0, 2], [2, INF_D]), conds: [{rel: 'gt', g: 'x'}, {rel: 'ne', g: 'x-2'}]},
  'exponencial': {fPla: 'e^(x^(2)-1)', num: x => Math.exp(x * x - 1), dom: TOT_D, conds: []},
  'exponencial-fraccio': {fPla: 'e^(((1)/(x)))', num: x => Math.exp(1 / x), dom: obert([-INF_D, 0], [0, INF_D]), conds: [{rel: 'ne', g: 'x'}]},
  'exponencial-arrel': {fPla: '2^(sqrt(x))', num: x => Math.pow(2, Math.sqrt(x)), dom: [[0, INF_D, true, false]], conds: [{rel: 'ge', g: 'x'}]},
};

/** La graella de comprovació: múltiples de 1/8 entre −12 i 12 (hi són tots els extrems, que són enters o meitats). */
const GRAELLA_DOMINI = Array.from({length: 193}, (_, k) => fr(k - 96, 8));
const enModel = (dom, x) => dom.some(([a, b, ca, cb]) => (x > a || (ca && x === a)) && (x < b || (cb && x === b)));
const RELACIONS_DOMINI = {ne: (v) => v.signe() !== 0, ge: v => v.signe() >= 0, gt: v => v.signe() > 0};

/** Un conjunt en text pla («ℝ-{-2,2}», «(-∞,-2]∪[2,+∞)», «A∩(B∪C)»): una funció «x (Fraccio) → bool». */
function conjuntDomini(text) {
  let i = 0;
  const nombreFins = () => {
    let prof = 0;
    const ini = i;
    while (i < text.length) {
      const c = text[i];
      if (c === '(' || c === '[') prof++;
      else if (c === ')' || c === ']') { if (prof === 0) break; prof--; } else if (c === ',' && prof === 0) break;
      i++;
    }
    return text.slice(ini, i);
  };
  const valor = s => (s === '-∞' || s === '+∞' || s === '∞' ? null : exacte(M.llegeix(s, {variables: []}), {variables: {}, funcions: {}}));
  const interval = () => {
    const obre = text[i];
    if (obre !== '(' && obre !== '[') throw new Error('no és un interval');
    i++;
    const a = valor(nombreFins());
    if (text[i] !== ',') throw new Error('falta la coma');
    i++;
    const b = valor(nombreFins());
    const tanca = text[i];
    if (tanca !== ')' && tanca !== ']') throw new Error('falta el final');
    i++;
    const [ca, cb] = [obre === '[', tanca === ']'];
    if (ca && a === null) throw new Error('claudàtor a l\'infinit');
    if (cb && b === null) throw new Error('claudàtor a l\'infinit');
    return x => (a === null || x.resta(a).signe() > 0 || (ca && x.resta(a).signe() === 0)) && (b === null || x.resta(b).signe() < 0 || (cb && x.resta(b).signe() === 0));
  };
  const atom = () => {
    if (text[i] === 'ℝ') {
      i++;
      if (text[i] !== '-') return () => true;
      if (text.slice(i + 1, i + 2) !== '{') throw new Error('falta {');
      const fi = text.indexOf('}', i);
      const punts = text.slice(i + 2, fi).split(',').map(s => valor(s));
      i = fi + 1;
      return x => !punts.some(p => x.resta(p).signe() === 0);
    }
    const inici = i;
    try { return interval(); } catch (e) { i = inici; }
    if (text[i] !== '(') throw new Error(`conjunt no entès: «${text.slice(inici)}»`);
    i++;
    const r = unio();
    if (text[i] !== ')') throw new Error('falta )');
    i++;
    return r;
  };
  const inter = () => {
    const fs = [atom()];
    while (text[i] === '∩') { i++; fs.push(atom()); }
    return x => fs.every(f => f(x));
  };
  function unio() {
    const fs = [inter()];
    while (text[i] === '∪') { i++; fs.push(inter()); }
    return x => fs.some(f => f(x));
  }
  const r = unio();
  if (i !== text.length) throw new Error(`sobra text a «${text}» (posició ${i})`);
  return r;
}
/** Els intervals d'un conjunt escrit com a unió d'intervals («(a,b]∪[c,d)»), per comprovar que és la forma normal. */
function intervalsDomini(text) {
  const peces = [];
  let prof = 0, ini = 0;
  for (let q = 0; q < text.length; q++) {
    if (text[q] === '(' || text[q] === '[') prof++; else if (text[q] === ')' || text[q] === ']') prof--; else if (text[q] === '∪' && prof === 0) { peces.push(text.slice(ini, q)); ini = q + 1; }
  }
  peces.push(text.slice(ini));
  return peces.map(p => {
    const m = /^([[(])(.*),(.*)([\])])$/.exec(p);
    if (!m) throw new Error(`«${p}» no és un interval`);
    return {a: m[2] === '-∞' ? null : valorNum(m[2]).v, b: m[3] === '+∞' ? null : valorNum(m[3]).v, ca: m[1] === '[', cb: m[4] === ']'};
  });
}

/** Una línia de la cadena d'equivalències («g ≥ 0», «x ≠ a, x ≠ b», «x ∈ conjunt»): una funció «x → bool». */
function liniaDomini(text) {
  if (text.startsWith('x∈')) return conjuntDomini(text.slice(2));
  const atoms = text.split(',').map(a => {
    const m = /^(.*?)(≥|≤|≠|>|<)(.*)$/.exec(a);
    if (!m) throw new Error(`«${a}» no és una desigualtat`);
    const REL = {'≥': (p, q) => p.resta(q).signe() >= 0, '≤': (p, q) => p.resta(q).signe() <= 0, '≠': (p, q) => p.resta(q).signe() !== 0,
      '>': (p, q) => p.resta(q).signe() > 0, '<': (p, q) => p.resta(q).signe() < 0};
    return {e: m[1], r: m[2], d: m[3], f: REL[m[2]]};
  });
  return x => atoms.every(a => a.f(valorX(a.e, 'x', x), valorX(a.d, 'x', x)));
}

function comprovaDomini(passos, p, nom) {
  const model = MODELS_DOMINI[p.id];
  comprova(model, () => `${nom}: no hi ha model`);
  if (!model) return 0;
  const FILA = Domini.FILA;
  let linies = 0;
  // El model és coherent: f es pot calcular exactament als punts del domini, i el domini és la conjunció de les condicions.
  for (const x of GRAELLA_DOMINI) {
    const xf = x.num / x.den;
    comprova(Number.isFinite(model.num(xf)) === enModel(model.dom, xf), () => `${nom}: el model del domini falla a x = ${xf}`);
    comprova(model.conds.every(c => RELACIONS_DOMINI[c.rel](valorX(c.g, 'x', x))) === enModel(model.dom, xf), () => `${nom}: les condicions del model no donen el seu domini a x = ${xf}`);
  }
  const reals = (S, x) => S(x);
  const conjModel = model.dom.map(([a, b, ca, cb]) => ({a, b, ca, cb}));
  const sol = model.conds.map(c => arrelsX(M.polinomi(M.llegeix(c.g, {variables: ['x']}), 'x')));
  const FC = [{cond: FILA.c0, eq: FILA.e0, tr: FILA.t0, sg: FILA.s0}, {cond: FILA.c1, eq: FILA.e1, tr: FILA.t1, sg: FILA.s1}];
  const n = model.conds.length;
  const darrer = passos[passos.length - 1];
  comprova(darrer.classes[FILA.fi] === 'final', () => `${nom}: el domini no està destacat`);
  passos.forEach((pas, s) => pas.files.forEach((tex, fila) => {
    if (!tex) return;
    const on = `${nom}, pas ${s + 1}, fila ${fila}`;
    linies++;
    try {
      if (fila === FILA.f) {
        comprova(textPla(tex) === `f(x)=${model.fPla}`, () => `${on}: «${textPla(tex)}» no és f(x) = ${model.fPla}`);
        const marcades = Object.entries(grupsAmbClau(tex)).filter(([, v]) => v.marca);
        comprova(marcades.length <= 1 && marcades.every(([k, v]) => v.marca === 'tria' && /^Gp\d$/.test(k)), () => `${on}: marques de f incorrectes`);
        if (marcades.length) {
          const c = +marcades[0][0][2];
          comprova(c < n && pas.text.length > 20, () => `${on}: es marca un tros que no posa cap condició`);
        }
      } else if (FC.some(b => b.cond === fila)) {
        const c = FC.findIndex(b => b.cond === fila);
        comprova(c < n, () => `${on}: una condició que no existeix`);
        const llinks = liniesLogiques(tex).join('').split('⇔');
        const rel = {ne: '≠', ge: '≥', gt: '>'}[model.conds[c].rel];
        const m = /^(.*?)(≥|≠|>)0$/.exec(llinks[0]);
        comprova(m && m[2] === rel && PUNTS_X.every(x => valorX(m[1], 'x', x).igual(valorX(model.conds[c].g, 'x', x))), () => `${on}: la primera línia «${llinks[0]}» no és «g ${rel} 0»`);
        llinks.forEach((l, k) => {
          const f = liniaDomini(l);
          for (const x of GRAELLA_DOMINI) {
            if (f(x) !== RELACIONS_DOMINI[model.conds[c].rel](valorX(model.conds[c].g, 'x', x))) {
              comprova(false, () => `${on}: «${l}» no és equivalent a la condició a x = ${x.num}/${x.den}`);
              break;
            }
          }
          // L'última línia, en forma normal d'intervals (ordenats, sense poder unir-ne cap).
          if (k === llinks.length - 1 && /^x∈[([]/.test(l)) {
            const iv = intervalsDomini(l.slice(2));
            iv.forEach((q, j) => {
              if (j) {
                const prev = iv[j - 1];
                comprova(prev.b !== null && q.a !== null && (prev.b < q.a || (prev.b === q.a && !prev.cb && !q.cb)), () => `${on}: «${l}»: intervals no normals`);
              }
            });
          }
        });
      } else if (FC.some(b => b.eq === fila || b.tr === fila)) {
        const c = FC.findIndex(b => b.eq === fila || b.tr === fila);
        comprova(c < n && model.conds[c], () => `${on}: una equació que no existeix`);
        const trobades = solucionsX(textPla(tex), 'x');
        comprova(trobades === conjunt(sol[c]), () => `${on}: «${textPla(tex)}» té les solucions {${trobades}} i g = 0, {${conjunt(sol[c])}}`);
      } else if (FC.some(b => b.sg === fila)) {
        const c = FC.findIndex(b => b.sg === fila);
        comprova(c < n, () => `${on}: una taula que no existeix`);
        const [cap, cos] = cellesTaula(tex);
        const arrels = sol[c].slice().sort((a, b) => a.resta(b).signe());
        comprova(cap.length === 2 * arrels.length + 2 && cap[0] === 'x', () => `${on}: capçalera de la taula: ${cap}`);
        const g = model.conds[c].g;
        comprova(model.conds[c].rel !== 'ne' && PUNTS_X.every(x => valorX(cos[0], 'x', x).igual(valorX(g, 'x', x))), () => `${on}: la fila de signes no és de g`);
        const marques = grupsAmbClau(tex);
        const omplerta = cos.slice(1).some(t => t);
        cap.slice(1).forEach((h, j) => {
          const esPunt = j % 2 === 1;
          const a = j === 0 ? null : arrels[(j - 1) >> 1], b = j >> 1 < arrels.length && !esPunt ? arrels[j >> 1] : null;
          if (esPunt) comprova(valorX(h, 'x', fr(0)).igual(arrels[(j - 1) >> 1]), () => `${on}: punt ${h} de la capçalera`);
          else {
            const q = llegeixParell(h);
            const esq = a === null ? -Infinity : a.num / a.den, dre = (j >> 1) < arrels.length ? arrels[j >> 1].num / arrels[j >> 1].den : Infinity;
            comprova(q && q[0] === esq && q[1] === dre, () => `${on}: interval ${h} de la capçalera`);
          }
          const prova = esPunt ? arrels[(j - 1) >> 1]
            : j === 0 ? (arrels.length ? arrels[0].resta(1) : fr(0)) : (j >> 1) < arrels.length ? arrels[(j - 1) >> 1].suma(arrels[j >> 1]).quocient(2) : arrels[arrels.length - 1].suma(1);
          const v = valorX(g, 'x', prova).signe();
          const esperat = v > 0 ? '+' : v < 0 ? '-' : '0';
          if (omplerta) comprova(cos[1 + j] === esperat, () => `${on}: signe de g al tros ${h}: «${cos[1 + j]}», i és ${esperat}`);
          const marca = (marques[`T${c}s${j}`] || {}).marca || '';
          const serveix = model.conds[c].rel === 'ge' ? v >= 0 : v > 0;
          if (omplerta && marca) comprova(marca === 'mes', () => `${on}: marca estranya`);
          if (marca) comprova(serveix, () => `${on}: marcat el tros ${h}, que no compleix la condició`);
        });
        const hiHaMarques = Object.values(marques).some(v => v.marca);
        if (hiHaMarques) {
          const total = cap.slice(1).filter((h, j) => {
            const prova = j % 2 === 1 ? arrels[(j - 1) >> 1] : j === 0 ? (arrels.length ? arrels[0].resta(1) : fr(0)) : (j >> 1) < arrels.length ? arrels[(j - 1) >> 1].suma(arrels[j >> 1]).quocient(2) : arrels[arrels.length - 1].suma(1);
            const v = valorX(g, 'x', prova).signe();
            return model.conds[c].rel === 'ge' ? v >= 0 : v > 0;
          }).length;
          comprova(Object.values(marques).filter(v => v.marca).length === total, () => `${on}: falten trossos per marcar (o en sobren)`);
        }
      } else if (fila === FILA.recta) {
        comprova(tex.startsWith('<svg'), () => `${on}: la recta ha de ser un dibuix`);
        const grups = tex.split('<g class="').slice(1);
        comprova(grups.length === (n >= 2 ? (passos.slice(s).some(q => q.files[FILA.inter].includes('{k=Ir}')) && tex.includes('conj-dom') ? 3 : 2) : 1), () => `${on}: nombre de línies de la recta: ${grups.length}`);
      } else if (fila === FILA.inter) {
        comprova(n === 2, () => `${on}: una intersecció sense dues condicions`);
        const pla = textPla(tex);
        const [esq, dre] = pla.split('=');
        const [A, B] = esq.split('∩');
        const fA = conjuntDomini(A), fB = conjuntDomini(B);
        const truth = c => x => RELACIONS_DOMINI[model.conds[c].rel](valorX(model.conds[c].g, 'x', x));
        for (const x of GRAELLA_DOMINI) {
          comprova(fA(x) === truth(0)(x) && fB(x) === truth(1)(x), () => `${on}: «${esq}» no són els conjunts de les condicions (x = ${x.num}/${x.den})`);
          if (dre !== undefined) comprova(conjuntDomini(dre)(x) === (truth(0)(x) && truth(1)(x)), () => `${on}: «${dre}» no és la intersecció (x = ${x.num}/${x.den})`);
        }
      } else if (fila === FILA.fi) {
        const pla = textPla(tex);
        const m = /^«Dom»f=(ℝ=)?(.*)$/.exec(pla);
        comprova(m, () => `${on}: el domini no s'entén: «${pla}»`);
        if (!m) return;
        const tot = model.dom.length === 1 && model.dom[0][0] === -INF_D && model.dom[0][1] === INF_D;
        comprova(Boolean(m[1]) === tot, () => `${on}: «ℝ =» ${tot ? 'falta' : 'sobra'}`);
        const f = conjuntDomini(m[2]);
        for (const x of GRAELLA_DOMINI) comprova(f(x) === enModel(model.dom, x.num / x.den), () => `${on}: «${m[2]}» no és el domini (x = ${x.num}/${x.den})`);
        const iv = intervalsDomini(m[2]);
        comprova(iv.length === model.dom.length, () => `${on}: el nombre d'intervals del domini és ${iv.length}, i ha de ser ${model.dom.length}`);
      } else {
        comprova(false, () => `${on}: una fila que no hauria d'existir`);
      }
    } catch (e) {
      comprova(false, () => `${on}: no es pot llegir «${tex.slice(0, 120)}»: ${e.message}`);
    }
  }));
  // El guió acaba amb el domini; la intersecció només amb dues condicions.
  comprova(Boolean(darrer.files[FILA.fi]) && Boolean(darrer.files[FILA.recta]) && Boolean(darrer.files[FILA.inter]) === (n === 2), () => `${nom}: l'últim pas no té les files que toca`);
  return linies;
}

seccio('domini d\'una funció', () => {
  let linies = 0, passos = 0;
  comprova(Domini.problemes.length === Object.keys(MODELS_DOMINI).length && Domini.problemes.every(p => MODELS_DOMINI[p.id]), () => 'la llista de problemes no és la del model');
  for (const problema of Domini.problemes) {
    const llista = Domini.passos({p: problema.id});
    comprovaGuio(llista, Domini.files, problema.id);
    linies += comprovaDomini(llista, problema, problema.id);
    passos += llista.length;
    // L'adreça: anada i tornada.
    const a = Domini.escriuAdreca({p: problema.id});
    comprova(Domini.llegeixAdreca(a).valors.p === problema.id, () => `${problema.id}: adreça`);
  }
  comprova(Domini.llegeixAdreca({p: 'no-existeix'}).error, () => 'cal un error per a un problema que no existeix');
  return `${Domini.problemes.length} funcions, ${passos} passos, ${linies} línies comprovades`;
});


seccio('regles generals de totes les pàgines', () => {
  const PAGINES = {RectaTangent: 'recta-tangent', Creixement: 'creixement', Extrems: 'extrems', PolinomiCondicions: 'polinomi-condicions',
    Optimitzacio: 'optimitzacio', Asimptotes: 'asimptotes', Bolzano: 'bolzano', Primitiva: 'primitiva', Barrow: 'barrow', AreaEix: 'area-eix',
    AreaCorbes: 'area-corbes', AreaParametre: 'area-parametre', Domini: 'domini', ProbabilitatTotal: 'probabilitat-total', Bayes: 'bayes', Binomial: 'binomial',
    Determinant: 'determinant', Rang: 'rang', Inversa: 'inversa', EquacioMatricial: 'equacio-matricial', Discussio: 'discussio',
    SistemaSCI: 'sistema-sci', Esglaonar: 'esglaonar', Pla: 'pla', RectaPlans: 'recta-plans', RectaPla: 'recta-pla', DuesRectes: 'dues-rectes',
    Distancies: 'distancies', Projeccions: 'projeccions', AreaVolum: 'area-volum', PerpendicularComuna: 'perpendicular-comuna', GraficaFuncio: 'grafica-funcio'};
  // Comprovacions que formen part del mètode (no són opcionals): les hipòtesis de Bolzano, f'' dels extrems que demana l'enunciat.
  const AMB_COMPROVACIO = new Set(['bolzano', 'polinomi-condicions']);
  const sense = t => t.replace(/\\htmlData\{[^}]*\}/g, '');
  let pagines = 0, passos = 0;
  for (const [global, pag] of Object.entries(PAGINES)) {
    const P = globalThis[global];
    comprova(P, () => `falta el procediment ${global}`);
    if (!P) continue;
    pagines++;
    const geometria = P.categoria === 'geometria';
    const casos = [];
    for (const e of P.exemples || []) casos.push(Object.assign({}, P.perDefecte || {}, e));
    if (P.modes) for (const o of P.modes.opcions) for (const e of P.exemples || []) casos.push(Object.assign({}, P.perDefecte || {}, e, {[P.modes.id]: o.valor}));
    for (const v of casos) {
      if (P.valida && P.valida(v)) continue;
      const llista = P.passos(v);
      passos += llista.length;
      const nom = `${pag} ${JSON.stringify(v)}`;
      const textos = [P.enunciat ? P.enunciat(v) : ''].concat(llista.map(q => q.text));
      llista.forEach((pas, i) => {
        const on = `${nom}, pas ${i + 1}`;
        const tot = sense(pas.files.join(' \n ')) + ' \n ' + pas.text;
        // Mai Cramer; mai les sigles dels tipus de sistema ni de les asímptotes; mai «màx/mín».
        comprova(!/cramer/i.test(tot), () => `${on}: Cramer (mai: David)`);
        comprova(!/\b(SCD|SCI|AV|AH|AO)\b|\\text\{SI\}|\bmàx\b|\bmín\b/.test(tot), () => `${on}: una abreviatura (SCD, SCI, SI, AV, AH, AO, màx, mín): cal la paraula sencera`);
        // Cap comprovació opcional després de la resposta.
        if (!AMB_COMPROVACIO.has(pag)) comprova(!/comprov/i.test(pas.text), () => `${on}: una comprovació («${pas.text.slice(0, 60)}…»): no se'n fan (David)`);
        pas.files.forEach((tex, f) => {
          if (!tex || tex.startsWith('<svg')) return;
          const t = sense(tex);
          // Un punt s'escriu P(3, -5), sense «=»; i a geometria mai les lletres X ni H per a un punt.
          if (geometria) {
            comprova(!/(^|[^\\a-zA-Z{])[A-Z](_\{?[^}= ]*\}?)?'?\s*=\s*\((?!x)/.test(t.replace(/\\overrightarrow\{[^}]*\}|\\vec\{[^}]*\}/g, 'v')), () => `${on}, fila ${f + 1}: un punt escrit amb «=»: «${t.slice(0, 80)}»`);
            comprova(!/(^|[^\\a-zA-Z])[XH](_\{?[^}]*\}?)?'?\(/.test(t), () => `${on}, fila ${f + 1}: un punt anomenat X o H`);
            comprova(!/\\cap|\\varnothing|\\emptyset|\\subset/.test(t), () => `${on}, fila ${f + 1}: notació de conjunts (cal una frase)`);
          }
          if (tex.startsWith('§')) return;
          // Un resultat («= 0») mai sol en una línia nova.
          for (const l of tex.split(/\\\\(?:\[[^\]]*\])?/).slice(1)) {
            let pla = '';
            try { pla = textPla(l.replace(/\\end\{array\}.*$/, '').replace(/^\s*&/, '')); } catch (e) { continue; }
            comprova(!/^=-?[\d,.]+$/.test(pla), () => `${on}, fila ${f + 1}: «${pla}» sol en una línia`);
          }
          // Davant d'un parèntesi, el producte porta punt (x · (x − 2), 2 · (x − 1)); les matrius, juxtaposades (A⁻¹B).
          if (pag !== 'equacio-matricial' && pag !== 'inversa') {
            let pla = '';
            try { pla = textPla(t); } catch (e) { return; }
            // π es llegeix «(pi)»; les fraccions ((a)/(b)), com un sol bloc; un interval o una fila nova després de «∪», «;», «,», «|» no és cap producte.
            const net = pla.replace(/\(pi\)/g, 'π').replace(/\(\([^()]*\)\/\([^()]*\)\)/g, 'F').replace(/[∪;|,»]\(/g, '#').replace(/_[\w\dλμ]\(/g, '#').replace(/\^\([+-]\)/g, '#');   // P_0(…), D_1(…): un nom de punt; x → 1⁻: el costat d'un límit lateral
            // també una incògnita sola davant d'un parèntesi: «x(x − 2)» (les funcions, f(x), F(x), P(…), d(…), no)
            const net2 = net.replace(/sqrt\(|det\(|lim/g, '#').replace(/[λμt]\([^()]*,[^()]*\)/g, '#');   // λ(1, 1, 0): un vector, notació habitual
            comprova(!/(\d|\))\(/.test(net) && !/(^|[^a-zA-Z_'])[xyzkmtλμ]\(/.test(net2), () => `${on}, fila ${f + 1}: un producte sense punt davant d'un parèntesi: «${pla.slice(0, 90)}»`);
          }
        });
      });
      // Els textos (enunciat i explicacions): les fórmules, ben tancades (un nombre parell de «$»).
      for (const t of textos) comprova((t.match(/\$/g) || []).length % 2 === 0, () => `${nom}: un «$» sense parella: «${t.slice(0, 90)}»`);
      // Punts sense «=», i cap fórmula que digui «X» o «H» per a un punt a geometria.
      if (geometria) for (const t of textos) {
        comprova(!/\$[^$]*(^|[^\\a-zA-Z{])[A-Z](_\{?[^}= ]*\}?)?'?\s*=\s*\((?!x)[^$]*\$/.test(t.replace(/\\overrightarrow\{[^}]*\}|\\vec\{[^}]*\}/g, 'v')), () => `${nom}: un punt escrit amb «=» al text: «${t.slice(0, 90)}»`);
      }
    }
  }
  return `${pagines} pàgines, ${passos} passos`;
});

// KaTeX amb throwOnError: false (com a les pàgines) no falla: dibuixa en vermell el que no entén (p. ex. «paral·lela» dins de
// \text{}, que surt «paral\cdotplela»). Aquí es dibuixen amb throwOnError: true totes les fórmules de tots els exemples.
// Cal KaTeX: KATEX=<katex/dist o katex.js> node procediments/proves/comprova.js (o bé un «katex» que require pugui trobar).
seccio('regles generals: KaTeX dibuixa totes les fórmules', () => {
  let katex = null;
  for (const lloc of [process.env.KATEX, 'katex']) {
    if (!lloc) continue;
    try { katex = require(lloc.endsWith('.js') || lloc === 'katex' ? lloc : path.resolve(lloc, 'katex.js')); break; } catch (e) { /* el següent */ }
  }
  if (!katex) return 'NO COMPROVAT: falta KaTeX (KATEX=<katex/dist>)';
  const PISSARRA = {throwOnError: true, strict: 'ignore', trust: c => c.command === '\\htmlData'}, TEXT = {throwOnError: true, strict: 'ignore'};
  const fet = new Set();
  const dibuixa = (tex, opcions, on) => {
    if (fet.has(tex)) return;
    fet.add(tex);
    let error = '';
    try { katex.renderToString(tex, opcions); } catch (e) { error = e.message; }
    comprova(!error, () => `${on}: KaTeX no ho pot dibuixar (${error.slice(0, 110)}): «${tex.slice(0, 90)}»`);
  };
  const formulesDe = (text, on) => { for (const m of text.matchAll(/\$([^$]+)\$/g)) dibuixa(m[1], TEXT, on); };
  const NOMS = ['RectaTangent', 'Creixement', 'Extrems', 'PolinomiCondicions', 'Optimitzacio', 'Asimptotes', 'Bolzano', 'Primitiva', 'Barrow',
    'AreaEix', 'AreaCorbes', 'AreaParametre', 'ProbabilitatTotal', 'Bayes', 'Binomial', 'Determinant', 'Rang', 'Inversa', 'EquacioMatricial',
    'Discussio', 'SistemaSCI', 'Esglaonar', 'Pla', 'RectaPlans', 'RectaPla', 'DuesRectes', 'Distancies', 'Projeccions', 'AreaVolum', 'PerpendicularComuna', 'GraficaFuncio'];
  for (const global of NOMS) {
    const P = globalThis[global];
    if (!P) continue;
    const casos = [];
    for (const e of P.exemples || []) casos.push(Object.assign({}, P.perDefecte || {}, e));
    if (P.modes) for (const o of P.modes.opcions) for (const e of P.exemples || []) casos.push(Object.assign({}, P.perDefecte || {}, e, {[P.modes.id]: o.valor}));
    for (const v of casos) {
      if (P.valida && P.valida(v)) continue;
      const nom = `${global} ${JSON.stringify(v)}`;
      if (P.enunciat) formulesDe(P.enunciat(v), nom + ', enunciat');
      if (P.resum && !P.nomExemple) dibuixa(P.resum(v), TEXT, nom + ', resum');   // el nom de l'exemple (si no n'hi ha, el resum)
      P.passos(v).forEach((pas, i) => {
        formulesDe(pas.text, `${nom}, pas ${i + 1}`);
        pas.files.forEach((tex, f) => {
          if (!tex || tex.startsWith('<svg')) return;
          if (tex.startsWith('§')) formulesDe(tex.slice(1).replace(/\{\{[^|}]*\|[^|}]*\|([^}]*)\}\}/g, '$1'), `${nom}, pas ${i + 1}, fila ${f + 1}`);
          else dibuixa(tex, PISSARRA, `${nom}, pas ${i + 1}, fila ${f + 1}`);
        });
      });
    }
  }
  return `KaTeX ${katex.version}, ${fet.size} fórmules diferents`;
});


/* ── RESULTAT ──────────────────────────────────────────────────────── */

if (missatges.length) {
  console.log('\nPrimers errors:');
  for (const m of missatges) console.log('  · ' + m);
}
console.log(errors
  ? `\nHi ha ${errors} errors (de ${total} comprovacions).`
  : `\nTot correcte: ${total} comprovacions.`);
process.exitCode = errors ? 1 : 0;
